# deepseek-harness-session-bi

DeepSeek Harness 会话运营数据插件。

当前 MVP：

- 监听 Session 创建、事件和销毁生命周期；
- 解析首条用户消息中的“责任人 / 责任人小组 / 目录 / 问题描述”；
- 记录状态、轮次、消息数、工具调用、错误、模型和处理时长；
- 使用本地 JSON 文件做崩溃安全的原子持久化；
- 通过受 Harness Connection 认证保护的 `/api/deepseek-harness-session-bi/records` 查询；
- 提供 Web Client 主面板与左侧导航入口。

默认数据文件为 Harness Home 下的 `session-bi/records.json`，在 Docker Compose 中对应 `dsh_home` 持久卷，不依赖 `/tmp`。也可以用 `DSH_SESSION_BI_DATA_FILE` 指定绝对路径。

当前 Compose 将 `WECOM_WORKSPACE_ROOT` 指向 `/data/tickets`，且案件目录是只读挂载，因此 BI 台账不默认写入该目录。若将来把 `/data/tickets` 的管理子目录单独以 `rw` 挂载，也可以把 `DSH_SESSION_BI_DATA_FILE` 指向 `/data/tickets/.harness-ops/session-bi/records.json`。

插件会在新数据文件不存在时尝试迁移旧版本的临时文件。未登记或格式不符合约定的首条消息会保留为 `invalid`，不会静默丢弃。

Docker Compose 建议使用以下变量：

```yaml
WECOM_WORKSPACE_ROOT: /data/tickets
DSH_SESSION_BI_RULE_SOURCE_ROOT: /data/tickets
DSH_SESSION_BI_DATA_FILE: /home/dsh/.dsh/session-bi/records.json
DSH_SESSION_BI_RULE_PACKAGE_ROOT: /home/dsh/.dsh/session-bi/rule-packages
```

`/data/tickets` 继续挂载为只读。规则版本和 BI 台账由 `dsh_home` 持久卷保存；新会话如果 Q 目录可写，会把选定规则包复制到该目录，否则保留版本绑定并使用会话级提示加载。

规则版本可以在 Web 的“规则包管理”页通过“从当前 Workspace 导入版本”生成，也可以预先写入 `rulePackageRoot/<packageId>/<version>/`，其中必须包含 `manifest.json` 和规则文件。企微新会话可显式指定：

```text
目录：Q2026111100310；规则包：hci-diagnosis@1.7.0-rc.1；问题：迁移失败
```

## 首条消息格式

```text
责任人：xxx
责任人小组：xxx
目录：Q2026xxxxxxxx
问题描述：xxx
```

## 当前边界

JSON 存储适合单进程 MVP。上线到大规模多人使用前，应将 `SessionOpsStore` 替换为 SQLite 或 PostgreSQL 实现，保持查询 DTO 和 Web 面板契约不变。
