# ip-redactor

DeepSeek Harness `0.2.1-rc.3` 的 Agent/LLM 边界 IPv4 脱敏插件。它复用 DSH 已配置的模型 provider 和 API Key，本身不请求模型、不读取模型凭据。

## 工作方式

1. `llm/stream` 在请求交给现有 provider 前复制并脱敏完整模型输入，原始本机会话不改动。
2. 最终输入如仍含受保护 IPv4，使用 `IP_REDACTION_LEAK` 拒绝请求。
3. 模型返回工具调用时，在 Agent 接收完整参数的边界透明还原已知占位符。
4. DSH 原生 `bash`、`read` 和其他工具保持原样，不新增、不移除，也不要求模型改用特殊工具。

精确的 `127.0.0.1` 保留，其他合法 IPv4 均脱敏。第一版不处理 IPv6、域名、MAC 或主机名。

原始日志文件不会被修改。原始 IP 只在本机工具执行边界短暂出现，不进入模型输入。

## 构建

需要 Node.js 24.9+：

```bash
cd /root/codex/agent_tools/ip-redactor
npm test
npm run build
npm_config_cache=/tmp/ip-redactor-npm-cache npm pack
```

`npm run build` 使用 Node 24 自带的 TypeScript transform 生成运行时 JavaScript。联网安装开发依赖后，还可以运行：

```bash
npm install
npm run check
```

## 安装

```bash
dsh --profile web plugin add ./ip-redactor-0.1.0.tgz
```

也可以替换为你的 profile 名称。安装后重启 DSH，继续选择原来已经配置好的 provider 和模型，不需要为本插件配置 API Key。

随包的配置只有：

```yaml
- insert:
    - id: ip-redactor
      name: ip-redactor
      config:
        maxSessions: 128
        audit: true
```

## 使用

正常让 Agent 查看日志即可。工具结果中的：

```text
10.20.30.40
```

会变成（隐藏前三段、保留末段，并附加会话内唯一编号）：

```text
*.*.*.40#IP0001
```

需要继续精确查询时，Agent 仍正常调用原生工具：

```text
bash(command="grep -R '*.*.*.40#IP0001' ./logs")
```

插件在本地实际执行：

```text
grep -R '10.20.30.40' ./logs
```

返回给模型的结果仍只包含 `IP_0001`。

Agent 侧实际收到的工具参数已恢复为原始 IP，因此原生工具及其参数能力完全不变。

## 安全说明

- 映射只保存在插件进程内存中，按 session id 隔离，并按 `maxSessions` 做 LRU 淘汰。
- 审计只记录阶段、替换数量和是否存在活动 session，不记录原始 IP、命令、prompt 或 API Key。
- 安装插件前已经写入会话历史的原始 IP 不会被静默发送；最终扫描会阻止请求。遇到此错误时应清空旧会话或重新提交相关上下文。
- 其他插件若在 `agent/pre-step` 之后注入原始 IP，也会被最终扫描阻止，而不会发送给模型。
