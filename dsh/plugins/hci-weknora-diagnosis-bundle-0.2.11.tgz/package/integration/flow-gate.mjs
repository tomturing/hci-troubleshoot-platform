import { caseAgent } from './case-agent.mjs'

export const name = 'hci-weknora-flow-gate'
export const inject = ['tools']

const ledgers = new WeakMap()
const DEFAULT_TOP_N = 3
const INVESTIGATION_TOOLS = new Set(['hci_quick_ask', 'hci_reasoning_ask'])
const INVESTIGATION_SEARCH_DIRECTIVE = /(?:^|[\r\n；;])\s*(?:[-*]\s*)?weknora排查思路是否检索\s*[:：]\s*(开启|关闭|true|false|yes|no|on|off|是|否|开|关|1|0)(?=\s*(?:$|[\r\n；;]))/giu

function messageText(event) {
  const message = event?.data?.message ?? event?.data
  const content = Array.isArray(message?.content) ? message.content : []
  return content
    .filter(block => block?.type === 'text' && typeof block.text === 'string')
    .map(block => block.text)
    .join('\n')
}

function latestUserMessage(agent) {
  const session = agent?.session
  const events = typeof session?.snapshotEvents === 'function'
    ? session.snapshotEvents()
    : Array.isArray(session?.events) ? session.events : []
  return [...events].reverse().find(event => event?.type === 'user/message'
    && (event.data?.source === undefined || event.data.source?.kind === 'user'))
}

export function investigationKbSearchEnabled(agent, configuredDefault = true) {
  const text = messageText(latestUserMessage(caseAgent(agent)))
  let override
  for (const match of text.matchAll(INVESTIGATION_SEARCH_DIRECTIVE)) {
    override = !['false', 'no', 'off', '否', '关', '关闭', '0'].includes(match[1].toLowerCase())
  }
  return override ?? (configuredDefault !== false)
}

function list(value) {
  if (!Array.isArray(value)) return []
  return [...new Set(value.filter(item => typeof item === 'string').map(item => item.trim()).filter(Boolean))]
}

function topN(value) {
  const parsed = Number(value)
  return Number.isSafeInteger(parsed) && parsed >= 1 && parsed <= 20 ? parsed : DEFAULT_TOP_N
}

function sameMembers(left, right) {
  const a = [...left].sort()
  const b = [...right].sort()
  return a.length === b.length && a.every((item, index) => item === b[index])
}

function classifyScope(requested, config) {
  if (requested.length === 0) {
    if (config.caseKnowledgeBaseIds.length > 0 && config.playbookKnowledgeBaseIds.length === 0) return 'case'
    if (config.playbookKnowledgeBaseIds.length > 0 && config.caseKnowledgeBaseIds.length === 0) return 'playbook'
    return undefined
  }
  if (sameMembers(requested, config.caseKnowledgeBaseIds)) return 'case'
  if (sameMembers(requested, config.playbookKnowledgeBaseIds)) return 'playbook'
  return undefined
}

function ledger(agent) {
  const owner = caseAgent(agent)
  let value = ledgers.get(owner)
  if (!value) {
    value = { required: new Set(), read: new Set(), evidence: new Set(), evidenceRecords: new Map(), searches: [], documents: new Map(), originalIds: new Map(), originalTitles: new Map(), originalUrls: new Map() }
    ledgers.set(owner, value)
  }
  return value
}

function resultJson(result) {
  const value = result?.value
  if (value && typeof value === 'object' && !Array.isArray(value) && !Array.isArray(value.content)) return value
  const blocks = value?.content ?? result?.content ?? []
  const text = Array.isArray(blocks) ? blocks.find(block => block?.type === 'text')?.text : undefined
  if (typeof text !== 'string') return undefined
  try { return JSON.parse(text) } catch { return undefined }
}

function candidateDocuments(payload, count) {
  if (!payload || !Array.isArray(payload.results)) return []
  const ids = []
  const seen = new Set()
  for (const hit of payload.results) {
    const id = hit?.knowledge_id
    if (typeof id !== 'string' || !id || seen.has(id)) continue
    seen.add(id)
    ids.push(id)
    if (ids.length >= count) break
  }
  return ids
}

function rememberDocument(state, id, title) {
  if (typeof id !== 'string' || id === '' || typeof title !== 'string') return
  const normalized = title.trim()
  if (normalized === '' || normalized === id) return
  state.documents.set(id, normalized)
  const imported = normalized.match(/^((?:HCI[-_])?\d+)\s*\|\s*(.+)$/i)
  if (imported) {
    state.originalIds.set(id, imported[1].replace(/^HCI[-_]/i, ''))
    state.originalTitles.set(id, imported[2].trim())
  }
}

function rememberOriginalCase(state, id, payload) {
  const content = typeof payload?.content === 'string' ? payload.content : ''
  const sourceId = content.match(/^\s*案例\s*ID\s*[:：]\s*([A-Za-z0-9_-]+)/im)?.[1]
  if (sourceId) state.originalIds.set(id, sourceId)
  const sourceUrl = content.match(/^\s*原文链接\s*[:：]\s*(https?:\/\/\S+)/im)?.[1]?.replace(/\\+_/g, '_')
  if (sourceUrl) {
    try {
      const url = new URL(sourceUrl)
      if (url.protocol === 'https:' || url.protocol === 'http:') state.originalUrls.set(id, url.href)
    } catch { /* An invalid source link cannot be cited. */ }
  }
  const heading = content.match(/^#\s+(.+)$/m)?.[1]?.trim()
  if (heading && (payload?.page === undefined || payload.page === 1)) state.originalTitles.set(id, heading)
}

function rememberDocumentLabels(state, payload) {
  for (const hit of payload?.results ?? []) {
    rememberDocument(state, hit?.knowledge_id, hit?.document)
  }
  for (const document of payload?.documents ?? []) {
    rememberDocument(state, document?.knowledge_id, document?.title)
  }
}

function documentCitations(state, ids) {
  return ids.map(id => ({
    knowledge_id: id,
    title: state.originalTitles.get(id) ?? state.documents.get(id) ?? '',
    original_id: state.originalIds.get(id) ?? '',
    original_url: state.originalUrls.get(id) ?? '',
  }))
}

const IPV4 = /(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])/g
const ALIAS = /\*\.\*\.\*\.\d{1,3}#IP\d{4,}/g
const escapeRegex = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')

function pathInSummary(summary, path) {
  if (summary.includes(path)) return true
  const parts = []
  let cursor = 0
  for (const match of path.matchAll(IPV4)) {
    parts.push(escapeRegex(path.slice(cursor, match.index)))
    const lastOctet = match[0].slice(match[0].lastIndexOf('.') + 1)
    parts.push(`\\*\\.\\*\\.\\*\\.${lastOctet}#IP\\d{4,}`)
    cursor = match.index + match[0].length
  }
  if (cursor === 0) return false
  parts.push(escapeRegex(path.slice(cursor)))
  return new RegExp(parts.join(''), 'u').test(summary)
}

function normalizedSource(text) {
  return text.replace(ALIAS, '<IP>').replace(IPV4, '<IP>')
}

function evidenceExcerptInSummary(summary, record) {
  if (!pathInSummary(summary, record.path)) return false
  const codeBlocks = [...summary.matchAll(/```[^\n]*\n([\s\S]*?)```/gu)].map(match => normalizedSource(match[1]))
  return record.lines.some(line => line.length >= 20
    && codeBlocks.some(block => block.split('\n').includes(normalizedSource(line))))
}

function rememberSearch(agent, result, kind, limits) {
  const count = kind === 'playbook' ? limits.playbookTopN : limits.caseTopN
  const payload = resultJson(result)
  const ids = candidateDocuments(payload, count)
  const state = ledger(agent)
  rememberDocumentLabels(state, payload)
  ids.forEach(id => state.required.add(id))
  state.searches.push({ kind, ids })
}

export function validateSummary(agent, summary, rootCauseStatus = 'undetermined') {
  const state = ledger(agent)
  const missing = [...state.required].filter(id => !state.read.has(id))
  const citations = documentCitations(state, [...state.required])
  const caseLinkPattern = /\[原始案例\s*ID\s*[:：]\s*([A-Za-z0-9_-]+)\]\((https?:\/\/[^)\s]+)\)/giu
  const linkedCaseReferences = [...summary.matchAll(caseLinkPattern)]
  const summaryWithoutCaseLinks = summary.replace(caseLinkPattern, '')
  const unlinkedCaseReferences = [...summaryWithoutCaseLinks.matchAll(/(?:原始案例\s*ID|案例\s*(?:ID|号))\s*[:：]?\s*([A-Za-z0-9_-]+)/giu)]
  const citationByOriginalId = new Map(citations.filter(item => item.original_id).map(item => [item.original_id, item]))
  const unverifiedCaseLinks = linkedCaseReferences.filter(match => {
    const citation = citationByOriginalId.get(match[1])
    return !citation || citation.original_url !== match[2]
  })
  const cited = citations.filter(item => (item.title && summary.includes(item.title))
    || (item.original_id && new RegExp(`(?:^|[^A-Za-z0-9_-])${escapeRegex(item.original_id)}(?![A-Za-z0-9_-])`, 'u').test(summary)))
  const missingOriginalIds = cited.filter(item => item.original_id === '')
  const missingCitations = cited.filter(item => item.original_id && !summary.includes(`原始案例 ID：${item.original_id}`) && !summary.includes(`原始案例 ID: ${item.original_id}`))
  const missingUrls = cited.filter(item => item.original_id && !item.original_url)
  const missingLinks = cited.filter(item => {
    if (!item.original_id || !item.original_url) return false
    const link = `[原始案例 ID：${item.original_id}](${item.original_url})`
    const withoutValidLinks = summary.split(link).join('')
    return !summary.includes(link)
      || new RegExp(`原始案例 ID\\s*[:：]\\s*${escapeRegex(item.original_id)}(?![A-Za-z0-9_-])`, 'u').test(withoutValidLinks)
  })
  const missingTitles = citations.filter(item => item.original_id
    && (summary.includes(`原始案例 ID：${item.original_id}`) || summary.includes(`原始案例 ID: ${item.original_id}`))
    && item.title && !summary.includes(item.title))
  const exposedKnowledgeIds = citations.filter(item => summary.includes(item.knowledge_id))
  const errors = []
  if (missing.length) errors.push(`必须通过 hci_kb_read_document 回读这些候选后才能收尾: ${missing.join(', ')}`)
  if (unlinkedCaseReferences.length) errors.push(`报告中的案例 ID 必须使用正文原文链接: ${[...new Set(unlinkedCaseReferences.map(match => match[1]))].join(', ')}`)
  if (unverifiedCaseLinks.length) errors.push(`报告中的案例链接必须先通过 hci_kb_read_document 回读核验: ${[...new Set(unverifiedCaseLinks.map(match => match[1]))].join(', ')}`)
  if (missingOriginalIds.length) errors.push(`这些案例缺少可核验的原始案例 ID，不能用 knowledge_id 代替: ${missingOriginalIds.map(item => item.knowledge_id).join(', ')}`)
  if (missingCitations.length) errors.push(`最终报告必须展示原始案例 ID: ${missingCitations.map(item => item.original_id).join(', ')}`)
  if (missingUrls.length) errors.push(`这些案例回读正文缺少有效原文链接，不能编造链接: ${missingUrls.map(item => item.original_id).join(', ')}`)
  if (missingLinks.length) errors.push(`原始案例 ID 必须链接到回读正文中的原文地址: ${missingLinks.map(item => item.original_id).join(', ')}`)
  if (missingTitles.length) {
    errors.push(`最终报告必须展示案例原名: ${missingTitles.map(item => item.title).join(', ')}`)
  }
  if (exposedKnowledgeIds.length) errors.push('面向用户的报告不得展示 WeKnora knowledge_id')
  if (/<kb\b|knowledge_id\s*[:：]/i.test(summary)) errors.push('面向用户的报告不得展示 WeKnora 内部引用标记')
  const evidenceCited = [...state.evidenceRecords.values()].some(record => evidenceExcerptInSummary(summary, record))
  if (state.evidence.size > 0 && !evidenceCited) errors.push('最终报告必须包含已读取支持包的日志路径及代码块中的逐行原文摘录')
  if (/\bE:[0-9a-f]{20}:[0-9a-f]{12}:[0-9a-f]{16}:L\d+-\d+\b/u.test(summary)) errors.push('面向用户的报告不得展示 E 哈希引用')
  if (rootCauseStatus !== 'undetermined' && state.evidence.size === 0) {
    errors.push('没有当前支持包 E 证据时，root_cause_status 只能是 undetermined')
  }
  return {
    valid: errors.length === 0,
    errors,
    required: [...state.required],
    read: [...state.read],
    documents: citations,
    evidence: [...state.evidence],
    rootCauseStatus,
    searches: state.searches,
  }
}

export function apply(ctx, config = {}) {
  const limits = {
    caseTopN: topN(config.caseTopN),
    playbookTopN: topN(config.playbookTopN),
    caseKnowledgeBaseIds: list(config.caseKnowledgeBaseIds),
    playbookKnowledgeBaseIds: list(config.playbookKnowledgeBaseIds),
    investigationKbSearchEnabled: config.investigationKbSearchEnabled !== false,
  }

  ctx.tools.guard(exec => {
    if (INVESTIGATION_TOOLS.has(exec.name)
      && !investigationKbSearchEnabled(exec.agent, limits.investigationKbSearchEnabled)) {
      return '当前机器人消息已关闭 WeKnora 排查思路检索；请仅使用当前支持包 E 证据定位问题。当 E 支持根因方向后，仍可使用 hci_kb_search 和 hci_kb_read_document 检索并回读解决方案。'
    }
    if (exec.name !== 'hci_kb_search') return undefined
    if (limits.caseKnowledgeBaseIds.length === 0 && limits.playbookKnowledgeBaseIds.length === 0) {
      return 'Configure an HCI knowledge base before HCI knowledge search'
    }
    const requested = list(exec.arguments?.knowledge_base_ids)
    const kind = classifyScope(requested, limits)
    if (!kind) {
      return 'HCI knowledge search must explicitly select exactly the configured Case KB ids or exactly the configured Playbook KB ids; do not mix both types in one search'
    }
    return undefined
  })

  ctx.on('tools/execute', async (exec, next) => {
    const result = await next()
    if (!exec.agent) return result
    if (exec.name === 'hci_kb_search' && !result.isError) {
      const kind = classifyScope(list(exec.arguments?.knowledge_base_ids), limits)
      if (kind) rememberSearch(exec.agent, result, kind, limits)
    }
    if (exec.name === 'hci_kb_read_document' && !result.isError) {
      const id = exec.arguments?.knowledge_id
      if (typeof id === 'string' && id) {
        const state = ledger(exec.agent)
        state.read.add(id)
        const payload = resultJson(result)
        rememberDocument(state, id, payload?.title)
        rememberOriginalCase(state, id, payload)
      }
    }
    if ((exec.name === 'mcp__hci_weknora__support_read'
      || exec.name === 'mcp__hci_weknora__support_search') && !result.isError) {
      const payload = resultJson(result)
      const state = ledger(exec.agent)
      if (typeof payload?.citation_id === 'string') {
        state.evidence.add(payload.citation_id)
        if (typeof payload.path === 'string' && Array.isArray(payload.lines)) {
          state.evidenceRecords.set(payload.citation_id, {
            path: payload.path,
            lines: payload.lines.map(line => line?.text).filter(line => typeof line === 'string'),
          })
        }
      }
    }
    return result
  })

  ctx.tools.register({
    name: 'hci_evidence_status',
    description: 'Check HCI evidence and KB-read coverage before drafting the final report. Call this before hci_finalize to avoid rewriting a report around missing reads.',
    parameters: { type: 'object', properties: {}, additionalProperties: false },
    output: {
      schema: { type: 'object' },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
    },
    async execute(_args, exec) {
      const state = ledger(exec.agent)
      return {
        ready: [...state.required].every(id => state.read.has(id)),
        required: [...state.required],
        read: [...state.read],
        missing: [...state.required].filter(id => !state.read.has(id)),
        documents: documentCitations(state, [...state.required]),
        evidence: [...state.evidence],
      }
    },
  })

  ctx.tools.register({
    name: 'hci_finalize',
    description: 'Validate the complete HCI report before final output. Cited cases must show their original title and a linked original case ID. Current support-package evidence must show its file path and verbatim log text without E hashes or source line-number prefixes.',
    parameters: {
      type: 'object',
      properties: {
        summary: { type: 'string', description: 'The complete final Markdown report.' },
        root_cause_status: {
          type: 'string',
          enum: ['confirmed', 'probable', 'undetermined', 'multiple'],
          description: 'Evidence-qualified conclusion status. Without current E evidence this must be undetermined.',
        },
      },
      required: ['summary', 'root_cause_status'],
      additionalProperties: false,
    },
    output: {
      schema: { type: 'object' },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
    },
    async execute(args, exec) {
      const summary = String(args.summary ?? '')
      const result = validateSummary(exec.agent, summary, String(args.root_cause_status ?? ''))
      if (!result.valid) {
      return { validated: false, ...result, instruction: '继续回读缺失文档或补充支持包原文与案例链接，再次调用 hci_finalize。' }
      }
      return { validated: true, ...result, instruction: '门禁通过，可以输出与 summary 完全一致的报告。' }
    },
  })
}
