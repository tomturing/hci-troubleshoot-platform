# WeCom channel for ordinary dsh

The ordinary dsh instance uses this plugin for WeCom group tasks and Web first-task messages. Both entries accept the same first-message syntax:

```text
目录：Q2026112601073；问题：虚拟机备份失败
```

The directory must exist below `WECOM_WORKSPACE_ROOT`. WeCom creates a bound group Session; a Web Session validates the same directory before its first model step and records a durable task marker and scoped instruction. This plugin does not install Session BI or create versioned `Q...-v...` rule directories.
