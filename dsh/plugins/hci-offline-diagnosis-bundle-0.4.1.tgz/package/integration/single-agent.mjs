// Loaded only inside the HCI preset. Both visibility and dispatch are restricted.
export const name = 'hci-offline-single-agent'
export const inject = ['tools']
export const TOOL_NAMES = [
  'knowledge_status', 'case_search', 'playbook_lookup', 'knowledge_read',
  'support_inventory', 'support_read', 'support_search',
].map(name => `mcp__hci_offline__${name}`)

export function apply(ctx) {
  // Some Harness builds select presentation through the scoped executor;
  // others also expose presentAs. The preset explicitly mounts native execution.
  if (typeof ctx.tools.presentAs === 'function') ctx.tools.presentAs('native')
  const inherited = ctx.tools.schemas().map(tool => tool.name)
  const delegation = inherited.filter(name => ['subagent', 'subagent_fork', 'workflow'].includes(name))
  if (delegation.length) ctx.tools.restrict({ deny: delegation })
  ctx.tools.guard(exec => {
    if (['subagent', 'subagent_fork', 'workflow'].includes(exec.name)) {
      return 'HCI offline diagnosis is a single-agent preset; delegation tools are disabled'
    }
    if (exec.agent?.session?.header.origin === 'subagent'
      || (exec.agent?.session?.header.delegationDepth ?? 0) > 0) {
      return 'HCI offline diagnosis requires the root single agent'
    }
    return undefined
  })
}
