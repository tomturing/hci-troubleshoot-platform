import { spawn } from 'node:child_process'
import { existsSync } from 'node:fs'
import { realpath, stat } from 'node:fs/promises'
import { isAbsolute, relative, resolve, sep } from 'node:path'
import { fileURLToPath } from 'node:url'

export const name = 'hci-session-evidence-tools'
export const inject = ['tools']

const OUTPUT_LIMIT = 1024 * 1024

export function runtimeConfig(config = {}) {
  const packageRoot = resolve(fileURLToPath(new URL('..', import.meta.url)))
  const installedPython = resolve(packageRoot, '.venv/bin/python')
  const explicitPython = process.env.HCI_DIAGNOSIS_PYTHON
  const python = explicitPython || (existsSync(installedPython) ? installedPython : '')
  return {
    command: config.command || python || 'uv',
    commandArgs: Array.isArray(config.commandArgs) ? config.commandArgs : (
      python ? ['-m', 'hci_diagnosis.evidence_bridge']
        : ['run', '--frozen', '--no-sync', '--directory', packageRoot, 'python', '-m', 'hci_diagnosis.evidence_bridge']
    ),
    cwd: config.cwd || packageRoot,
    pythonPath: config.pythonPath || resolve(packageRoot, 'src'),
    workspaceRoot: config.workspaceRoot || process.env.WECOM_WORKSPACE_ROOT || '',
    ruleWorkspaceRoot: config.ruleWorkspaceRoot || process.env.WECOM_RULE_WORKSPACE_ROOT || '',
    fallbackSupportRoot: config.fallbackSupportRoot || process.env.HCI_SUPPORT_ROOT || '',
  }
}

function inside(root, candidate) {
  return candidate.startsWith(root.endsWith(sep) ? root : root + sep)
}

async function checkedDirectory(path, label) {
  let resolved
  try {
    resolved = await realpath(path)
  } catch {
    throw new Error(`${label} does not exist: ${JSON.stringify(path)}`)
  }
  if (!(await stat(resolved)).isDirectory()) throw new Error(`${label} is not a directory: ${JSON.stringify(path)}`)
  return resolved
}

/** Resolve one immutable evidence root from the calling session. */
export async function resolveEvidenceRoots(agent, config = {}) {
  const relativeDirectory = agent?.session?.header?.wecomTaskDirectory
  const absoluteDirectory = agent?.session?.header?.wecomTaskAbsoluteDirectory
  const materializedPath = agent?.session?.header?.wecomRuleMaterializedPath
  if (typeof relativeDirectory === 'string' && relativeDirectory.trim()) {
    if (typeof config.workspaceRoot !== 'string' || !config.workspaceRoot.trim()) {
      throw new Error('WECOM_WORKSPACE_ROOT is required for a WeCom-bound diagnosis session')
    }
    if (isAbsolute(relativeDirectory)) throw new Error('WeCom task directory must be relative to its workspace')
    const workspace = await checkedDirectory(config.workspaceRoot, 'WeCom workspace root')
    const target = await checkedDirectory(
      typeof absoluteDirectory === 'string' && absoluteDirectory.trim()
        ? absoluteDirectory : resolve(workspace, relativeDirectory),
      'WeCom task directory',
    )
    if (target === workspace || !inside(workspace, target)) {
      throw new Error('WeCom task directory resolves outside its workspace')
    }
    const analysisRoot = typeof materializedPath === 'string' && materializedPath.trim()
      ? await checkedDirectory(materializedPath, 'Session rule analysis directory')
      : target
    if (typeof materializedPath === 'string' && materializedPath.trim()) {
      const ruleRoot = await checkedDirectory(config.ruleWorkspaceRoot, 'Rule workspace root')
      if (!inside(ruleRoot, analysisRoot)) throw new Error('Session rule analysis directory is outside the rule workspace')
    }
    return { root: analysisRoot, sourceRoot: target }
  }
  if (typeof config.fallbackSupportRoot === 'string' && config.fallbackSupportRoot.trim()) {
    return { root: await checkedDirectory(config.fallbackSupportRoot, 'HCI fallback support root'), sourceRoot: undefined }
  }
  throw new Error('This session has no bound support package. Bind a WeCom task directory or configure HCI_SUPPORT_ROOT for standalone testing.')
}

export async function resolveSupportRoot(agent, config = {}) {
  return (await resolveEvidenceRoots(agent, config)).root
}

function runBridge(config, root, sourceRoot, operation, args, signal) {
  return new Promise((resolveResult, reject) => {
    const child = spawn(config.command, [
      ...config.commandArgs,
      '--support-root', root,
      ...(sourceRoot === undefined ? [] : ['--source-root', sourceRoot]),
      operation,
    ], {
      cwd: config.cwd,
      env: { ...process.env, PYTHONUNBUFFERED: '1', PYTHONPATH: config.pythonPath },
      stdio: ['pipe', 'pipe', 'pipe'],
    })
    const stdout = []
    const stderr = []
    let bytes = 0
    let settled = false
    const finish = (error, value) => {
      if (settled) return
      settled = true
      signal?.removeEventListener('abort', abort)
      if (error) reject(error)
      else resolveResult(value)
    }
    const abort = () => {
      child.kill('SIGTERM')
      finish(new Error('HCI evidence tool call was cancelled'))
    }
    signal?.addEventListener('abort', abort, { once: true })
    child.stdout.on('data', chunk => {
      bytes += chunk.length
      if (bytes > OUTPUT_LIMIT) {
        child.kill('SIGTERM')
        finish(new Error('HCI evidence tool output exceeded 1 MiB'))
      } else stdout.push(chunk)
    })
    child.stderr.on('data', chunk => {
      if (stderr.reduce((sum, item) => sum + item.length, 0) < 64 * 1024) stderr.push(chunk)
    })
    child.on('error', error => finish(error))
    child.on('close', code => {
      if (settled) return
      if (code !== 0) {
        const detail = Buffer.concat(stderr).toString('utf8').trim().split('\n').slice(-4).join('\n')
        finish(new Error(`HCI evidence ${operation} failed (${code}): ${detail || 'no diagnostic'}`))
        return
      }
      try {
        finish(undefined, JSON.parse(Buffer.concat(stdout).toString('utf8')))
      } catch (error) {
        finish(new Error(`HCI evidence ${operation} returned invalid JSON: ${String(error)}`))
      }
    })
    child.stdin.end(JSON.stringify(args))
  })
}

function tool(name, description, parameters, operation, config) {
  const required = []
  const properties = Object.fromEntries(Object.entries(parameters).map(([key, value]) => {
    const { required: isRequired, ...schema } = value
    if (isRequired) required.push(key)
    return [key, schema]
  }))
  return {
    name: `mcp__hci_offline__${name}`,
    description,
    parameters: {
      type: 'object',
      properties,
      required,
      additionalProperties: false,
    },
    output: {
      schema: {},
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
    },
    async execute(args, exec) {
      const roots = await resolveEvidenceRoots(exec.agent, config)
      return runBridge(config, roots.root, roots.sourceRoot, operation, args, exec.signal)
    },
  }
}

export function definitions(config = {}) {
  config = runtimeConfig(config)
  return [
    tool('support_inventory', 'Discover files only in this session\'s bound support package. Inspect metadata first and follow next_offset.', {
      pattern: { type: 'string', description: 'Path glob within the bound package; default *.' },
      offset: { type: 'integer', description: 'Pagination offset; default 0.' },
      limit: { type: 'integer', description: 'Maximum paths; default 100, maximum 200.' },
    }, 'inventory', config),
    tool('support_read', 'Read UTF-8 source lines only from this session\'s bound support package and return an E citation.', {
      path: { type: 'string', required: true, description: 'Relative path returned by support_inventory or support_search.' },
      start_line: { type: 'integer', description: 'One-based starting line; default 1.' },
      line_count: { type: 'integer', description: 'Maximum lines; default 120, maximum 400.' },
    }, 'read', config),
    tool('support_search', 'Literal search only in this session\'s bound support package. No match is not evidence of health.', {
      query: { type: 'string', required: true, description: 'Literal case-sensitive text.' },
      pattern: { type: 'string', description: 'Path glob within the bound package; default *.' },
      limit: { type: 'integer', description: 'Maximum matches; default 30, maximum 100.' },
    }, 'search', config),
  ]
}

export function apply(ctx, config = {}) {
  for (const definition of definitions(config)) ctx.tools.register(definition)
}
