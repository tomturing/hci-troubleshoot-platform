import { fileURLToPath } from 'node:url'
import { resolve } from 'node:path'
import { existsSync } from 'node:fs'

export const name = 'hci-offline-preset'
export const inject = ['agentPresets']

// Harness anchors inserted top-level plugin names, but not plugin names nested
// inside a preset config. Resolve our own local child against this module.
export function resolvePreset(config) {
  const packageRoot = resolve(fileURLToPath(new URL('..', import.meta.url)))
  const knowledgeRoot = config.knowledgeRoot
  const workspaceRoot = config.workspaceRoot
  const fallbackSupportRoot = config.fallbackSupportRoot
  const caseTopN = Number.isSafeInteger(Number(config.caseTopN)) ? Number(config.caseTopN) : Number(process.env.HCI_CASE_TOP_N ?? 3)
  const playbookTopN = Number.isSafeInteger(Number(config.playbookTopN)) ? Number(config.playbookTopN) : Number(process.env.HCI_PLAYBOOK_TOP_N ?? 3)
  if (typeof knowledgeRoot !== 'string' || !knowledgeRoot.trim()) {
    throw new Error('HCI_KNOWLEDGE_ROOT must name an existing local knowledge directory')
  }
  if ((!workspaceRoot || typeof workspaceRoot !== 'string')
    && (!fallbackSupportRoot || typeof fallbackSupportRoot !== 'string')) {
    throw new Error('WECOM_WORKSPACE_ROOT or HCI_SUPPORT_ROOT is required')
  }
  const installedPython = resolve(packageRoot, '.venv/bin/python')
  const pythonPath = resolve(packageRoot, 'src')
  const python = process.env.HCI_DIAGNOSIS_PYTHON
    || (existsSync(installedPython) ? installedPython : '')
  const command = python || 'uv'
  const args = python ? ['-m', 'hci_diagnosis.server']
    : ['run', '--frozen', '--no-sync', '--directory', packageRoot, 'python', '-m', 'hci_diagnosis.server']
  const knowledgeArgs = [...args, '--knowledge-root', resolve(knowledgeRoot)]
  const evidenceArgs = python ? ['-m', 'hci_diagnosis.evidence_bridge']
    : ['run', '--frozen', '--no-sync', '--directory', packageRoot, 'python', '-m', 'hci_diagnosis.evidence_bridge']
  const plugins = config.plugins.map(entry => {
    let resolvedEntry = entry
    if (entry.name === './single-agent.mjs' || entry.name === './evidence-tools.mjs' || entry.name === './flow-gate.mjs') {
      resolvedEntry = { ...resolvedEntry, name: fileURLToPath(new URL(entry.name, import.meta.url)) }
    }
    if (entry.id === 'mcp-hci-offline') {
      resolvedEntry = { ...resolvedEntry, config: {
        ...entry.config,
        command,
        args: knowledgeArgs,
        cwd: packageRoot,
        env: { ...entry.config?.env, PYTHONUNBUFFERED: '1', PYTHONPATH: pythonPath },
      } }
    }
    if (entry.id === 'hci-session-evidence-tools') {
      resolvedEntry = { ...resolvedEntry, config: {
        command,
        commandArgs: evidenceArgs,
        cwd: packageRoot,
        pythonPath,
        workspaceRoot: typeof workspaceRoot === 'string' ? resolve(workspaceRoot) : '',
        ruleWorkspaceRoot: process.env.WECOM_RULE_WORKSPACE_ROOT || '',
        fallbackSupportRoot: typeof fallbackSupportRoot === 'string' && fallbackSupportRoot.trim()
          ? resolve(fallbackSupportRoot) : '',
      } }
    }
    if (entry.id === 'hci-kb-flow-gate') {
      resolvedEntry = { ...resolvedEntry, config: { ...entry.config, caseTopN, playbookTopN } }
    }
    return resolvedEntry
  })
  const {
    knowledgeRoot: _knowledgeRoot,
    workspaceRoot: _workspaceRoot,
    fallbackSupportRoot: _fallbackSupportRoot,
    ...presetConfig
  } = config
  return { ...presetConfig, plugins }
}

export async function apply(ctx, config) {
  await ctx.effect(() => ctx.agentPresets.register(resolvePreset(config)))
}
