// Session-scoped audit ledger for the two-stage HCI KB workflow.
export const name = 'hci-kb-flow-gate'
export const inject = ['tools']

const ledgers = new WeakMap()
const lastToolNames = new WeakMap()
const DEFAULT_TOP_N = 3

function topN(value) {
  const parsed = Number(value)
  return Number.isSafeInteger(parsed) && parsed >= 1 && parsed <= 20 ? parsed : DEFAULT_TOP_N
}

function ledger(agent) {
  let value = ledgers.get(agent)
  if (!value) {
    value = { required: new Set(), read: new Set(), evidence: new Set(), searches: [] }
    ledgers.set(agent, value)
  }
  return value
}

function resultJson(result) {
  const value = result?.value
  const blocks = value?.content ?? result?.content ?? []
  const text = blocks.find(block => block?.type === 'text')?.text
  if (typeof text !== 'string') return undefined
  try { return JSON.parse(text) } catch { return undefined }
}

function rememberSearch(agent, result, config) {
  const payload = resultJson(result)
  if (!payload || !Array.isArray(payload.matches)) return
  const name = lastToolNames.get(agent)
  const count = name === 'mcp__hci_offline__playbook_lookup' ? config.playbookTopN : config.caseTopN
  const ids = payload.matches.slice(0, count).map(match => match?.id).filter(id => typeof id === 'string')
  const state = ledger(agent)
  ids.forEach(id => state.required.add(id))
  state.searches.push({ name, ids })
}

export function validateSummary(agent, summary) {
  const state = ledger(agent)
  const missing = [...state.required].filter(id => !state.read.has(id))
  const missingCitations = [...state.read].filter(id => !summary.includes(id))
  const errors = []
  if (missing.length) errors.push(`必须回读这些候选原文后才能收尾: ${missing.join(', ')}`)
  if (missingCitations.length) errors.push(`最终报告必须引用已回读案例: ${missingCitations.join(', ')}`)
  if (state.evidence.size > 0 && !summary.includes('E:')) errors.push('最终报告必须包含当前支持包 E 引用')
  return { valid: errors.length === 0, errors, required: [...state.required], read: [...state.read], evidence: [...state.evidence] }
}

export function apply(ctx, config = {}) {
  const limits = {
    caseTopN: topN(config.caseTopN),
    playbookTopN: topN(config.playbookTopN),
  }
  ctx.on('tools/execute', async (exec, next) => {
    const result = await next()
    if (exec.agent && (exec.name === 'mcp__hci_offline__case_search'
      || exec.name === 'mcp__hci_offline__playbook_lookup')) {
      lastToolNames.set(exec.agent, exec.name)
      rememberSearch(exec.agent, result, limits)
    }
    if (exec.agent && exec.name === 'mcp__hci_offline__knowledge_read') {
      const id = exec.arguments?.asset_id
      if (typeof id === 'string' && !result.isError) ledger(exec.agent).read.add(id)
    }
    if (exec.agent && (exec.name === 'mcp__hci_offline__support_read'
      || exec.name === 'mcp__hci_offline__support_search')) {
      const payload = resultJson(result)
      if (payload?.citation_id || (Array.isArray(payload?.matches) && payload.matches.length)) {
        const state = ledger(exec.agent)
        if (payload.citation_id) state.evidence.add(payload.citation_id)
        for (const match of payload.matches ?? []) if (match?.source_sha256) state.evidence.add(`E:${match.source_sha256}`)
      }
    }
    return result
  })

  ctx.tools.register({
    name: 'hci_finalize',
    description: 'Validate the complete HCI report before final output. Call only after all required Case/Playbook candidates have been read and the report contains their IDs plus current E citations.',
    parameters: {
      type: 'object',
      properties: { summary: { type: 'string', description: 'The complete final Markdown report.' } },
      required: ['summary'],
      additionalProperties: false,
    },
    output: {
      schema: { type: 'object' },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
    },
    async execute(args, exec) {
      const summary = String(args.summary ?? '')
      const result = validateSummary(exec.agent, summary)
      if (!result.valid) return { validated: false, ...result, instruction: '继续回读缺失原文或补充 E 引用，验证通过后再次调用 hci_finalize。' }
      return { validated: true, ...result, instruction: '验证通过，可以输出 summary。' }
    },
  })
}
