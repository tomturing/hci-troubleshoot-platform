# HCI 单 Agent 离线诊断：首版工具接入

状态：Harness 组合包 0.4.1、Python 核心 0.2.0，2026-11-13。HCI Preset 继承 Standard 的 Agent 能力，再叠加本地知识、会话级支持包工具和 KB 多案例收尾门禁。
尚未完成真实支持包的模型盲测、案件账本、报告程序校验或生产发布。

## 已实现

一个 Harness 诊断 Agent，通过本地 stdio MCP 调用确定性 Python 工具。MCP 服务不调用模型、
不连接 HCI 节点、不加载 ops-agent 的凭据或部署配置。模型仍由 Harness 的实际路由提供，
“离线”指支持包取证方式，不表示模型一定在本机运行。

| 工具 | 用途 |
|---|---|
| `knowledge_status` | 知识快照、候选状态、案例数量和实际绑定的支持包范围 |
| `case_search` | 全库 BM25＋字面字段检索；分类仅加权，不过滤未知/其他分类 |
| `playbook_lookup` | 按症状、错误查询 SOP |
| `knowledge_read` | 按稳定本地 ID 分页读取原文，返回 K 引用、版本与来源限制 |
| `support_inventory` | 发现实际包内路径，分页并保留跳过项 |
| `support_search` | 有预算的字面检索，显式返回扫描范围、截断、二进制/超限缺口 |
| `support_read` | 只读原文，返回行号、SHA-256 和 E 引用 |
| `hci_finalize` | 收尾门禁；检查检索候选是否按 Top N 回读，以及最终报告是否包含 K/E 引用 |

收尾门禁默认要求每次检索回读 Top 3 Case 和 Top 3 Playbook。可通过 `HCI_CASE_TOP_N`、
`HCI_PLAYBOOK_TOP_N` 或 Preset 配置调整，范围为 1–20。

知识默认使用现有 `ops-agent/ops-claude-sdk/data/hci-knowledge-reorganized-v3`。
首次加载校验三个 manifest 的数量、每份 Case/SOP 身份和全文哈希；当前包为 3,201 Case＋133 SOP。
manifest 的 `output_sha256` 按 LF 校验，同时返回实际字节哈希，兼容本地 CRLF 检出。
原文每次回读重新校验；更新知识包后重启服务，使索引与新快照一致。

Case/SOP 保持 `candidate/draft` 等原状态，命中分数不表示根因置信度。`knowledge_read` 返回的是
现有 v3 加工件正文，不能据此宣称已经读取原始 Support 网页的图片和附件。
取证、版本、适用条件及方案来源仍需核验；首版没有受信方案发布或自动处置能力。

## 插件包与运行方式

`package.json` 声明 `dsh.bundle.patch`，`cordis.patch.yml` 注册 HCI 单 Agent Preset。
安装到 Harness Web profile 后，预设自带知识工具、会话级取证工具、原生工具执行器和访问限制。
Python 服务是插件内的确定性知识/取证核心，仍由 Harness 的 Agent 发起每次工具调用。
历史知识库与当前支持包按路径显式绑定，未随 npm 包分发。

从本仓库源码安装到已配置的 Harness Web profile，例如：

```bash
cd /path/to/deepseek-harness
pnpm dsh plugin --profile web add /absolute/path/to/hci-agent-playbook/hci-diagnosis
```

安装后的插件目录需先执行 `uv sync --frozen --no-editable` 安装随包携带的 Python 核心与锁定依赖。
设置 `HCI_KNOWLEDGE_ROOT` 为 v3 知识包目录。企微使用时设置 `WECOM_WORKSPACE_ROOT`，
支持包由每个会话持久化的 `wecomTaskDirectory` 和规则物化目录自动绑定；规则物化目录是本次分析根，
其中的文件软链接必须解析到 `WECOM_WORKSPACE_ROOT/Q工单目录`，`HCI_SUPPORT_ROOT` 仅用于独立 Web 单包测试。
启动 Web profile 并选择 **HCI 单 Agent 离线诊断**。企微通道设置 `WECOM_AGENT_PRESET=hci-offline`。
插件优先调用安装目录的 `.venv/bin/python`，并显式注入插件自身的 `src` 到 `PYTHONPATH`；找不到时回退到 `uv run --frozen --no-sync`，
启动阶段不会自行安装依赖。也可用 `HCI_DIAGNOSIS_PYTHON` 显式指定解释器。
独立 Web 单包测试更换 `HCI_SUPPORT_ROOT` 后需重启并新建会话；企微群按各自持久化的目录独立绑定。

三个插件协同启动的环境变量示例：

```bash
WECOM_WORKSPACE_ROOT=/path/to/workspace \
WECOM_RULE_WORKSPACE_ROOT=/path/to/work-ticket-rules \
WECOM_AGENT_PRESET=hci-offline \
HCI_KNOWLEDGE_ROOT=/path/to/hci-knowledge-reorganized-v3 \
pnpm dsh --profile web --host 127.0.0.1 --port 3082 --no-open
```

企微群首次使用 `目录：Q工单目录；问题：故障描述` 建立永久工单绑定。此模式无需设置
`HCI_SUPPORT_ROOT`；该变量只用于没有 WeCom 工单绑定的独立 Web 测试。

以下开发启动器会自动设置这些路径并使用源码检出，无需先安装 npm 包：

```bash
bash integration/start-harness.sh /path/to/deepseek-harness /path/to/expanded-support-package
```

## 安装与验证

需要 Python 3.11+、uv；本版支持包读取使用 POSIX 文件描述符，面向 macOS/Linux。
在本目录运行：

```bash
uv sync --frozen
.venv/bin/python -m pytest -q
node scripts/harness-smoke.mjs /path/to/deepseek-harness
```

最后一项使用已经安装依赖并构建库的 Harness 源码检出，实际加载其工具注册器、原生执行器和 MCP Client。
它用现有全量知识包与仓库合成支持包验证 4 个共享知识工具、3 个会话取证工具、问询保留、作用域隔离、禁止子 Agent 和越界拒绝；没有模型调用。
依赖安装可以联网，安装完成后的知识查询与文本取证不需要网络。跨操作系统交付需另备对应依赖包。

## 使用

开发启动器默认打开 `http://127.0.0.1:3082`，新建会话并选择 **HCI 单 Agent 离线诊断**。
它不替换默认 Preset 或模型配置。可设置 `HCI_HARNESS_PORT` 改端口，
设置 `HCI_KNOWLEDGE_ROOT` 指向另一份符合相同 manifest 契约的 HCI 知识包。
该启动方式需目标 Harness 的 Web profile 已可用；适配验证版本见 `VALIDATION.md`。

先发：

> 请核对当前支持包范围和采集缺口，然后根据我描述的问题分析；结论保留证据和案例出处。

再提供故障现象、目标 VM/主机、时间范围。首次查询会加载索引。
这个 Preset 暴露上述八个 HCI 工具，并保留 `ask_user_question` 与企微会话动态注册的 `wecom_send_file`；
通用 shell、通用文件工具、在线设备、其他外部 MCP 和子 Agent 被隐藏。
程序 guard 是执行边界，提示词负责诊断策略。首版问询使用普通对话。

**范围绑定规则：** 企微群首次提交 `目录：Q...；问题：...` 后，WeCom 将相对目录持久化到会话；
每次取证都在 `WECOM_WORKSPACE_ROOT` 下重新解析并验证该目录。不同群可并行绑定不同工单，恢复会话继续使用原绑定。
规则版本和分析目录由 Session BI 管理，HCI 取证工具直接读取真实工单目录，不跟随规则分析目录中的软链接。

可以单独启动 MCP 服务供兼容客户端使用：

```bash
.venv/bin/python -m hci_diagnosis.server \
  --knowledge-root ../ops-agent/ops-claude-sdk/data/hci-knowledge-reorganized-v3 \
  --support-root /path/to/expanded-support-package
```

## 支持包范围与限制

- 当前接收**已经解压的 UTF-8 文本目录**；配置 JSON、TSV、日志等按原文读取。
- 原文路径从 inventory/search 获取，文件与目录软链、路径穿越和特殊文件拒绝读取。
- 单文件最多 16 MiB，单次搜索最多读取 64 MiB；清单最多遍历 20,000 个条目。
  分页、长行、编码错误、二进制和预算限制都保留明确状态。搜索片段需再回读上下文才能作证据。
- 原始包应保持稳定只读；本模块不改原件，但不会阻止其他本机进程修改输入。
- 不自动解压嵌套归档，不解析 SQLite、RRD、二进制或图片；对应材料会显示为缺口。
- 自动解析节点/对象/事件时间/采集状态尚未实现，需要 Agent 回读实际 metadata 和原文核对。
  文件 mtime 明确不当作故障发生时间。
- E 标识由支持范围、相对路径、原始字节哈希和行号组成，K 标识由本地知识 ID、修订和行号组成。
  本版没有持久化引用注册表，引用必须保留工具返回的路径、哈希和行号才能独立回查。

## 下一批落地

1. 用授权、未把答案放入输入的真实支持包完成模型试跑；固定模型、规则和知识快照，记录定位正确性与耗时。
2. 根据真实包布局补采集元数据解析、归档/SQLite 等来源适配；优先解决实际阻塞。
3. 在现有 Session BI 会话记录之上补 E/K/C/S 关联，保存反证、未决条件、跨轮修订和正式报告的引用/方案校验。
4. 用独立查询集比较本版与 ops-agent 全量检索策略，再补语义召回或复杂路由。

代码复用边界见 `THIRD_PARTY.md`；验证证据与限制见 `VALIDATION.md`。
