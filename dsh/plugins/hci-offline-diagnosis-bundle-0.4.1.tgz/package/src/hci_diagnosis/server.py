"""MCP stdio adapter. It never creates an LLM client or connects to a device."""
from __future__ import annotations

import argparse
from pathlib import Path

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

from .evidence import EvidenceStore
from .knowledge import KnowledgeStore


def create_server(knowledge: KnowledgeStore, evidence: EvidenceStore | None = None) -> FastMCP:
    server = FastMCP("hci_offline", instructions=(
        "HCI offline reference and evidence tools. Knowledge is historical, never current evidence. "
        "Read original sources before citing; no match/absent files are not exclusion. "
        "Candidate knowledge requires applicability and source review before solution use. "
        "Use only this server's configured support scope; it does not follow the UI workspace automatically."
    ))
    read_only = ToolAnnotations(readOnlyHint=True, destructiveHint=False, openWorldHint=False)

    @server.tool(annotations=read_only)
    def knowledge_status() -> dict:
        """Inspect the loaded knowledge revision, release state, counts and support scope."""
        return {
            "knowledge": knowledge.status(),
            "evidence": evidence._scope() if evidence is not None else {
                "binding": "session_scoped",
                "usage": "Use support tools; their root is resolved from the calling Harness session.",
            },
        }

    @server.tool(annotations=read_only)
    def case_search(query: str, category: str = "", limit: int = 8) -> dict:
        """Search all historical HCI cases. Category boosts ranking, never excludes other cases. Scores are not confidence."""
        return knowledge.search(query, category=category, limit=limit)

    @server.tool(annotations=read_only)
    def playbook_lookup(query: str, limit: int = 5) -> dict:
        """Find HCI SOPs by symptom or error. Read the returned id before using branches or checks."""
        return knowledge.search(query, kind="playbook", limit=limit)

    @server.tool(annotations=read_only)
    def knowledge_read(asset_id: str, start_line: int | None = None, line_count: int = 160) -> dict:
        """Read original Markdown with K citation, applicability and source status. Follow next_line until the required context is complete."""
        return knowledge.read(asset_id, start_line=start_line, line_count=line_count)

    if evidence is not None:
        @server.tool(annotations=read_only)
        def support_inventory(pattern: str = "*", offset: int = 0, limit: int = 100) -> dict:
            """Discover files in the selected expanded support package. Inspect metadata first; follow next_offset."""
            return evidence.inventory(pattern, offset, limit)

        @server.tool(annotations=read_only)
        def support_read(path: str, start_line: int = 1, line_count: int = 120) -> dict:
            """Read UTF-8 original lines with E citation and source hash. Paths must come from this package; no symlinks or commands."""
            return evidence.read(path, start_line, line_count)

        @server.tool(annotations=read_only)
        def support_search(query: str, pattern: str = "*", limit: int = 30) -> dict:
            """Literal case-sensitive search in scoped text files. Returns coverage gaps/skips. Read surrounding lines before citing."""
            return evidence.search(query, pattern, limit)

    return server


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--knowledge-root", type=Path, required=True)
    parser.add_argument("--support-root", type=Path)
    args = parser.parse_args()
    evidence = EvidenceStore(args.support_root) if args.support_root is not None else None
    create_server(KnowledgeStore(args.knowledge_root), evidence).run(transport="stdio")


if __name__ == "__main__":
    main()
