"""Bounded reads of an explicitly selected, already-expanded support package."""
from __future__ import annotations

import fnmatch
import os
import stat
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from os.path import realpath

from .knowledge import bounded_int, digest

MAX_SOURCE_BYTES = 16 * 1024 * 1024
MAX_SEARCH_BYTES = 64 * 1024 * 1024
MAX_FILES = 20000


class EvidenceStore:
    def __init__(self, root: Path, allowed_symlink_root: Path | None = None):
        self.root = root.resolve(strict=True)
        if not self.root.is_dir():
            raise ValueError("Support root must be an already-expanded directory")
        self.allowed_symlink_root = (
            allowed_symlink_root.resolve(strict=True) if allowed_symlink_root is not None else None
        )
        if self.allowed_symlink_root is not None and not self.allowed_symlink_root.is_dir():
            raise ValueError("Allowed symlink root must be a directory")
        self.scope_id = digest(str(self.root).encode())[:20]

    def _scope(self):
        return {"scope_id": self.scope_id, "support_root": str(self.root),
                "source_root": str(self.allowed_symlink_root) if self.allowed_symlink_root is not None else None,
                "observed_at": datetime.now(timezone.utc).isoformat(),
                "collection_status": "unknown; inspect metadata/summary and files/commands manifests",
                "usage": "File absence/no match does not establish product health; timestamps must be read from source"}

    def _inventory(self):
        paths, skipped = [], []
        def walk_error(error):
            skipped.append({"path": str(error.filename), "reason": "inventory_error"})

        for directory, dirs, files in os.walk(self.root, followlinks=False, onerror=walk_error):
            dirs.sort()
            for name in list(dirs):
                if (Path(directory) / name).is_symlink():
                    dirs.remove(name)
                    skipped.append({"path": str((Path(directory)/name).relative_to(self.root)), "reason": "symlink_directory"})
            for name in sorted(files):
                path = Path(directory) / name
                relative = path.relative_to(self.root).as_posix()
                try:
                    mode = path.lstat().st_mode
                except OSError:
                    skipped.append({"path": relative, "reason": "stat_error"})
                    continue
                if stat.S_ISLNK(mode) and self.allowed_symlink_root is not None:
                    try:
                        target = Path(realpath(path))
                        if target.is_file() and target.is_relative_to(self.allowed_symlink_root):
                            paths.append(relative)
                        else:
                            skipped.append({"path": relative, "reason": "symlink_target_outside_source_root"})
                    except OSError:
                        skipped.append({"path": relative, "reason": "symlink_target_unavailable"})
                elif not stat.S_ISREG(mode):
                    skipped.append({"path": relative, "reason": "non_regular_or_symlink"})
                else:
                    paths.append(relative)
                if len(paths) + len(skipped) >= MAX_FILES:
                    return sorted(paths), skipped, False
        return sorted(paths), skipped, True

    def _read(self, relative: str, byte_limit: int = MAX_SOURCE_BYTES, on_read=None):
        path = PurePosixPath(relative)
        if not relative or path.is_absolute() or ".." in path.parts or "\\" in relative or "\x00" in relative:
            raise ValueError("Expected a relative path inside this support package")
        # Walk directory descriptors with O_NOFOLLOW: symlink traversal is denied
        # even if an intermediate directory is swapped after inventory creation.
        fd = os.open(self.root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            for part in path.parts[:-1]:
                next_fd = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
                os.close(fd)
                fd = next_fd
            final_path = self.root / Path(*path.parts)
            if final_path.is_symlink():
                if self.allowed_symlink_root is None:
                    raise ValueError("Symlink source requires an approved source root")
                target = Path(realpath(final_path))
                if not target.is_file() or not target.is_relative_to(self.allowed_symlink_root):
                    raise ValueError("Symlink target is outside the approved source root")
                source_fd = os.open(target, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            else:
                source_fd = os.open(path.parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd)
            with os.fdopen(source_fd, "rb") as stream:
                before = os.fstat(stream.fileno())
                if not stat.S_ISREG(before.st_mode):
                    raise ValueError("Only regular files can be read")
                if before.st_size > byte_limit:
                    raise ValueError("Source exceeds per-file or remaining search byte budget; prepare a scoped extract with provenance")
                raw = stream.read(byte_limit + 1)
                if on_read is not None:
                    on_read(len(raw))
                after = os.fstat(stream.fileno())
            if len(raw) > byte_limit or (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                raise ValueError("Source changed during read or exceeds limit")
            if b"\x00" in raw:
                raise ValueError("Binary source unsupported; compressed archives/SQLite require a source adapter")
            text = raw.decode("utf-8")
            return raw, text.splitlines(), before
        finally:
            os.close(fd)

    def inventory(self, pattern: str = "*", offset: int = 0, limit: int = 100):
        bounded_int(offset, 0, MAX_FILES, "offset")
        bounded_int(limit, 1, 200, "limit")
        if len(pattern) > 300:
            raise ValueError("Pattern too long")
        paths, skipped, complete = self._inventory()
        matches = [p for p in paths if fnmatch.fnmatchcase(p, pattern)]
        page = matches[offset:offset+limit]
        next_offset = offset+len(page) if offset+len(page) < len(matches) else None
        return {**self._scope(), "pattern": pattern, "files": page, "matched_count": len(matches),
                "inventory_complete": complete, "next_offset": next_offset,
                "skipped_count": len(skipped), "skipped": skipped[:100],
                "skipped_truncated": len(skipped) > 100}

    def read(self, path: str, start_line: int = 1, line_count: int = 120):
        bounded_int(start_line, 1, 10000000, "start_line")
        bounded_int(line_count, 1, 400, "line_count")
        raw, lines, info = self._read(path)
        if start_line > max(1, len(lines)):
            raise ValueError("start_line exceeds source length")
        selected, chars = [], 0
        for number in range(start_line, min(start_line+line_count, len(lines)+1)):
            value = lines[number-1]
            if chars+len(value)+1 > 32000:
                if not selected:
                    raise ValueError("Single source line exceeds read limit")
                break
            selected.append({"line": number, "text": value})
            chars += len(value)+1
        end = selected[-1]["line"] if selected else 0
        sha = digest(raw)
        return {**self._scope(), "path": path, "source_sha256": sha,
                "citation_id": f"E:{self.scope_id}:{digest(path.encode())[:12]}:{sha[:16]}:L{start_line}-{end}",
                "start_line": start_line, "end_line": end, "total_lines": len(lines), "lines": selected,
                "file_mtime_ns": info.st_mtime_ns, "mtime_is_event_time": False,
                "truncated": end < len(lines), "next_line": end+1 if end < len(lines) else None}

    def search(self, query: str, pattern: str = "*", limit: int = 30):
        bounded_int(limit, 1, 100, "limit")
        if not query or len(query) > 1000 or len(pattern) > 300:
            raise ValueError("Expected literal query (1-1000 chars) and a bounded path pattern")
        paths, skipped, complete = self._inventory()
        matches, scanned, used = [], 0, 0
        def charge_bytes(count):
            nonlocal used
            used += count

        candidates = [p for p in paths if fnmatch.fnmatchcase(p, pattern)]
        for path in candidates:
            if used >= MAX_SEARCH_BYTES or len(matches) >= limit:
                complete = False
                break
            try:
                raw, lines, _ = self._read(path, min(MAX_SOURCE_BYTES, MAX_SEARCH_BYTES-used), charge_bytes)
            except (OSError, ValueError, UnicodeError) as exc:
                skipped.append({"path": path, "reason": type(exc).__name__ + ": " + str(exc)})
                continue
            scanned += 1
            sha = digest(raw)
            for number, line in enumerate(lines, 1):
                if query in line:
                    matches.append({"path": path, "line": number, "text": line[:1200],
                                    "excerpt_truncated": len(line) > 1200, "source_sha256": sha,
                                    "needs_read": True})
                    if len(matches) >= limit:
                        complete = False
                        break
        return {**self._scope(), "query": query, "pattern": pattern, "matches": matches,
                "search_complete": complete and not skipped, "files_scanned": scanned,
                "candidate_files": len(candidates), "bytes_scanned": used,
                "skipped_count": len(skipped), "skipped": skipped[:100],
                "skipped_truncated": len(skipped) > 100,
                "interpretation": "Search hits are navigation; read context before citing. No hit is not exclusion."}
