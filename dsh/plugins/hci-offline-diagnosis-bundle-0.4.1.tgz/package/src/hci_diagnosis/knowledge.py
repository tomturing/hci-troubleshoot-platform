"""Manifest-backed, read-only v3 knowledge access, independent of the Agent SDK."""
from __future__ import annotations

import hashlib
import re
import unicodedata
from pathlib import Path
from typing import Any

import yaml
from rank_bm25 import BM25Okapi

from .vendor import v3_sections

Loader = getattr(yaml, "CSafeLoader", yaml.SafeLoader)
MAX_DOCUMENT_BYTES = 4 * 1024 * 1024
FIELDS = (("title", 4), ("告警信息", 4), ("问题描述", 3), ("根因", 2),
          ("有效排查步骤", 1), ("解决方案", 1), ("分类路径", 1))
GENERIC_LITERAL_TERMS = frozenset({
    "hci", "acloud", "服务器", "应用", "系统", "平台", "虚拟机", "主机", "问题", "异常", "失败",
})
MIN_RELATIVE_BM25_SCORE = 0.5
MIN_BM25_SCORE = 2.0


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def tokenize(value: str) -> list[str]:
    """Upstream's NFKC, ASCII words and Chinese uni/bi/trigram approach."""
    words = re.findall(r"[\u4e00-\u9fff]+|[^\W_]+", unicodedata.normalize("NFKC", value).casefold())
    tokens = []
    for word in words:
        if re.fullmatch(r"[\u4e00-\u9fff]+", word):
            tokens.extend(word[i:i+n] for n in (1, 2, 3) for i in range(len(word)-n+1))
        else:
            tokens.append(word)
    return tokens


def bounded_int(value: int, low: int, high: int, name: str) -> int:
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f"{name} must be between {low} and {high}")
    return value


class KnowledgeStore:
    def __init__(self, root: Path):
        self.root = root.resolve(strict=True)
        self.assets: dict[str, dict[str, Any]] = {}
        self.documents: dict[str, tuple[dict, str, int]] = {}
        self.release = self._yaml("manifests/release-manifest.yaml")
        manifests = [self._yaml(f"manifests/{kind}-manifest.yaml") for kind in ("case", "playbook")]
        manifest_bytes = b"".join(self._bytes(f"manifests/{kind}-manifest.yaml") for kind in ("release", "case", "playbook"))
        self.snapshot = digest(manifest_bytes)
        for kind, manifest in zip(("case", "playbook"), manifests):
            assets = manifest.get("assets", [])
            if not assets or manifest.get("count") != len(assets) or self.release.get("counts", {}).get(kind + "s") != len(assets):
                raise ValueError(f"Invalid {kind} manifest count")
            for asset in assets:
                asset = dict(asset, kind=kind)
                asset_id = asset["id"]
                if asset_id in self.assets:
                    raise ValueError(f"Duplicate asset: {asset_id}")
                self.assets[asset_id] = asset
                self.documents[asset_id] = self._document(asset)
        self.indexes = {kind: self._index(kind) for kind in ("case", "playbook")}

    def _bytes(self, relative: str) -> bytes:
        path = (self.root / relative).resolve(strict=True)
        if not path.is_relative_to(self.root) or not path.is_file():
            raise ValueError("Knowledge path escapes the selected snapshot")
        with path.open("rb") as stream:
            data = stream.read(MAX_DOCUMENT_BYTES + 1)
        if len(data) > MAX_DOCUMENT_BYTES:
            raise ValueError("Knowledge document exceeds size limit")
        return data

    def _yaml(self, relative: str) -> dict:
        value = yaml.load(self._bytes(relative), Loader=Loader)
        if not isinstance(value, dict):
            raise ValueError(f"Expected mapping: {relative}")
        return value

    def _document(self, asset: dict) -> tuple[dict, str, int]:
        raw = self._bytes(asset["output"])
        # This checkout uses CRLF. Verify the declared LF digest explicitly;
        # preserve and expose the actual byte digest separately for citations.
        normalized = raw.replace(b"\r\n", b"\n")
        if digest(normalized) != asset["output_sha256"]:
            raise ValueError(f"Knowledge hash mismatch: {asset['id']}")
        text = normalized.decode("utf-8")
        match = re.match(r"\A---\n(.*?)\n---(?:\n|$)", text, re.S)
        if not match:
            raise ValueError(f"Missing frontmatter: {asset['id']}")
        meta = yaml.load(match[1], Loader=Loader)
        if not isinstance(meta, dict) or meta.get("id") != asset["id"] or meta.get("knowledge_type") != asset["kind"]:
            raise ValueError(f"Frontmatter identity mismatch: {asset['id']}")
        asset["byte_sha256"] = digest(raw)
        return meta, text, text[:match.end()].count("\n") + 1

    def _index(self, kind: str):
        entries = []
        evidence = []
        for asset_id, asset in self.assets.items():
            if asset["kind"] != kind:
                continue
            meta, text, body_line = self.documents[asset_id]
            sections = v3_sections.case_section_texts(meta) if kind == "case" else {
                "问题描述": "\n".join(meta.get("entry", {}).get("problem_patterns", [])),
                "有效排查步骤": "\n".join(text.splitlines()[body_line-1:]),
            }
            entries.append({"id": asset_id, "title": str(meta.get("title", asset_id)), "sections": sections})
            evidence.append(v3_sections.case_evidence_texts(meta))
        if kind == "case":
            v3_sections.filter_ubiquitous_evidence(entries, evidence)
        corpus = []
        for entry in entries:
            fields = dict(entry["sections"], title=entry["title"])
            entry["fields"] = fields
            corpus.append([token for key, weight in FIELDS for token in tokenize(fields.get(key, "")[:6000]) * weight] or ["empty"])
        return entries, BM25Okapi(corpus)

    def status(self) -> dict:
        return {"schema": "hci-knowledge-v1", "release_id": self.release.get("release_id"),
                "snapshot_sha256": self.snapshot, "counts": self.release["counts"],
                "release_status": self.release.get("release_status", "unknown"),
                "activation": self.release.get("activation", {}),
                "usage": "Historical reference only; not current evidence or automatic action authorization",
                "retrieval": "bm25+literal-field-match+soft-category-boost-v1"}

    def _reference(self, asset_id: str) -> dict:
        asset = self.assets[asset_id]
        meta, _, body_line = self.documents[asset_id]
        return {"id": asset_id, "kind": asset["kind"], "title": meta.get("title", asset_id),
                "path": asset["output"], "revision": asset["output_sha256"],
                "byte_sha256": asset["byte_sha256"], "body_start_line": body_line,
                "local_case_id": asset.get("case_id", ""), "remote_id": asset.get("remote_id", ""),
                "support_url": v3_sections.case_support_url(meta),
                "applicability": meta.get("applicability", {}),
                "lifecycle": meta.get("lifecycle", "unknown"),
                "source_state": meta.get("provenance", {}).get("source_state", "unknown"),
                "historical_prior_only": True, "solution_eligibility": "requires_source_and_applicability_review",
                "categories": list(v3_sections.category_fields(meta)),
                "case_categories": asset.get("case_categories", [])}

    def search(self, query: str, *, kind: str = "case", category: str = "", limit: int = 8) -> dict:
        bounded_int(limit, 1, 20, "limit")
        if kind not in self.indexes or not query.strip() or len(query) > 2000 or len(category) > 100:
            raise ValueError("Provide a nonempty query (max 2000 chars) and kind case/playbook")
        query = query.strip()
        tokens = list(dict.fromkeys(tokenize(query)))[:160]
        if not tokens:
            raise ValueError("Query contains no searchable text")
        entries, index = self.indexes[kind]
        scores = index.get_scores(tokens)
        # Literal phrase boosts preserve error codes, paths, and exact user words.
        phrases = [query.casefold()] + [
            value for value in (x.casefold() for x in re.split(r"\s+", query) if len(x) >= 2)
            if value not in GENERIC_LITERAL_TERMS
        ]
        top_bm25 = max((max(0.0, float(value)) for value in scores), default=0.0)
        bm25_floor = max(MIN_BM25_SCORE, top_bm25 * MIN_RELATIVE_BM25_SCORE)
        results = []
        for entry, bm25 in zip(entries, scores):
            matched = [key for key, value in entry["fields"].items() if any(p in value.casefold() for p in phrases)]
            bm25_score = max(0.0, float(bm25))
            if bm25_score < bm25_floor and not matched:
                continue
            score = bm25_score + 20 * len(matched) + (60 if "title" in matched else 0)
            ref = self._reference(entry["id"])
            boosted = bool(category and category in ref["categories"] + ref["case_categories"])
            if boosted:
                score *= 1.2
            results.append(dict(ref, score=round(score, 4), matched_fields=matched,
                                category_boosted=boosted, excerpt=entry["sections"].get("问题描述", "")[:350]))
        results.sort(key=lambda item: (-item["score"], item["id"]))
        return {**self.status(), "query": query, "category_policy": "soft_boost_only",
                "bm25_floor": round(bm25_floor, 4),
                "match_count": len(results), "matches": results[:limit], "truncated": len(results) > limit}

    def read(self, asset_id: str, *, start_line: int | None = None, line_count: int = 160) -> dict:
        bounded_int(line_count, 1, 400, "line_count")
        if asset_id not in self.assets:
            raise ValueError("Unknown knowledge id; use the id returned by search, not a display id or path")
        asset = self.assets[asset_id]
        # Re-verify on read so an old index cannot cite a changed document.
        meta, text, body_line = self._document(asset)
        lines = text.splitlines()
        start = body_line if start_line is None else bounded_int(start_line, 1, len(lines), "start_line")
        selected = []
        chars = 0
        for number in range(start, min(start + line_count, len(lines) + 1)):
            value = lines[number-1]
            if chars + len(value) + 1 > 40000:
                if not selected:
                    raise ValueError("Single knowledge line exceeds read limit")
                break
            selected.append({"line": number, "text": value})
            chars += len(value) + 1
        end = selected[-1]["line"] if selected else start-1
        return {**self.status(), **self._reference(asset_id),
                "citation_id": f"K:{asset_id}:{asset['output_sha256'][:16]}:L{start}-{end}",
                "start_line": start, "end_line": end, "total_lines": len(lines), "lines": selected,
                "truncated": end < len(lines), "next_line": end+1 if end < len(lines) else None,
                "knowledge_gaps": meta.get("knowledge_gaps", []),
                "external_media_included": False}
