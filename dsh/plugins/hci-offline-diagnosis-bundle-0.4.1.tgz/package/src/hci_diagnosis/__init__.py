"""HCI single-agent offline diagnosis tools; no model or device connections."""

