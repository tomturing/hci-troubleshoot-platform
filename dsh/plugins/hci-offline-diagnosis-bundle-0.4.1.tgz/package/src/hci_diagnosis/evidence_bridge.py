"""One-shot JSON bridge used by Harness's session-scoped evidence tools."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .evidence import EvidenceStore


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--support-root", type=Path, required=True)
    parser.add_argument("--source-root", type=Path)
    parser.add_argument("operation", choices=("inventory", "read", "search"))
    args = parser.parse_args()
    payload = json.load(sys.stdin)
    if not isinstance(payload, dict):
        raise ValueError("tool arguments must be a JSON object")
    store = EvidenceStore(args.support_root, args.source_root)
    if args.operation == "inventory":
        result = store.inventory(
            str(payload.get("pattern", "*")),
            int(payload.get("offset", 0)),
            int(payload.get("limit", 100)),
        )
    elif args.operation == "read":
        result = store.read(
            str(payload.get("path", "")),
            int(payload.get("start_line", 1)),
            int(payload.get("line_count", 120)),
        )
    else:
        result = store.search(
            str(payload.get("query", "")),
            str(payload.get("pattern", "*")),
            int(payload.get("limit", 30)),
        )
    json.dump(result, sys.stdout, ensure_ascii=False, separators=(",", ":"))
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
