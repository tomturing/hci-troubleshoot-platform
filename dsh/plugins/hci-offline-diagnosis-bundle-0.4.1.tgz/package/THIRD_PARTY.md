# 上游复用记录

`src/hci_diagnosis/vendor/v3_sections.py` 来自本工作区
`ops-agent/ops-claude-sdk/ops_sdk_poc/v3_sections.py`，仅统一 CRLF 为 LF，保留原 SPDX MIT 标记。
归一化文件 SHA-256：`c70d67590bdbd6b9dfb793381ca8a9dccf1c7c065631619faf0611f33edb2c9d`。
复用了案例字段提取、来源链接提取、分类读取和全库模板证据过滤。

`knowledge.py` 的中文字符 n-gram、BM25 字段权重及分类 1.2 倍软加权参考上游
`ops_sdk_poc/tools.py`；适配层独立实现，不加载上游全局配置、Claude SDK、线上 QA、设备工具或模型。
本版没有迁入上游全部规则分、词典扩展、症状族强制候选和会话原话加权，不声称与上游排序完全一致。
后续需用独立标注的查询集比较召回，再决定迁入哪些策略。

知识正文不复制进本模块，由启动参数指向既有知识包。保留每条 manifest 的来源身份、内容修订、
本地 ID、远端 ID 和原文行号；不重新生成或发布知识包。

会话级目录绑定读取 Harness `Agent.session.header.wecomTaskDirectory`，该字段由
`deepseek-harness-wecom` 持久化。工具执行时再用 `realpath` 验证它仍位于 `WECOM_WORKSPACE_ROOT` 内；
Python 取证层继续拒绝路径穿越、软链接与特殊文件。

MCP 使用官方 Python `mcp` 包；检索使用 `rank-bm25`，YAML 使用 PyYAML。
版本和分发文件哈希固定于 `uv.lock`。
