export const name = 'hci-weknora-single-agent'
export const inject = ['tools', 'systemPrompt']

export const TOOL_NAMES = [
  'hci_kb_list_knowledge_bases',
  'hci_kb_search',
  'hci_kb_read_document',
  'hci_quick_ask',
  'hci_reasoning_ask',
  'mcp__hci_weknora__support_inventory',
  'mcp__hci_weknora__support_read',
  'mcp__hci_weknora__support_search',
  'hci_evidence_status',
]

const FORBIDDEN = new Set(['subagent', 'subagent_fork'])
const UNSCOPED = new Set(['bash', 'pwsh', 'read', 'write', 'edit', 'glob', 'grep'])
const CHILD_TOOLS = new Set([...TOOL_NAMES.filter(name => name !== 'hci_evidence_status'), 'structured_output'])

export function apply(ctx) {
  ctx.on('agent/created', ({ agent }) => {
    agent.ctx.systemPrompt.section({
      name: 'tool:workflow',
      order: agent.ctx.systemPrompt.getSectionOrder('TOOL_WORKFLOW'),
      text: 'Use workflow when independent read-only evidence or knowledge checks in this HCI case benefit from concurrent agents. Delegate at most three direct children, await every result, and verify their evidence before the final diagnosis. Do not use workflow for serial or trivial steps.',
    })
  })
  if (typeof ctx.tools.presentAs === 'function') ctx.tools.presentAs('native')
  const inherited = ctx.tools.schemas().map(tool => tool.name)
  const denied = inherited.filter(name => FORBIDDEN.has(name) || UNSCOPED.has(name))
  if (denied.length) ctx.tools.restrict({ deny: denied })
  ctx.tools.guard(exec => {
    if (FORBIDDEN.has(exec.name)) {
      return 'HCI diagnosis delegates only through the bounded workflow tool'
    }
    const header = exec.agent?.session?.header
    if (header?.origin === 'subagent' || (header?.delegationDepth ?? 0) > 0) {
      if (header?.origin !== 'subagent' || header?.delegationDepth !== 1 || !header?.parentSession) {
        return 'HCI diagnosis only permits direct workflow children of the root agent'
      }
      if (!CHILD_TOOLS.has(exec.name)) {
        return 'HCI workflow children may only use task-bound read-only evidence and knowledge tools'
      }
    }
    if (UNSCOPED.has(exec.name)) {
      return 'HCI diagnosis must use the task-bound support tools; unscoped shell and filesystem tools are disabled'
    }
    return undefined
  })
}
