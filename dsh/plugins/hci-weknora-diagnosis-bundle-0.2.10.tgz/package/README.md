# HCI 诊断（WeKnora）插件

状态：0.2.8，2026-11-27。该目录是当前用于替代旧 `hci-diagnosis/` 实现及其
`hci-offline-diagnosis-bundle` 的新插件；旧目录不修改、不删除，仅作历史对照。部署时只加载一个 HCI Bundle。

## 当前落地范围

- Preset `hci-weknora` 保留通用交互与上下文能力；根 Agent 可通过 workflow 编排最多三个并发、单次最多 20 个 fork 子 Agent。直接委派及无范围 Shell/文件工具被拒绝。
- 知识工具复用官方 `@wxg-prc-cpg/dsh-weknora@0.1.0`。
- 阶段一默认调用 `HCI 案例排查助手`，需要跨案例补查时调用 `HCI 案例深度研判助手`。可按部署或单条机器人消息关闭这两个阶段一案例检索工具。
- 阶段二直接检索 `test` 并回读方案候选。同一文档多个 chunk 只占一个 TopN，默认回读 3 个不同案例。
- 支持包工具改为 Bundle 内原生 Node 工具，不依赖旧插件的 Python MCP。
- 保留 WeCom 工单目录绑定、Session BI 独立的规则/分析目录物化、内部 E 取证标识和 `hci_finalize` 门禁；E 工具不从物化目录取证。子 Agent 仅能使用当前工单的只读证据与知识工具，根 Agent 负责最终判断和报告。
- WeCom 绑定从持久用户标记恢复，E 工具只读取真实案件目录；HCI preset 禁用无范围的 shell/文件工具。
- 子 Agent 从活动根会话读取工单绑定和本轮检索开关，其 E/K 回读记录汇入根 Agent 会话内账本。根 Agent 的 `hci_evidence_status` 检查回读覆盖；确认型结论必须展示当前支持包的相对路径及回读原文，不展示 E 哈希标识或来源行号。路径中的 IPv4 仍由 ip-redactor 脱敏。
- 提供可恢复的 v3 Markdown 导入脚本。

当前门禁仍是会话内兼容门禁，不等同目标架构中的持久化案件核心和固定报告服务。WeKnora 文档 ID
作为本阶段 K 回读和校验标识；最终报告展示原始案例名称，并把原始案例 ID 渲染为指向回读正文“原文链接”的 Markdown 超链接，不展示内部 `knowledge_id` 或案例行号。原始 ID 从回读正文的“案例ID”字段或导入标题前缀提取，缺失时不得用内部 ID 冒充；原文链接缺失时不得编造。稳定 `asset_id/revision`
已写入导入元数据，下一阶段再接入持久化 K 登记表。

阶段一关闭案例检索时，根因定位只引用当前支持包 E 证据；阶段二仍可检索方案案例。阶段二回读后只列适用案例的原名和原始 ID，不改写处置内容。没有适用方案案例时，可给出明确标为“主观建议（未经案例原文支持，尚未执行）”的建议；不适用的检索候选不作为解决方案展示。

workflow 在前台完成并等待所有子 Agent 退出后，根 Agent 才能调用 `hci_finalize`。子 Agent 的活动父会话不可用时，支持包访问和证据登记失败。并行额度只限制一次 workflow，不保证同一工单跨会话的全局互斥；案件级互斥仍需案件核心实现。

0.2.6 在预设插件中覆盖通用 workflow 使用提示，允许当前工单内适合并行的独立只读取证或知识核查；无需修改 Harness 的 `tool-workflow` 配置接口。Web 新会话的工单绑定依赖 Session BI 0.1.26。

0.2.10 归一化知识库正文“原文链接”中一层或多层 Markdown 下划线转义，并把报告中任何独立出现的原始案例 ID 都视为引用，要求每次使用正文提供的 Markdown 原文链接。Web 工单绑定需配套 Session BI 0.1.27。

0.2.7 将用户可见的现场证据改为支持包相对路径和日志原文摘录，原始案例 ID 链接至回读正文的“原文链接”。内部 E 标识继续用于会话内登记，不在最终报告展示；日志路径中的 IPv4 仍由 ip-redactor 脱敏。

0.2.8 要求同一案例 ID 在报告中的每次出现都带原文链接。

## 与旧插件的关系

| 项目 | 旧插件 | 新插件 |
|---|---|---|
| 包名 | `hci-offline-diagnosis-bundle` | `hci-weknora-diagnosis-bundle` |
| Preset | `hci-offline` | `hci-weknora` |
| 知识底座 | 本地 Python BM25/MCP | WeKnora REST＋官方 DSH 插件 |
| 支持包 | Python bridge | 原生 Node 只读工具 |
| 运行要求 | `HCI_KNOWLEDGE_ROOT` | WeKnora URL、test 范围 API Key、两个智能体 ID |

两个 Bundle 都注册 `hci_finalize`，不能在同一个 profile 同时加载。保留旧插件目录不会产生冲突；只要
不在 DSH profile 安装/加载旧 Bundle，并把 `WECOM_AGENT_PRESET` 改为 `hci-weknora` 即可。

## WeKnora 配置

当前本地服务地址为 `http://127.0.0.1:8080/api/v1`。阶段一使用 `test` 文档知识库，当前有 10,196 篇已完成解析的案例。

| 智能体 | 模式 | 主要配置 | 使用时机 |
|---|---|---|---|
| `HCI 案例排查助手` | 快速问答 | `test`；DeepSeek Flash；BGE rerank；TopK 30；rerank 12；输出 6144；联网关闭 | 每个诊断问题的阶段一首轮 |
| `HCI 案例深度研判助手` | 智能推理 | `test`；只开放 search/read/list；8 轮；输出 8192；minimal；联网/MCP/Skill/沙箱关闭 | 首轮过宽、案例冲突或出现新错误链 |

运行 Key 的知识库白名单只有 `test`，权限为 `retrieve`、`chat`、`read_agents`。
两个智能体工具只接受 `query` 和可选的续问 `session_id`。Agent ID、`test` 范围和 `web_search=false` 由部署固定，模型不能在调用参数中覆盖。

## 阶段一如何提问

阶段一案例检索默认开启。部署时可用 `WEKNORA_INVESTIGATION_KB_SEARCH_ENABLED=false`
默认关闭；机器人每条消息可用独立一行字段做单次覆盖：

```text
weknora排查思路是否检索：否
```

取值为“是”或“否”（也接受 `true/false`、`yes/no`、`1/0`），仅影响当前轮。值为“否”时，
Harness 在工具门禁层拒绝 `hci_quick_ask` 和 `hci_reasoning_ask`，但不拒绝现场 E 支持根因方向后的
`hci_kb_search` / `hci_kb_read_document`，因此根因与解决方案阶段仍会检索、回读案例原文。

Harness 保留 VM 名称、工单号、精确时间和日志原文用于本地关联。发给智能体的问题使用下面结构。

原始消息为“虚拟机卡顿，异常时间点 2026-11-18 08:00 左右，异常虚拟机名称 HIS生产库”时，Harness 用名称和时间定位支持包范围，向快速问答发送下面的技术问题。

```text
故障现象：HCI 虚拟机卡顿。
已观察技术信号：尚无确认错误码；CPU、内存、存储、网络指标待核。
影响范围：单台还是同主机多台待核。
任务：基于 test 案例给出最有区分度的只读检查，说明每种结果支持或削弱哪个候选机制，并附实际案例出处。
```

快速问答只有泛化检查表、缺少实际来源、案例适用条件冲突，或日志出现新的错误链时，再问深度研判助手。二次问题包含已观察信号和需要区分的解释，例如“多台 VM 同时出现 IO timeout，如何区分共享存储路径异常和宿主机 CPU 争用”。

智能推理当前会把案例引用以内联 `<kb ...>` 标记写入回答，WeKnora 的独立 `references` 数组可能为空。Harness 在阶段一保留这些内联来源，阶段二仍通过 `hci_kb_read_document` 回读方案原文。

## 导入现有 v3 知识

先做只读盘点：

```bash
node scripts/import-v3.mjs \
  --knowledge-root ../ops-agent/ops-claude-sdk/data/hci-knowledge-reorganized-v3 \
  --case-kb-id <HCI_CASE_KB_ID> \
  --playbook-kb-id <HCI_PLAYBOOK_KB_ID> \
  --dry-run
```

首次小批导入验证：

```bash
WEKNORA_INGEST_API_KEY=<ingest-key> \
node scripts/import-v3.mjs \
  --knowledge-root ../ops-agent/ops-claude-sdk/data/hci-knowledge-reorganized-v3 \
  --case-kb-id <HCI_CASE_KB_ID> \
  --playbook-kb-id <HCI_PLAYBOOK_KB_ID> \
  --state ./weknora-hci-import-state.json \
  --limit 10
```

确认解析、检索和回读后去掉 `--limit`。脚本逐篇保存 state：相同 revision 会跳过，正文变化会更新同一
WeKnora 手工文档，进程中断后可继续。state 包含映射和哈希，不包含 API Key，属于知识发布记录，应备份。
可用 `--type case` 或 `--type playbook` 单独导入一类资产，便于先做分库烟测。
全量导入可增加 `--concurrency 4`；允许范围为 1～8。导入器会对 429/可重试 5xx 做有限重试，
逐资产原子保存 state，并在结束时列出失败资产，重复执行只补缺或更新 revision。

## 安装到 DSH

从本仓库安装新 Bundle：

```bash
cd /path/to/deepseek-harness
pnpm dsh plugin --profile web add \
  /path/to/deepseek-harness-plugins/hci-weknora-diagnosis
```

发布包通过 `npm pack` 生成，`bundleDependencies` 会把 `@wxg-prc-cpg/dsh-weknora@0.1.0` 一并写入 tgz 的
`node_modules`，因此安装 tgz 时不再需要单独的 WeKnora 依赖包，也不会再从 registry 解析该依赖。打包前需保证该依赖已在
本目录的 `node_modules` 中（`npm install --ignore-scripts`）。

环境变量：

```bash
WECOM_WORKSPACE_ROOT=/Users/royin/Downloads/tmp/workspace \
WECOM_RULE_WORKSPACE_ROOT=/Users/royin/Downloads/tmp/work-ticket-rules \
WECOM_AGENT_PRESET=hci-weknora \
WEKNORA_BASE_URL=http://127.0.0.1:8080/api/v1 \
WEKNORA_API_KEY=<test-scoped-runtime-key> \
WEKNORA_KB_CASE_IDS=<TEST_KB_ID> \
WEKNORA_KB_PLAYBOOK_IDS= \
WEKNORA_HCI_AGENT_KB_IDS=<TEST_KB_ID> \
WEKNORA_HCI_QUICK_AGENT_ID=<QUICK_AGENT_ID> \
WEKNORA_HCI_REASONING_AGENT_ID=<REASONING_AGENT_ID> \
WEKNORA_INVESTIGATION_KB_SEARCH_ENABLED=true \
HCI_CASE_TOP_N=3 \
HCI_PLAYBOOK_TOP_N=3 \
pnpm dsh --profile web --host 127.0.0.1 --port 3080 --no-open
```

不再需要 `HCI_KNOWLEDGE_ROOT` 或旧插件内的 Python 虚拟环境。

## 工具

| 工具 | 用途 |
|---|---|
| `hci_kb_list_knowledge_bases` | 核对运行 Key 可见知识库 |
| `hci_quick_ask` | 基于 `test` 生成首轮候选机制与区分性检查 |
| `hci_reasoning_ask` | 基于 `test` 跨案例研判冲突和新错误链 |
| `hci_kb_search` | 阶段二按根因检索 `test` 方案候选 |
| `hci_kb_read_document` | 回读候选文档及相邻 chunk |
| `mcp__hci_weknora__support_inventory` | 盘点当前会话支持包 |
| `mcp__hci_weknora__support_search` | 支持包字面导航搜索 |
| `mcp__hci_weknora__support_read` | 回读原文并签发 E 引用 |
| `hci_finalize` | 检查 TopN 回读和最终 E/K 引用 |

## 本地检查

```bash
pnpm install --ignore-scripts
pnpm test
pnpm run check
pnpm run pack:check
```

全量导入后可校验 manifest、正文 revision 与 state：

```bash
node scripts/verify-import-state.mjs \
  --knowledge-root ../ops-agent/ops-claude-sdk/data/hci-knowledge-reorganized-v3 \
  --state ./weknora-hci-import-state.json
```

加载 DSH `.env` 后可运行真实 WeKnora 检索/回读烟测：`node scripts/real-retrieval-smoke.mjs`。

## 日志收集包自动验证矩阵

`testdata/log-packages/` 提供七类无客户数据的合成收集包：已知案例精确命中、多个已知案例冲突、无精确案例但可类比、完全无 KB、证据不足、相似案例误导和并发双根因。每个包的 `scenario.json` 同时定义现场证据探针和诊断结果验收条件。

```bash
npm run log-packages:generate
npm run log-packages:validate
```

加载真实 WeKnora 运行环境后执行 KB 漂移预检：

```bash
npm run log-packages:validate-kb
```

该检查要求精确场景召回 HCI-44561，类比场景召回 HCI-39058，同时拒绝在标题中出现虚构的 NebulaOS/vortex_scsi“精确案例”。当 KB 新增内容改变这些前提时，矩阵会显式失败并要求重新分类场景。

需要通过当前 WeCom 实例测试时，把场景物化到 `WECOM_WORKSPACE_ROOT`：

```bash
npm run log-packages:materialize -- /path/to/wecom-workspace
node scripts/validate-log-packages.mjs /path/to/wecom-workspace --materialized
```

每个 `scenario.json` 都包含唯一的合成 `task_directory`，可直接用作企微首条消息中的“目录”。目标目录已存在时命令会拒绝覆盖；确认只刷新矩阵自有文件时显式加 `--force`。
物化命令不会复制含验收条件的 `scenario.json`，被测 Agent 只能看到合成现场材料。

真实 Agent 应按 `testdata/log-packages/README.md` 的 JSON 格式保存每个场景的最终结果。`npm run log-packages:validate-results -- /path/to/results` 会检查根因状态、精确/类比/无匹配 KB 关系、必要案例 ID、未知项声明以及每条已断言根因的 E 引用。普通 `npm test` 也会验证全部合成包可被 support 工具完整盘点、检索和引用。

验证记录见 [VALIDATION.md](VALIDATION.md)。整体边界见
[WeKnora 替代架构](../design/hci-single-agent/weknora-replacement-architecture.md)和
[技术设计](../design/hci-single-agent/weknora-replacement-technical-design.md)。
