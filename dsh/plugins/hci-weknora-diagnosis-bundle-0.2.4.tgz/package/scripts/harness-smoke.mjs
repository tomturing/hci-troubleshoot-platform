import assert from 'node:assert/strict'
import { createServer } from 'node:http'
import { createRequire } from 'node:module'
import { readFile } from 'node:fs/promises'
import { resolve, dirname } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const harnessRoot = process.argv[2]
if (!harnessRoot) throw new Error('Usage: node scripts/harness-smoke.mjs /path/to/deepseek-harness')
const packageRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const loadLocal = name => import(pathToFileURL(resolve(packageRoot, `integration/${name}.mjs`)).href)
const [singleAgent, preset, evidenceTools, flowGate, agentTools] = await Promise.all([
  loadLocal('single-agent'), loadLocal('preset'), loadLocal('evidence-tools'), loadLocal('flow-gate'),
  loadLocal('agent-tools'),
])
const packageRequire = createRequire(resolve(packageRoot, 'package.json'))
const Weknora = await import(pathToFileURL(packageRequire.resolve('@wxg-prc-cpg/dsh-weknora')).href)

const require = createRequire(resolve(harnessRoot, 'packages/mcp/mcp-client/package.json'))
const load = name => import(pathToFileURL(require.resolve(name)).href)
const { Context } = await load('@deepseek-ai/cordis')
const { default: SystemPrompt } = await load('@deepseek-ai/dsh-system-prompt')
const { default: ToolRuntime } = await load('@deepseek-ai/dsh-tools')
const NativeExecutor = await load('@deepseek-ai/dsh-tool-executor-native')
const { createScope } = await load('@deepseek-ai/dsh-scope')
const { executeToolFixture } = await load('@deepseek-ai/dsh-tool-testkit')
const cliRequire = createRequire(resolve(harnessRoot, 'apps/cli/package.json'))
const boot = await import(pathToFileURL(cliRequire.resolve('@deepseek-ai/dsh-app-boot')).href)

const patchPath = resolve(packageRoot, 'cordis.patch.yml')
const patches = boot.loadOverlayPatches('dsh', patchPath)
const composed = boot.renderConfigDump('dsh', resolve(packageRoot, 'tests/fixtures/empty.cordis.yml'), [{ label: patchPath, patches }])
assert.ok(composed.includes('hci-weknora'))
const bundleConfig = patches[0].insert[0]
assert.equal(bundleConfig.name, 'hci-weknora-diagnosis-bundle')
const manifest = JSON.parse(await readFile(resolve(packageRoot, 'package.json'), 'utf8'))
assert.equal(manifest.dsh.bundle.patch, './cordis.patch.yml')

const fixture = resolve(packageRoot, 'testdata/log-packages')
const mock = createServer(async (request, response) => {
  const url = new URL(request.url, 'http://localhost')
  const send = value => {
    response.setHeader('content-type', 'application/json')
    response.end(JSON.stringify(value))
  }
  if (url.pathname === '/api/v1/knowledge-bases') {
    return send({ success: true, data: [
      { id: 'kb-cases', name: 'HCI Cases', description: '' },
      { id: 'kb-playbooks', name: 'HCI Playbooks', description: '' },
    ] })
  }
  if (url.pathname === '/api/v1/knowledge-search') {
    const chunks = []
    for await (const part of request) chunks.push(part)
    const body = JSON.parse(Buffer.concat(chunks).toString('utf8'))
    const prefix = body.knowledge_base_ids?.[0] === 'kb-playbooks' ? 'playbook' : 'case'
    return send({ success: true, data: [1, 2, 3].flatMap(index => [
      { id: `${prefix}-chunk-${index}-a`, knowledge_id: `${prefix}-${index}`, chunk_index: 0,
        knowledge_title: `hci-${prefix}-${index}`, score: 1 - index / 10, content: `${prefix} evidence ${index}` },
      { id: `${prefix}-chunk-${index}-b`, knowledge_id: `${prefix}-${index}`, chunk_index: 1,
        knowledge_title: `hci-${prefix}-${index}`, score: 0.5, content: `${prefix} duplicate ${index}` },
    ]) })
  }
  if (url.pathname === '/api/v1/knowledge/search') return send({ success: true, data: [] })
  if (url.pathname === '/api/v1/sessions' && request.method === 'POST') {
    return send({ success: true, data: { id: 'weknora-session-1' } })
  }
  if (url.pathname.startsWith('/api/v1/agent-chat/') && request.method === 'POST') {
    response.setHeader('content-type', 'text/event-stream')
    response.end([
      'data: {"response_type":"answer","content":"候选机制与区分性检查"}',
      'data: {"response_type":"references","knowledge_references":[{"knowledge_id":"test-case-1","knowledge_title":"test case","chunk_index":0,"content":"source"}]}',
      'data: {"response_type":"tool_call","tool_calls":[{"function":{"name":"search_knowledge"}}]}',
      'data: {"response_type":"complete","session_id":"weknora-session-1"}',
      '',
    ].join('\n'))
    return
  }
  const document = url.pathname.match(/^\/api\/v1\/knowledge\/(.+)$/)
  if (document) return send({ success: true, data: { id: document[1], title: document[1], description: '' } })
  const chunks = url.pathname.match(/^\/api\/v1\/chunks\/(.+)$/)
  if (chunks) return send({ success: true, data: [
    { id: `${chunks[1]}-0`, knowledge_id: chunks[1], chunk_index: 0, content: `full ${chunks[1]}` },
  ], total: 1, page: 1, page_size: 20 })
  response.statusCode = 404
  return send({ success: false, message: 'not found' })
})
await new Promise(resolveListen => mock.listen(0, '127.0.0.1', resolveListen))
const address = mock.address()
const baseUrl = `http://127.0.0.1:${address.port}/api/v1`

const resolvedPreset = preset.resolvePreset({
  ...bundleConfig.config,
  baseUrl,
  apiKey: 'test-key',
  workspaceRoot: fixture,
  fallbackSupportRoot: '',
  caseKnowledgeBaseIds: ['kb-cases'],
  playbookKnowledgeBaseIds: ['kb-playbooks'],
  agentKnowledgeBaseIds: ['kb-test'],
  quickAgentId: 'agent-quick',
  reasoningAgentId: 'agent-reasoning',
})
assert.equal(resolvedPreset.plugins.find(item => item.id === 'weknora-hci-knowledge').config.tools.ask, false)

const ctx = new Context()
let scope
const agent = { id: 'hci-weknora-smoke', session: { header: { wecomTaskDirectory: 'exact-known-case' } } }
try {
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(ToolRuntime)
  await ctx.plugin(NativeExecutor)
  ctx.tools.register({ name: 'subagent', description: 'forbidden', parameters: { type: 'object', properties: {} },
    output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: value }] }, execute: async () => 'bad' })
  await ctx.plugin(Object.assign(inner => { scope = createScope(inner, agent) }, { inject: ['tools', 'systemPrompt'] }))
  agent.ctx = scope.ctx
  await scope.ctx.plugin(NativeExecutor)
  await scope.ctx.plugin(singleAgent)
  const evidenceConfig = resolvedPreset.plugins.find(item => item.id === 'hci-weknora-evidence-tools').config
  const gateConfig = resolvedPreset.plugins.find(item => item.id === 'hci-weknora-flow-gate').config
  const knowledgeConfig = resolvedPreset.plugins.find(item => item.id === 'weknora-hci-knowledge').config
  const quickConfig = resolvedPreset.plugins.find(item => item.id === 'weknora-hci-quick-agent').config
  const reasoningConfig = resolvedPreset.plugins.find(item => item.id === 'weknora-hci-reasoning-agent').config
  await scope.ctx.plugin(evidenceTools, evidenceConfig)
  await scope.ctx.plugin(flowGate, gateConfig)
  await scope.ctx.plugin(Weknora, knowledgeConfig)
  await scope.ctx.plugin(agentTools, quickConfig)
  await scope.ctx.plugin(agentTools, reasoningConfig)

  const tools = ctx.tools.schemas(agent).map(item => item.name)
  for (const name of [...singleAgent.TOOL_NAMES, 'hci_finalize']) assert.ok(tools.includes(name), name)
  assert.ok(!tools.includes('hci_kb_ask'))
  assert.equal(ctx.tools.get('subagent', agent), undefined)

  let sequence = 0
  async function call(name, args) {
    return executeToolFixture(ctx, { signal: new AbortController().signal,
      callId: `weknora-smoke-${++sequence}`, name, arguments: args, agent })
  }
  async function value(name, args) {
    const result = await call(name, args)
    assert.equal(result.isError, false, JSON.stringify(result))
    if (result.value && typeof result.value === 'object' && !Array.isArray(result.value)) return result.value
    return JSON.parse(result.content.find(item => item.type === 'text').text)
  }

  await value('hci_kb_list_knowledge_bases', {})
  const quickAnswer = await value('hci_quick_ask', { query: '虚拟机卡顿如何区分候选原因？' })
  assert.equal(quickAnswer.pipeline, 'agent')
  assert.equal(quickAnswer.references[0].knowledge_id, 'test-case-1')
  const reasoningAnswer = await value('hci_reasoning_ask', { query: '区分存储时延和 CPU 争用' })
  assert.ok(reasoningAnswer.tool_calls.includes('search_knowledge'))
  for (const [kb, prefix] of [['kb-cases', 'case'], ['kb-playbooks', 'playbook']]) {
    const found = await value('hci_kb_search', { query: `${prefix} query`, knowledge_base_ids: [kb], max_results: 12 })
    assert.equal(new Set(found.results.map(item => item.knowledge_id)).size, 3)
    for (const id of [`${prefix}-1`, `${prefix}-2`, `${prefix}-3`]) {
      await value('hci_kb_read_document', { knowledge_id: id })
    }
  }
  const evidence = await value('mcp__hci_weknora__support_read', { path: 'metadata/summary.txt' })
  const status = await value('hci_evidence_status', {})
  assert.equal(status.ready, true)
  const citations = status.documents
    .map(document => `${document.title} (knowledge_id: ${document.knowledge_id})`)
    .join(' ')
  const final = await value('hci_finalize', {
    root_cause_status: 'confirmed',
    summary: `${citations} ${evidence.citation_id}`,
  })
  assert.equal(final.validated, true)
  console.log(JSON.stringify({ status: 'passed', preset: 'hci-weknora', tools: tools.length,
    case_documents: 3, playbook_documents: 3, quick_agent: true, reasoning_agent: true,
    evidence: true, finalize: true, model_calls: 0 }, null, 2))
} finally {
  await scope?.dispose()
  await ctx.fiber.dispose()
  await new Promise(resolveClose => mock.close(resolveClose))
}
