export const name = 'hci-weknora-single-agent'
export const inject = ['tools']

export const TOOL_NAMES = [
  'hci_kb_list_knowledge_bases',
  'hci_kb_search',
  'hci_kb_read_document',
  'hci_quick_ask',
  'hci_reasoning_ask',
  'mcp__hci_weknora__support_inventory',
  'mcp__hci_weknora__support_read',
  'mcp__hci_weknora__support_search',
  'hci_evidence_status',
]

const FORBIDDEN = new Set(['subagent', 'subagent_fork', 'workflow'])
const UNSCOPED = new Set(['bash', 'read', 'write', 'edit', 'glob', 'grep'])

export function apply(ctx) {
  if (typeof ctx.tools.presentAs === 'function') ctx.tools.presentAs('native')
  const inherited = ctx.tools.schemas().map(tool => tool.name)
  const denied = inherited.filter(name => FORBIDDEN.has(name) || UNSCOPED.has(name))
  if (denied.length) ctx.tools.restrict({ deny: denied })
  ctx.tools.guard(exec => {
    if (FORBIDDEN.has(exec.name)) {
      return 'HCI WeKnora diagnosis is a single-agent preset; delegation tools are disabled'
    }
    if (exec.agent?.session?.header.origin === 'subagent'
      || (exec.agent?.session?.header.delegationDepth ?? 0) > 0) {
      return 'HCI WeKnora diagnosis requires the root single agent'
    }
    if (UNSCOPED.has(exec.name)) {
      return 'HCI diagnosis must use the task-bound support tools; unscoped shell and filesystem tools are disabled'
    }
    return undefined
  })
}
