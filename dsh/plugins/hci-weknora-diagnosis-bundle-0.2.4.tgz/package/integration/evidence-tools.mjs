import { createHash } from 'node:crypto'
import { opendir, lstat, readFile, realpath, stat } from 'node:fs/promises'
import { isAbsolute, relative, resolve, sep } from 'node:path'

export const name = 'hci-weknora-evidence-tools'
export const inject = ['tools']

const MAX_SOURCE_BYTES = 16 * 1024 * 1024
const MAX_SEARCH_BYTES = 64 * 1024 * 1024
const MAX_FILES = 20000

function hash(value) {
  return createHash('sha256').update(value).digest('hex')
}

function bounded(value, fallback, low, high, name) {
  const parsed = value === undefined ? fallback : Number(value)
  if (!Number.isSafeInteger(parsed) || parsed < low || parsed > high) {
    throw new Error(`${name} must be between ${low} and ${high}`)
  }
  return parsed
}

function inside(root, candidate) {
  return candidate === root || candidate.startsWith(root.endsWith(sep) ? root : root + sep)
}

async function checkedDirectory(path, label) {
  let resolved
  try {
    resolved = await realpath(path)
  } catch {
    throw new Error(`${label} does not exist: ${JSON.stringify(path)}`)
  }
  if (!(await stat(resolved)).isDirectory()) throw new Error(`${label} is not a directory: ${JSON.stringify(path)}`)
  return resolved
}

export async function resolveEvidenceRoots(agent, config = {}) {
  const recordedDirectory = recoverTaskDirectory(agent)
  const relativeDirectory = agent?.session?.header?.wecomTaskDirectory ?? recordedDirectory
  const absoluteDirectory = agent?.session?.header?.wecomTaskAbsoluteDirectory
  if (typeof relativeDirectory === 'string' && relativeDirectory.trim()) {
    if (typeof config.workspaceRoot !== 'string' || !config.workspaceRoot.trim()) {
      throw new Error('WECOM_WORKSPACE_ROOT is required for a WeCom-bound diagnosis session')
    }
    if (isAbsolute(relativeDirectory)) throw new Error('WeCom task directory must be relative to its workspace')
    const workspace = await checkedDirectory(config.workspaceRoot, 'WeCom workspace root')
    const target = await checkedDirectory(
      typeof absoluteDirectory === 'string' && absoluteDirectory.trim()
        ? absoluteDirectory : resolve(workspace, relativeDirectory),
      'WeCom task directory',
    )
    if (target === workspace || !inside(workspace, target)) {
      throw new Error('WeCom task directory resolves outside its workspace')
    }
    return { root: target, sourceRoot: undefined }
  }
  if (typeof config.fallbackSupportRoot === 'string' && config.fallbackSupportRoot.trim()) {
    return { root: await checkedDirectory(config.fallbackSupportRoot, 'HCI fallback support root'), sourceRoot: undefined }
  }
  throw new Error('This session has no bound support package. Bind a WeCom task directory or configure HCI_SUPPORT_ROOT for standalone testing.')
}

function recoverTaskDirectory(agent) {
  const session = agent?.session
  const events = typeof session?.snapshotEvents === 'function'
    ? session.snapshotEvents()
    : Array.isArray(session?.events) ? session.events : []
  const pattern = /\[WeCom log task directory: ("(?:\\.|[^"\\])*");/u
  for (const event of [...events].reverse()) {
    if (event?.type !== 'user/message') continue
    const message = event.data?.message ?? event.data
    const content = Array.isArray(message?.content) ? message.content : []
    for (const block of content) {
      if (block?.type !== 'text' || typeof block.text !== 'string') continue
      const encoded = pattern.exec(block.text)?.[1]
      if (encoded === undefined) continue
      const value = JSON.parse(encoded)
      if (typeof value === 'string' && value.trim()) return value
    }
  }
  return undefined
}

export async function resolveSupportRoot(agent, config = {}) {
  return (await resolveEvidenceRoots(agent, config)).root
}

function globRegex(pattern) {
  if (typeof pattern !== 'string' || pattern.length > 300) throw new Error('Pattern must be at most 300 characters')
  let out = '^'
  for (const char of pattern || '*') {
    if (char === '*') out += '.*'
    else if (char === '?') out += '.'
    else out += char.replace(/[|\\{}()[\]^$+?.]/g, '\\$&')
  }
  return new RegExp(out + '$')
}

async function inventoryPaths(root, sourceRoot) {
  const files = []
  const skipped = []
  let complete = true
  async function walk(directory, prefix = '') {
    let handle
    try {
      handle = await opendir(directory)
      const entries = []
      for await (const entry of handle) entries.push(entry)
      entries.sort((left, right) => left.name.localeCompare(right.name))
      for (const entry of entries) {
        if (files.length + skipped.length >= MAX_FILES) {
          complete = false
          return
        }
        const absolute = resolve(directory, entry.name)
        const relativePath = prefix ? `${prefix}/${entry.name}` : entry.name
        const info = await lstat(absolute)
        if (info.isSymbolicLink()) {
          let target
          try { target = await realpath(absolute) } catch {
            skipped.push({ path: relativePath, reason: 'symlink_target_unavailable' })
            continue
          }
          if (sourceRoot && inside(sourceRoot, target) && (await stat(target)).isFile()) files.push(relativePath)
          else skipped.push({ path: relativePath, reason: 'symlink_target_outside_source_root' })
        } else if (info.isDirectory()) {
          await walk(absolute, relativePath)
          if (!complete) return
        } else if (info.isFile()) files.push(relativePath)
        else skipped.push({ path: relativePath, reason: 'non_regular' })
      }
    } catch (error) {
      skipped.push({ path: prefix, reason: `inventory_error: ${error instanceof Error ? error.message : String(error)}` })
    } finally {
      await handle?.close().catch(() => undefined)
    }
  }
  await walk(root)
  return { files, skipped, complete }
}

function relativePath(value) {
  if (typeof value !== 'string' || !value || value.includes('\\') || value.includes('\0') || isAbsolute(value)) {
    throw new Error('Expected a relative path inside this support package')
  }
  const parts = value.split('/')
  if (parts.some(part => part === '..' || part === '')) throw new Error('Expected a relative path inside this support package')
  return parts.join('/')
}

async function readSource(roots, inputPath, byteLimit = MAX_SOURCE_BYTES) {
  const path = relativePath(inputPath)
  const lexical = resolve(roots.root, path)
  if (!inside(roots.root, lexical)) throw new Error('Source path escapes the analysis root')
  const target = await realpath(lexical)
  const allowed = inside(roots.root, target) || (roots.sourceRoot && inside(roots.sourceRoot, target))
  if (!allowed) throw new Error('Symlink target is outside the approved source root')
  const before = await stat(target)
  if (!before.isFile()) throw new Error('Only regular files can be read')
  if (before.size > byteLimit) throw new Error('Source exceeds per-file or remaining search byte budget')
  const raw = await readFile(target)
  const after = await stat(target)
  if (raw.length > byteLimit || before.size !== after.size || before.mtimeMs !== after.mtimeMs) {
    throw new Error('Source changed during read or exceeds limit')
  }
  if (raw.includes(0)) throw new Error('Binary source unsupported; compressed archives/SQLite require a source adapter')
  let text
  try { text = new TextDecoder('utf-8', { fatal: true }).decode(raw) } catch {
    throw new Error('Source is not valid UTF-8 text')
  }
  const lines = text === '' ? [] : text.split(/\r?\n/)
  if (lines.at(-1) === '' && /\r?\n$/.test(text)) lines.pop()
  return { path, raw, lines, info: before }
}

function scope(roots) {
  return {
    scope_id: hash(roots.root).slice(0, 20),
    support_root: roots.root,
    ...(roots.sourceRoot === undefined ? {} : { source_root: roots.sourceRoot }),
    observed_at: new Date().toISOString(),
    collection_status: 'unknown; inspect metadata/summary and files/commands manifests',
    usage: 'File absence/no match does not establish product health; timestamps must be read from source',
  }
}

export async function inventory(roots, args = {}) {
  const pattern = typeof args.pattern === 'string' ? args.pattern : '*'
  const matcher = globRegex(pattern)
  const offset = bounded(args.offset, 0, 0, MAX_FILES, 'offset')
  const limit = bounded(args.limit, 100, 1, 200, 'limit')
  const found = await inventoryPaths(roots.root, roots.sourceRoot)
  const matches = found.files.filter(path => matcher.test(path))
  const files = matches.slice(offset, offset + limit)
  return {
    ...scope(roots), pattern, files, matched_count: matches.length,
    inventory_complete: found.complete,
    next_offset: offset + files.length < matches.length ? offset + files.length : null,
    skipped_count: found.skipped.length,
    skipped: found.skipped.slice(0, 100),
    skipped_truncated: found.skipped.length > 100,
  }
}

export async function read(roots, args = {}) {
  const startLine = bounded(args.start_line, 1, 1, 10000000, 'start_line')
  const lineCount = bounded(args.line_count, 120, 1, 400, 'line_count')
  const source = await readSource(roots, args.path)
  if (startLine > Math.max(1, source.lines.length)) throw new Error('start_line exceeds source length')
  const lines = []
  let chars = 0
  for (let index = startLine - 1; index < Math.min(source.lines.length, startLine - 1 + lineCount); index += 1) {
    const value = source.lines[index]
    if (chars + value.length + 1 > 32000) {
      if (lines.length === 0) throw new Error('Single source line exceeds read limit')
      break
    }
    lines.push({ line: index + 1, text: value })
    chars += value.length + 1
  }
  const endLine = lines.at(-1)?.line ?? 0
  const sha = hash(source.raw)
  const currentScope = scope(roots)
  return {
    ...currentScope,
    path: source.path,
    source_sha256: sha,
    citation_id: `E:${currentScope.scope_id}:${hash(source.path).slice(0, 12)}:${sha.slice(0, 16)}:L${startLine}-${endLine}`,
    start_line: startLine,
    end_line: endLine,
    total_lines: source.lines.length,
    lines,
    file_mtime_ms: source.info.mtimeMs,
    mtime_is_event_time: false,
    truncated: endLine < source.lines.length,
    next_line: endLine < source.lines.length ? endLine + 1 : null,
  }
}

export async function search(roots, args = {}) {
  const query = typeof args.query === 'string' ? args.query : ''
  const pattern = typeof args.pattern === 'string' ? args.pattern : '*'
  const limit = bounded(args.limit, 30, 1, 100, 'limit')
  if (!query || query.length > 1000) throw new Error('Expected literal query (1-1000 characters)')
  const matcher = globRegex(pattern)
  const found = await inventoryPaths(roots.root, roots.sourceRoot)
  const candidates = found.files.filter(path => matcher.test(path))
  const matches = []
  const skipped = [...found.skipped]
  let bytesScanned = 0
  let filesScanned = 0
  let complete = found.complete
  for (const path of candidates) {
    if (bytesScanned >= MAX_SEARCH_BYTES || matches.length >= limit) {
      complete = false
      break
    }
    try {
      const source = await readSource(roots, path, Math.min(MAX_SOURCE_BYTES, MAX_SEARCH_BYTES - bytesScanned))
      bytesScanned += source.raw.length
      filesScanned += 1
      const sha = hash(source.raw)
      for (let index = 0; index < source.lines.length; index += 1) {
        if (source.lines[index].includes(query)) {
          matches.push({
            path, line: index + 1, text: source.lines[index].slice(0, 1200),
            excerpt_truncated: source.lines[index].length > 1200,
            source_sha256: sha, needs_read: true,
          })
          if (matches.length >= limit) {
            complete = false
            break
          }
        }
      }
    } catch (error) {
      skipped.push({ path, reason: error instanceof Error ? error.message : String(error) })
    }
  }
  return {
    ...scope(roots), query, pattern, matches,
    search_complete: complete && skipped.length === 0,
    files_scanned: filesScanned,
    candidate_files: candidates.length,
    bytes_scanned: bytesScanned,
    skipped_count: skipped.length,
    skipped: skipped.slice(0, 100),
    skipped_truncated: skipped.length > 100,
    interpretation: 'Search hits are navigation; read context before citing. No hit is not exclusion.',
  }
}

function definition(name, description, parameters, operation, config) {
  return {
    name: `mcp__hci_weknora__${name}`,
    description,
    parameters,
    output: {
      schema: { type: 'object' },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
    },
    async execute(args, exec) {
      const roots = await resolveEvidenceRoots(exec.agent, config)
      return operation(roots, args)
    },
  }
}

export function definitions(config = {}) {
  return [
    definition('support_inventory', 'Discover files only in this session\'s bound HCI support package.', {
      type: 'object', properties: {
        pattern: { type: 'string' }, offset: { type: 'integer' }, limit: { type: 'integer' },
      }, additionalProperties: false,
    }, inventory, config),
    definition('support_read', 'Read UTF-8 source lines from this session\'s bound HCI support package and return an E citation.', {
      type: 'object', properties: {
        path: { type: 'string' }, start_line: { type: 'integer' }, line_count: { type: 'integer' },
      }, required: ['path'], additionalProperties: false,
    }, read, config),
    definition('support_search', 'Literal search in this session\'s bound HCI support package. A hit is navigation and must be read.', {
      type: 'object', properties: {
        query: { type: 'string' }, pattern: { type: 'string' }, limit: { type: 'integer' },
      }, required: ['query'], additionalProperties: false,
    }, search, config),
  ]
}

export function apply(ctx, config = {}) {
  for (const item of definitions(config)) ctx.tools.register(item)
}
