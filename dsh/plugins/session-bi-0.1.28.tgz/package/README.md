# session-bi

DeepSeek Harness 会话运营数据插件。

当前 MVP：

- 监听 Session 创建、事件和销毁生命周期；
- 解析首条用户消息中的“责任人 / 责任人小组 / 目录 / 问题描述”；
- 记录状态、轮次、消息数、工具调用、错误、模型和处理时长；
- 使用本地 JSON 文件做崩溃安全的原子持久化；
- 通过受 Harness Connection 认证保护的 `/api/session-bi/records` 查询；
- 提供 Web Client 主面板与左侧导航入口。

默认数据文件为 Harness Home 下的 `session-bi/records.json`，在 Docker Compose 中对应 `dsh_home` 持久卷，不依赖 `/tmp`。也可以用 `DSH_SESSION_BI_DATA_FILE` 指定绝对路径。

当前 Compose 将 `WECOM_WORKSPACE_ROOT` 指向 `/data/tickets`，且案件目录是只读挂载，因此 BI 台账不默认写入该目录。若将来把 `/data/tickets` 的管理子目录单独以 `rw` 挂载，也可以把 `DSH_SESSION_BI_DATA_FILE` 指向 `/data/tickets/.harness-ops/session-bi/records.json`。

插件会在新数据文件不存在时尝试迁移旧版本的临时文件。未登记或格式不符合约定的首条消息会保留为 `invalid`，不会静默丢弃。

消息统计只计直接用户消息和含可见文本的 Assistant 消息，不把 runtime context、技能提醒或纯推理步骤算作对话消息。处理时长累计各 turn 的实际执行窗口；恢复旧 Session 不会把闲置时间计入处理时长。可恢复的工具参数错误保留在 `toolErrors`，只有终止性 turn 错误才标记 `EXECUTION_FAILURE`。

Docker Compose 建议使用以下变量：

```yaml
WECOM_WORKSPACE_ROOT: /data/tickets
DSH_SESSION_BI_RULE_SOURCE_ROOT: /data/tickets
DSH_SESSION_BI_DATA_FILE: /home/dsh/.dsh/session-bi/records.json
DSH_SESSION_BI_RULE_PACKAGE_ROOT: /home/dsh/.dsh/session-bi/rule-packages
```

`/data/tickets` 继续挂载为只读。规则版本和 BI 台账由 `dsh_home` 持久卷保存；新会话如果 Q 目录可写，会把选定规则包复制到该目录，否则保留版本绑定并使用会话级提示加载。

规则版本可以在 Web 的“规则包管理”页通过“从当前 Workspace 导入版本”生成，也可以预先写入 `rulePackageRoot/<packageId>/<version>/`，其中必须包含 `manifest.json` 和规则文件。企微新会话可显式指定：

```text
目录：Q2026111100310；规则包：hci-diagnosis@1.7.0-rc.1；问题：迁移失败
```

## 首条消息格式

```text
责任人：xxx
责任人小组：xxx
目录：Q2026xxxxxxxx
问题描述：xxx
```

HCI Web 新会话请选择 `hci-weknora` 预设，首条消息可直接使用与企微相同的任务格式。Session BI 在首个模型步骤前校验 `WECOM_WORKSPACE_ROOT` 下的工单目录、绑定规则包并在分析根目录物化规则；HCI 证据工具从会话绑定读取原始工单目录。Web 消息无需手写 `[WeCom log task directory: ...]` 标记。

0.1.27 将 Web Agent 的首步监听注册到 Harness 根上下文，使 Agent Preset 内创建的 Web Agent 与企微入口一样执行规则准备；0.1.26 的局部监听无法收到这类 Agent 的 `agent/pre-step` 事件。

0.1.28 不再依赖 Session Header 中的初始 Agent Preset。Web UI 可以先创建 `standard` 会话、再记录 `agent-preset/selected: hci-weknora`；只要首消息符合任务信封，Session BI 都会执行目录校验和规则准备。

```text
目录：Q2026112601073；问题：虚拟机备份失败
```

```text
责任人：张三；责任小组：HCI 二组；目录：Q2026112601073；规则包：hci-diagnosis@1.0.0；weknora排查思路是否检索：是；问题：虚拟机备份失败
```

`规则包` 省略时采用当前默认版本。WeKnora 检索开关只影响本轮；后续轮次需要覆盖默认值时再次写入 `weknora排查思路是否检索：是/否`。

## 当前边界

JSON 存储适合单进程 MVP。上线到大规模多人使用前，应将 `SessionOpsStore` 替换为 SQLite 或 PostgreSQL 实现，保持查询 DTO 和 Web 面板契约不变。
