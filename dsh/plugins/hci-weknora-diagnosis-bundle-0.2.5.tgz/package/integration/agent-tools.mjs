import { WeknoraClient, createTools, resolveConfig } from '@wxg-prc-cpg/dsh-weknora'

export const name = 'hci-weknora-fixed-agent-tool'
export const inject = ['tools']

export function definition(config) {
  const resolved = resolveConfig(config)
  if (!resolved.agentId) throw new Error('A fixed WeKnora agentId is required')
  if (resolved.knowledgeBaseIds.length === 0) throw new Error('A fixed WeKnora knowledge base scope is required')
  const ask = createTools(new WeknoraClient(resolved), resolved).find(tool => tool.name === `${resolved.toolPrefix}_ask`)
  if (!ask) throw new Error('WeKnora ask tool is disabled')
  return {
    ...ask,
    description: 'Ask the configured HCI knowledge agent. Its agent id, test knowledge-base scope and disabled web search are fixed by deployment.',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'A technical HCI question containing observed signals and unknown conditions.' },
        session_id: { type: 'string', description: 'Continue the same fixed HCI agent session for a focused follow-up.' },
      },
      required: ['query'],
      additionalProperties: false,
    },
    execute: (args, exec) => ask.execute({
      query: args.query,
      ...(typeof args.session_id === 'string' && args.session_id.trim() ? { session_id: args.session_id.trim() } : {}),
      agent_id: resolved.agentId,
      knowledge_base_ids: resolved.knowledgeBaseIds,
      web_search: false,
    }, exec),
  }
}

export function apply(ctx, config) {
  ctx.tools.register(definition(config))
}
