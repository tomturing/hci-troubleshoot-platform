export function caseAgent(agent) {
  const header = agent?.session?.header
  if (header?.origin !== 'subagent') return agent
  if (header.delegationDepth !== 1 || !header.parentSession) {
    throw new Error('HCI evidence requires a direct child of the root diagnosis session')
  }
  const parent = agent.ctx?.get?.('agents')?.get(header.parentSession)
  if (!parent || parent.session?.header?.origin === 'subagent') {
    throw new Error('The parent HCI diagnosis session is no longer active')
  }
  return parent
}
