#!/usr/bin/env node
import { createHash } from 'node:crypto'
import { readFile, rename, writeFile } from 'node:fs/promises'
import { basename, resolve } from 'node:path'

function usage(message) {
  if (message) console.error(message)
  console.error('Usage: node scripts/import-v3.mjs --knowledge-root PATH --case-kb-id ID --playbook-kb-id ID [--type all|case|playbook] [--concurrency N] [--base-url URL] [--api-key KEY] [--state FILE] [--limit N] [--dry-run]')
  process.exit(message ? 2 : 0)
}

function argsOf(argv) {
  const args = {}
  for (let index = 0; index < argv.length; index += 1) {
    const item = argv[index]
    if (item === '--dry-run') args.dryRun = true
    else if (item.startsWith('--')) {
      const key = item.slice(2).replace(/-([a-z])/g, (_all, char) => char.toUpperCase())
      const value = argv[++index]
      if (!value) usage(`Missing value for ${item}`)
      args[key] = value
    } else usage(`Unknown argument: ${item}`)
  }
  return args
}

function apiRoot(value) {
  const trimmed = String(value || 'http://127.0.0.1:8080/api/v1').replace(/\/+$/, '')
  return /\/api\/v\d+$/.test(trimmed) ? trimmed : `${trimmed}/api/v1`
}

function sha(value) {
  return createHash('sha256').update(value.replace(/\r\n/g, '\n')).digest('hex')
}

function titleOf(text, fallback) {
  const frontmatter = text.match(/^---\r?\n([\s\S]*?)\r?\n---/)
  const title = frontmatter?.[1].match(/^title:\s*["']?(.*?)["']?\s*$/m)?.[1]?.trim()
  if (title) return title
  return text.match(/^#\s+(.+)$/m)?.[1]?.trim() || fallback
}

async function request(config, path, method, body) {
  let lastError
  for (let attempt = 0; attempt < 4; attempt += 1) {
    try {
      const response = await fetch(`${config.baseUrl}${path}`, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...(config.apiKey ? { 'X-API-Key': config.apiKey } : {}),
          ...(config.tenantId ? { 'X-Tenant-ID': config.tenantId } : {}),
        },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: AbortSignal.timeout(120000),
      })
      const text = await response.text()
      let payload
      try { payload = JSON.parse(text) } catch { payload = { message: text.slice(0, 300) } }
      if (response.ok) return payload.data ?? payload
      const message = `${method} ${path} failed with HTTP ${response.status}: ${payload.message || payload.error || 'unknown error'}`
      if (![429, 500, 502, 503, 504].includes(response.status) || attempt === 3) throw new Error(message)
      lastError = new Error(message)
    } catch (error) {
      lastError = error
      if (attempt === 3 || (error instanceof Error && /HTTP 4\d\d/.test(error.message) && !/HTTP 429/.test(error.message))) throw error
    }
    await new Promise(resolveDelay => setTimeout(resolveDelay, 500 * (2 ** attempt)))
  }
  throw lastError
}

async function loadState(path) {
  try { return JSON.parse(await readFile(path, 'utf8')) } catch { return { schema: 1, assets: {} } }
}

async function saveState(path, state) {
  const temporary = `${path}.tmp`
  await writeFile(temporary, JSON.stringify(state, null, 2) + '\n')
  await rename(temporary, path)
}

async function assets(root, type, kbId) {
  const kind = type === 'case' ? 'case' : 'playbook'
  const manifestPath = resolve(root, `manifests/${kind}-manifest.yaml`)
  const manifest = await readFile(manifestPath, 'utf8')
  const outputs = [...manifest.matchAll(/^\s+output:\s*["']?([^"'\r\n]+?)["']?\s*$/gm)]
    .map(match => match[1].trim())
  if (outputs.length === 0) throw new Error(`No assets found in ${manifestPath}`)
  const unique = [...new Set(outputs)]
  if (unique.length !== outputs.length) throw new Error(`Duplicate output paths in ${manifestPath}`)
  return unique.sort().map(output => ({
    type,
    kbId,
    path: resolve(root, output),
    assetId: basename(output, '.md'),
  }))
}

async function main() {
  const args = argsOf(process.argv.slice(2))
  if (!args.knowledgeRoot || !args.caseKbId || !args.playbookKbId) usage('knowledge root and both KB ids are required')
  const config = {
    baseUrl: apiRoot(args.baseUrl || process.env.WEKNORA_BASE_URL),
    apiKey: args.apiKey || process.env.WEKNORA_INGEST_API_KEY || process.env.WEKNORA_API_KEY,
    tenantId: args.tenantId || process.env.WEKNORA_TENANT_ID,
  }
  const statePath = resolve(args.state || './weknora-hci-import-state.json')
  const state = await loadState(statePath)
  const all = [
    ...await assets(args.knowledgeRoot, 'case', args.caseKbId),
    ...await assets(args.knowledgeRoot, 'playbook', args.playbookKbId),
  ]
  const type = args.type || 'all'
  if (!['all', 'case', 'playbook'].includes(type)) usage('--type must be all, case, or playbook')
  const scoped = type === 'all' ? all : all.filter(item => item.type === type)
  const limit = args.limit ? Number(args.limit) : scoped.length
  if (!Number.isSafeInteger(limit) || limit < 1) usage('--limit must be a positive integer')
  const concurrency = args.concurrency ? Number(args.concurrency) : 1
  if (!Number.isSafeInteger(concurrency) || concurrency < 1 || concurrency > 8) usage('--concurrency must be between 1 and 8')
  const selected = scoped.slice(0, limit)
  if (args.dryRun) {
    console.log(JSON.stringify({ dry_run: true, total: all.length, selected: selected.length, type, concurrency,
      cases: all.filter(item => item.type === 'case').length,
      playbooks: all.filter(item => item.type === 'playbook').length,
      base_url: config.baseUrl, state: statePath }, null, 2))
    return
  }
  if (!config.apiKey) throw new Error('WEKNORA_INGEST_API_KEY or --api-key is required for import')

  let created = 0
  let updated = 0
  let skipped = 0
  let completed = 0
  let cursor = 0
  let stateWrites = Promise.resolve()
  const failures = []

  async function checkpoint(assetId, value) {
    state.assets[assetId] = value
    state.updated_at = new Date().toISOString()
    stateWrites = stateWrites.then(() => saveState(statePath, state))
    await stateWrites
  }

  async function importOne(item) {
    const content = await readFile(item.path, 'utf8')
    const revision = sha(content)
    const previous = state.assets[item.assetId]
    if (previous?.revision === revision && previous?.knowledge_id) {
      skipped += 1
      return
    }
    const title = `${item.assetId} | ${titleOf(content, item.assetId)}`
    let knowledgeId = previous?.knowledge_id
    if (knowledgeId) {
      await request(config, `/knowledge/manual/${encodeURIComponent(knowledgeId)}`, 'PUT', { content, status: 'publish' })
      updated += 1
    } else {
      const createdKnowledge = await request(config, `/knowledge-bases/${encodeURIComponent(item.kbId)}/knowledge/manual`, 'POST', {
        title, content, status: 'publish', channel: 'hci-v3-import',
        process_config: { summary_enabled: false, question_generation_config: { enabled: false } },
      })
      knowledgeId = createdKnowledge?.id
      if (typeof knowledgeId !== 'string' || !knowledgeId) throw new Error(`WeKnora returned no knowledge id for ${item.assetId}`)
      created += 1
      await checkpoint(item.assetId, {
        knowledge_id: knowledgeId,
        knowledge_base_id: item.kbId,
        type: item.type,
        revision: null,
        status: 'metadata_pending',
      })
    }
    await request(config, `/knowledge/${encodeURIComponent(knowledgeId)}`, 'PUT', {
      title,
      custom_metadata: {
        asset_id: item.assetId,
        asset_type: item.type,
        revision,
        source_package: 'hci-knowledge-reorganized-v3',
      },
    })
    await checkpoint(item.assetId, {
      knowledge_id: knowledgeId,
      knowledge_base_id: item.kbId,
      type: item.type,
      revision,
      status: 'published',
    })
  }

  async function worker() {
    while (true) {
      const index = cursor
      cursor += 1
      if (index >= selected.length) return
      const item = selected[index]
      try {
        await importOne(item)
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error)
        failures.push({ asset_id: item.assetId, error: message })
        console.error(`[import][error] ${item.assetId}: ${message}`)
      } finally {
        completed += 1
        if (completed % 25 === 0 || completed === selected.length) {
          console.log(`[import] ${completed}/${selected.length} created=${created} updated=${updated} skipped=${skipped} failed=${failures.length}`)
        }
      }
    }
  }

  await Promise.all(Array.from({ length: Math.min(concurrency, selected.length) }, () => worker()))
  await stateWrites
  console.log(JSON.stringify({ created, updated, skipped, failed: failures.length,
    failures: failures.slice(0, 100), selected: selected.length, concurrency, state: statePath }, null, 2))
  if (failures.length) process.exitCode = 1
}

main().catch(error => {
  console.error(error instanceof Error ? error.stack : String(error))
  process.exitCode = 1
})
