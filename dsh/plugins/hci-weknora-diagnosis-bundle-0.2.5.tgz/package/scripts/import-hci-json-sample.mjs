#!/usr/bin/env node
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { readFile, writeFile } from 'node:fs/promises'

const baseUrl = (process.env.WEKNORA_BASE_URL || 'http://127.0.0.1:8080/api/v1').replace(/\/+$/, '')
const email = process.env.WEKNORA_EMAIL
const password = process.env.WEKNORA_PASSWORD
const kbId = process.env.WEKNORA_KB_ID || '619c4252-2325-438e-982b-1d2a1f2d0911'
const inputPath = process.env.HCI_JSON_PATH || new URL('../../HCI.json', import.meta.url).pathname
const statePath = process.env.HCI_IMPORT_STATE || '/tmp/hci-json-sample-100-state.json'
const targetCount = Number(process.env.HCI_IMPORT_COUNT || 100)
const concurrency = Number(process.env.HCI_IMPORT_CONCURRENCY || 4)

if (!email || !password) throw new Error('WEKNORA_EMAIL and WEKNORA_PASSWORD are required')
if (!Number.isSafeInteger(targetCount) || targetCount < 1) throw new Error('HCI_IMPORT_COUNT must be a positive integer')
if (!Number.isSafeInteger(concurrency) || concurrency < 1 || concurrency > 8) throw new Error('HCI_IMPORT_CONCURRENCY must be between 1 and 8')

async function request(path, token, method = 'GET', body) {
  let last
  for (let attempt = 0; attempt < 4; attempt += 1) {
    try {
      const response = await fetch(`${baseUrl}${path}`, {
        method,
        headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: AbortSignal.timeout(120000),
      })
      const text = await response.text()
      let payload
      try { payload = JSON.parse(text) } catch { payload = { message: text.slice(0, 500) } }
      if (response.ok) return payload.data ?? payload
      const message = `${method} ${path} HTTP ${response.status}: ${payload.error?.message || payload.message || 'unknown error'}`
      if (![429, 500, 502, 503, 504].includes(response.status) || attempt === 3) throw new Error(message)
      last = new Error(message)
    } catch (error) {
      last = error
      if (attempt === 3) throw error
    }
    await new Promise(resolve => setTimeout(resolve, 500 * (attempt + 1)))
  }
  throw last
}

function markdownFromHtml(htmlText) {
  let source = String(htmlText || '')
  source = source.replace(/<input\b[^>]*>/gi, tag => {
    const match = tag.match(/\bvalue\s*=\s*(["'])(.*?)\1/is)
    if (!match) return ''
    const label = match[2].replace(/&quot;/gi, '"').replace(/&#39;/g, "'").replace(/&amp;/gi, '&').trim().replace(/^\*+/, '')
    return label === '补充说明' ? `<h3>${label}</h3>` : `<h2>${label}</h2>`
  })
  // Images are intentionally omitted for this first import batch.
  source = source.replace(/<img\b[^>]*>/gi, '')
  const converted = execFileSync('pandoc', ['--from=html', '--to=gfm', '--wrap=none'], { input: source, encoding: 'utf8' })
  const cleaned = converted.split('\n').filter(line => {
    const trimmed = line.trim()
    return !/^<\/?div\b/i.test(trimmed) && !/^<span\b[^>]*>\s*<\/span>$/i.test(trimmed)
  }).join('\n').replace(/\n{3,}/g, '\n\n').trim()
  return cleaned.replace(/^## 补充说明$/m, '### 补充说明')
}

function sha(text) {
  return createHash('sha256').update(text.replace(/\r\n/g, '\n')).digest('hex')
}

function contentOf(item) {
  const body = markdownFromHtml(item['正文'])
  return [
    `# ${item['标题']}`,
    '',
    `案例ID：${item['案例ID']}`,
    `产品线：${item['产品线'] || '未注明'}`,
    `更新时间：${item['更新时间'] || '未注明'}`,
    `案例库状态：${item['案例库状态'] || '未注明'}`,
    `案例分类：${item['案例分类'] || '未注明'}`,
    `典型场景分类：${item['典型场景分类'] || '未注明'}`,
    `来源：${item['链接'] || '未注明'}`,
    '',
    body,
    '',
  ].join('\n')
}

function titleOf(item) {
  const full = `HCI-${item['案例ID']} | ${item['标题']}`
  return full.length <= 240 ? full : `${full.slice(0, 237)}...`
}

async function listExisting(token) {
  const existing = new Map()
  for (let page = 1; ; page += 1) {
    const response = await request(`/knowledge-bases/${encodeURIComponent(kbId)}/knowledge?page=${page}&page_size=100`, token)
    for (const item of response.data || response) {
      const match = String(item.title || '').match(/^HCI-(\d+)\s*\|/)
      if (match && item.id) existing.set(match[1], item)
    }
    const total = Number(response.total || 0)
    if ((response.data || response).length === 0 || page * 100 >= total) break
  }
  return existing
}

const login = await request('/auth/login', undefined, 'POST', { email, password })
const token = login.token
await request(`/knowledge-bases/${encodeURIComponent(kbId)}`, token, 'PATCH', {
  chunking_config: {
    chunk_size: 512,
    chunk_overlap: 64,
    separators: ['\n\n', '\n', '。', '！', '？', '；'],
    strategy: 'auto',
    languages: ['zh'],
    enable_parent_child: false,
  },
})
console.log('[config] Case KB configured: auto, 512/64, parent-child=false')

const root = JSON.parse(await readFile(inputPath, 'utf8'))
const records = Object.values(root).flat().filter(item => item && item['正文']).slice(0, targetCount)
if (records.length < targetCount) throw new Error(`Only ${records.length} non-empty records available`) 
const existing = await listExisting(token)
const state = await (async () => { try { return JSON.parse(await readFile(statePath, 'utf8')) } catch { return { schema: 1, assets: {} } } })()
let created = 0
let updated = 0
let skipped = 0
const failures = []
let cursor = 0
let completed = 0
let stateWrites = Promise.resolve()

async function checkpoint() {
  stateWrites = stateWrites.then(() => writeFile(statePath, JSON.stringify(state, null, 2) + '\n'))
  await stateWrites
}

async function importOne(index) {
  const item = records[index]
  const assetId = String(item['案例ID'])
  try {
    const prior = state.assets[assetId]
    if (prior?.knowledge_id) {
      skipped += 1
      return
    }
    const content = contentOf(item)
    const revision = sha(content)
    const title = titleOf(item)
    let knowledge = existing.get(assetId)
    if (knowledge?.id) {
      await request(`/knowledge/manual/${encodeURIComponent(knowledge.id)}`, token, 'PUT', { content, status: 'publish' })
      updated += 1
    } else {
      knowledge = await request(`/knowledge-bases/${encodeURIComponent(kbId)}/knowledge/manual`, token, 'POST', {
        title,
        content,
        status: 'publish',
        channel: 'hci-json-sample-100',
        process_config: { summary_enabled: false, question_generation_config: { enabled: false } },
      })
      created += 1
    }
    await request(`/knowledge/${encodeURIComponent(knowledge.id)}`, token, 'PUT', {
      title,
      custom_metadata: {
        asset_id: `hci-case-${assetId}`,
        source_case_id: assetId,
        asset_type: 'case',
        revision,
        source_package: 'HCI.json',
        source_updated_at: item['更新时间'] || null,
      },
    })
    state.assets[assetId] = { knowledge_id: knowledge.id, revision, title, status: 'submitted' }
    await checkpoint()
  } catch (error) {
    failures.push({ asset_id: assetId, error: error instanceof Error ? error.message : String(error) })
  } finally {
    completed += 1
    if (completed % 100 === 0 || completed === records.length) {
      console.log(`[import] ${completed}/${records.length} created=${created} updated=${updated} skipped=${skipped} failed=${failures.length}`)
    }
  }
}

async function worker() {
  while (true) {
    const index = cursor
    cursor += 1
    if (index >= records.length) return
    await importOne(index)
  }
}

await Promise.all(Array.from({ length: Math.min(concurrency, records.length) }, () => worker()))
await stateWrites
console.log(JSON.stringify({ kb_id: kbId, selected: records.length, created, updated, skipped, failed: failures.length, failures, state: statePath }, null, 2))
if (failures.length) process.exitCode = 1
