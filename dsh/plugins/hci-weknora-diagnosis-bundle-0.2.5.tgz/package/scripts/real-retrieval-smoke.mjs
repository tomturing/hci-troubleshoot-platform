#!/usr/bin/env node
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const { WeknoraClient, resolveConfig } = await import(require.resolve('@wxg-prc-cpg/dsh-weknora'))

function list(value) {
  return String(value || '').split(',').map(item => item.trim()).filter(Boolean)
}

const caseIds = list(process.env.WEKNORA_KB_CASE_IDS)
const playbookIds = list(process.env.WEKNORA_KB_PLAYBOOK_IDS)
const knowledgeBaseIds = [...new Set([...caseIds, ...playbookIds])]
if (!process.env.WEKNORA_API_KEY || knowledgeBaseIds.length === 0) {
  throw new Error('WEKNORA_API_KEY and at least one HCI KB id are required')
}

const config = resolveConfig({
  baseUrl: process.env.WEKNORA_BASE_URL,
  apiKey: process.env.WEKNORA_API_KEY,
  knowledgeBaseIds,
  resourceUrls: 'handle',
  tools: { listKnowledgeBases: true, search: true, readDocument: true, ask: false },
})
const client = new WeknoraClient(config)
const signal = AbortSignal.timeout(120000)

function distinctDocuments(results, limit = 5) {
  const seen = new Set()
  const documents = []
  for (const result of results) {
    if (typeof result.knowledge_id !== 'string' || seen.has(result.knowledge_id)) continue
    seen.add(result.knowledge_id)
    documents.push({
      knowledge_id: result.knowledge_id,
      title: result.knowledge_title || result.knowledge_filename || '',
      score: result.score,
    })
    if (documents.length >= limit) break
  }
  return documents
}

const checks = [
  { kind: 'case', query: 'Windows2008迁移到aCloud后虚拟机无法开机', scope: knowledgeBaseIds, expected: 'HCI-15447' },
  { kind: 'case', query: '外置存储链路抖动导致虚拟机 IO 超时', scope: caseIds },
  { kind: 'case', query: '虚拟机开关机异常排查', scope: knowledgeBaseIds },
  { kind: 'case', query: 'BMC 管理口异常排查', scope: knowledgeBaseIds },
]
const output = []
for (const check of checks) {
  const results = await client.search({ query: check.query, knowledgeBaseIds: check.scope, knowledgeIds: [] }, signal)
  const documents = distinctDocuments(results)
  if (documents.length === 0) throw new Error(`${check.kind} query returned no documents: ${check.query}`)
  if (check.expected && !documents.slice(0, 3).some(item => item.title.includes(check.expected))) {
    throw new Error(`${check.expected} not found in top 3 for ${check.query}: ${documents.map(item => item.title).join(' | ')}`)
  }
  output.push({ kind: check.kind, query: check.query, documents })
}

const first = output[0].documents[0]
const document = await client.getDocument(first.knowledge_id, signal)
const chunks = await client.listChunks({ knowledgeId: first.knowledge_id, page: 1, pageSize: 5 }, signal)
const bases = await client.listKnowledgeBases(signal)
const visibleIds = new Set(bases.map(item => item.id))
if (!knowledgeBaseIds.every(id => visibleIds.has(id))) throw new Error('runtime key cannot see every configured HCI KB')

console.log(JSON.stringify({
  status: 'passed',
  knowledge_bases: bases.filter(item => knowledgeBaseIds.includes(item.id)).map(item => ({ id: item.id, name: item.name })),
  checks: output,
  read_document: {
    knowledge_id: first.knowledge_id,
    title: document.title,
    total_chunks: chunks.total,
    returned_chunks: chunks.chunks.length,
  },
}, null, 2))
