#!/usr/bin/env node
import { createHash } from 'node:crypto'
import { readFile } from 'node:fs/promises'
import { basename, resolve } from 'node:path'

function parseArgs(argv) {
  const args = {}
  for (let index = 0; index < argv.length; index += 2) {
    const flag = argv[index]
    const value = argv[index + 1]
    if (!flag?.startsWith('--') || !value) throw new Error('Usage: verify-import-state.mjs --knowledge-root PATH --state FILE')
    args[flag.slice(2).replace(/-([a-z])/g, (_all, char) => char.toUpperCase())] = value
  }
  if (!args.knowledgeRoot || !args.state) throw new Error('--knowledge-root and --state are required')
  return args
}

function digest(text) {
  return createHash('sha256').update(text.replace(/\r\n/g, '\n')).digest('hex')
}

async function manifestAssets(root, kind) {
  const manifest = await readFile(resolve(root, `manifests/${kind}-manifest.yaml`), 'utf8')
  const outputs = [...manifest.matchAll(/^\s+output:\s*["']?([^"'\r\n]+?)["']?\s*$/gm)]
    .map(match => match[1].trim())
  return outputs.map(output => ({
    assetId: basename(output, '.md'),
    type: kind === 'case' ? 'case' : 'playbook',
    path: resolve(root, output),
  }))
}

async function main() {
  const args = parseArgs(process.argv.slice(2))
  const state = JSON.parse(await readFile(resolve(args.state), 'utf8'))
  const expected = [
    ...await manifestAssets(args.knowledgeRoot, 'case'),
    ...await manifestAssets(args.knowledgeRoot, 'playbook'),
  ]
  const expectedIds = new Set(expected.map(item => item.assetId))
  const stateIds = new Set(Object.keys(state.assets ?? {}))
  const errors = []
  for (const item of expected) {
    const record = state.assets?.[item.assetId]
    if (!record) {
      errors.push(`${item.assetId}: missing state record`)
      continue
    }
    if (record.type !== item.type) errors.push(`${item.assetId}: type ${record.type} != ${item.type}`)
    if (record.status !== 'published') errors.push(`${item.assetId}: status ${record.status}`)
    if (typeof record.knowledge_id !== 'string' || !record.knowledge_id) errors.push(`${item.assetId}: missing knowledge_id`)
    const revision = digest(await readFile(item.path, 'utf8'))
    if (record.revision !== revision) errors.push(`${item.assetId}: revision mismatch`)
  }
  for (const id of stateIds) if (!expectedIds.has(id)) errors.push(`${id}: state record not present in manifests`)
  const counts = {
    expected: expected.length,
    state: stateIds.size,
    cases: expected.filter(item => item.type === 'case').length,
    playbooks: expected.filter(item => item.type === 'playbook').length,
    errors: errors.length,
  }
  console.log(JSON.stringify({ ...counts, sample_errors: errors.slice(0, 50) }, null, 2))
  if (errors.length) process.exitCode = 1
}

main().catch(error => {
  console.error(error instanceof Error ? error.stack : String(error))
  process.exitCode = 1
})
