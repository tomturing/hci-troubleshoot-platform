#!/usr/bin/env node
import { access, mkdir, rm, writeFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { SCENARIOS, scenarioFiles } from './log-package-scenarios.mjs'

const workspace = process.argv[2] ? resolve(process.argv[2]) : undefined
const force = process.argv.includes('--force')
if (!workspace) throw new Error('Usage: materialize-log-packages.mjs WORKSPACE [--force]')
await access(workspace)

for (const scenario of SCENARIOS) {
  const targetRoot = resolve(workspace, scenario.task_directory)
  if (!force) {
    try {
      await access(targetRoot)
      throw new Error(`Target already exists: ${targetRoot}; pass --force to refresh expected files`)
    } catch (error) {
      if (error?.code !== 'ENOENT') throw error
    }
  } else {
    await rm(targetRoot, { recursive: true, force: true })
  }
  for (const [relativePath, content] of Object.entries(scenarioFiles(scenario))) {
    if (relativePath === 'scenario.json') continue
    const target = resolve(targetRoot, relativePath)
    await mkdir(dirname(target), { recursive: true })
    await writeFile(target, content, 'utf8')
  }
}

console.log(JSON.stringify({
  status: 'materialized',
  workspace,
  scenarios: SCENARIOS.map(({ id, task_directory }) => ({ id, task_directory })),
}, null, 2))
