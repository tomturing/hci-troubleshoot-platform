#!/usr/bin/env node
import assert from 'node:assert/strict'
import { pathToFileURL, fileURLToPath } from 'node:url'
import { dirname, resolve } from 'node:path'
import { readFile } from 'node:fs/promises'
import { inventory, read, search } from '../integration/evidence-tools.mjs'
import { SCENARIOS, scenarioFiles, scenarioManifest } from './log-package-scenarios.mjs'

const packageRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..')

function validateContract(scenario) {
  const expected = scenario.expectation
  if (scenario.category === 'exact') assert.ok(expected.required_case_ids.length > 0)
  if (scenario.category === 'analogy') {
    assert.equal(expected.required_case_ids.length, 0)
    assert.ok(expected.helpful_case_ids.length > 0)
  }
  if (scenario.category === 'none' || scenario.category === 'insufficient') {
    assert.equal(expected.required_case_ids.length, 0)
    assert.equal(expected.helpful_case_ids.length, 0)
  }
  if (scenario.category === 'multiple') assert.equal(expected.root_cause_status, 'multiple')
  if (scenario.category === 'insufficient') assert.equal(expected.root_cause_status, 'undetermined')
  if (scenario.category === 'rejected-similarity') assert.ok(expected.rejected_case_ids.length > 0)
}

export async function validateMatrix(root = resolve(packageRoot, 'testdata/log-packages'), options = {}) {
  const results = []
  for (const scenario of SCENARIOS) {
    validateContract(scenario)
    const scenarioRoot = resolve(root, options.materialized ? scenario.task_directory : scenario.id)
    const allExpectedFiles = scenarioFiles(scenario)
    const expectedFiles = options.materialized
      ? Object.fromEntries(Object.entries(allExpectedFiles).filter(([path]) => path !== 'scenario.json'))
      : allExpectedFiles
    if (!options.materialized) {
      const manifest = JSON.parse(await readFile(resolve(scenarioRoot, 'scenario.json'), 'utf8'))
      assert.deepEqual(manifest, scenarioManifest(scenario), `${scenario.id}: scenario.json drifted`)
    }

    const roots = { root: scenarioRoot, sourceRoot: undefined }
    const found = await inventory(roots, { pattern: '*', limit: 200 })
    assert.equal(found.inventory_complete, true, `${scenario.id}: inventory incomplete`)
    assert.deepEqual(found.files, Object.keys(expectedFiles).sort(), `${scenario.id}: unexpected file set`)

    for (const [relativePath, expectedContent] of Object.entries(expectedFiles)) {
      assert.equal(await readFile(resolve(scenarioRoot, relativePath), 'utf8'), expectedContent, `${scenario.id}: ${relativePath} drifted`)
    }

    const citations = []
    for (const path of scenario.evidence_files) {
      const evidence = await read(roots, { path, start_line: 1, line_count: 400 })
      assert.match(evidence.citation_id, /^E:[0-9a-f]{20}:[0-9a-f]{12}:[0-9a-f]{16}:L1-\d+$/)
      citations.push(evidence.citation_id)
    }

    for (const probe of scenario.probes) {
      const searched = await search(roots, { query: probe.query, limit: 20 })
      assert.ok(searched.matches.some(match => match.path === probe.path), `${scenario.id}: probe not found: ${probe.query}`)
    }

    results.push({
      id: scenario.id,
      category: scenario.category,
      files: found.matched_count,
      evidence_files: citations.length,
      probes: scenario.probes.length,
    })
  }
  return { status: 'passed', root, scenarios: results }
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  const materialized = process.argv.includes('--materialized')
  const rootArgument = process.argv.slice(2).find(value => value !== '--materialized')
  console.log(JSON.stringify(await validateMatrix(rootArgument ? resolve(rootArgument) : undefined, { materialized }), null, 2))
}
