#!/usr/bin/env node
import assert from 'node:assert/strict'
import { readdir, readFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { SCENARIOS } from './log-package-scenarios.mjs'

const packageRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const allowedStatuses = new Set(['confirmed', 'probable', 'undetermined', 'multiple', 'not_reproduced'])
const allowedRelationships = new Set(['exact', 'analogical', 'none', 'conflicting', 'rejected_similarity'])

function text(result) {
  return [...result.root_causes.map(item => item.summary), ...result.limitations].join('\n')
}

export function validateScenarioResult(scenario, result) {
  assert.equal(result.schema, 1, `${scenario.id}: result schema`)
  assert.equal(result.scenario_id, scenario.id, `${scenario.id}: scenario id`)
  assert.ok(allowedStatuses.has(result.root_cause_status), `${scenario.id}: invalid root_cause_status`)
  assert.ok(allowedRelationships.has(result.kb_relationship), `${scenario.id}: invalid kb_relationship`)
  assert.ok(Array.isArray(result.root_causes), `${scenario.id}: root_causes must be an array`)
  assert.ok(Array.isArray(result.kb_case_ids), `${scenario.id}: kb_case_ids must be an array`)
  assert.ok(Array.isArray(result.limitations), `${scenario.id}: limitations must be an array`)
  assert.equal(result.root_cause_status, scenario.expectation.root_cause_status, `${scenario.id}: root cause status`)
  assert.equal(result.kb_relationship, scenario.expectation.kb_relationship, `${scenario.id}: KB relationship`)

  const reportText = text(result)
  for (const pattern of scenario.expectation.root_cause_patterns) {
    assert.match(reportText, new RegExp(pattern, 'i'), `${scenario.id}: missing root cause pattern ${pattern}`)
  }
  for (const pattern of scenario.expectation.limitation_patterns) {
    assert.match(reportText, new RegExp(pattern, 'i'), `${scenario.id}: missing limitation pattern ${pattern}`)
  }
  for (const id of scenario.expectation.required_case_ids) {
    assert.ok(result.kb_case_ids.includes(id), `${scenario.id}: missing required case ${id}`)
  }
  for (const id of scenario.expectation.helpful_case_ids) {
    assert.ok(result.kb_case_ids.includes(id), `${scenario.id}: missing helpful case ${id}`)
  }
  if (scenario.expectation.kb_relationship === 'none') {
    assert.equal(result.kb_case_ids.length, 0, `${scenario.id}: no-match result must not claim a case`)
  }
  if (result.root_cause_status === 'confirmed' || result.root_cause_status === 'probable' || result.root_cause_status === 'multiple') {
    assert.ok(result.root_causes.length > 0, `${scenario.id}: root cause entries required`)
    for (const cause of result.root_causes) {
      assert.ok(Array.isArray(cause.evidence_citations) && cause.evidence_citations.some(value => /^E:/.test(value)),
        `${scenario.id}: every asserted cause needs an E citation`)
    }
  }
  if (result.root_cause_status === 'undetermined') {
    assert.equal(result.root_causes.length, 0, `${scenario.id}: undetermined result must not assert a cause`)
  }
  if (result.root_cause_status === 'multiple') {
    assert.ok(result.root_causes.length >= 2, `${scenario.id}: multiple result needs at least two causes`)
  }
  return { id: scenario.id, status: 'passed' }
}

export async function validateResults(resultRoot = resolve(packageRoot, 'testdata/log-package-results')) {
  const names = new Set(await readdir(resultRoot))
  const validated = []
  for (const scenario of SCENARIOS) {
    const filename = `${scenario.id}.json`
    assert.ok(names.has(filename), `missing result: ${filename}`)
    const result = JSON.parse(await readFile(resolve(resultRoot, filename), 'utf8'))
    validated.push(validateScenarioResult(scenario, result))
  }
  return { status: 'passed', root: resultRoot, scenarios: validated }
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  const root = process.argv[2] ? resolve(process.argv[2]) : undefined
  console.log(JSON.stringify(await validateResults(root), null, 2))
}
