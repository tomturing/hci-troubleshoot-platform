#!/usr/bin/env node
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const { WeknoraClient, resolveConfig } = await import(require.resolve('@wxg-prc-cpg/dsh-weknora'))

const apiKey = process.env.WEKNORA_API_KEY
const baseUrl = process.env.WEKNORA_BASE_URL
const knowledgeBaseIds = String(process.env.WEKNORA_HCI_AGENT_KB_IDS || '').split(',').filter(Boolean)
const quickAgentId = process.env.WEKNORA_HCI_QUICK_AGENT_ID
const reasoningAgentId = process.env.WEKNORA_HCI_REASONING_AGENT_ID
const includeAnswers = process.argv.includes('--full')
if (!apiKey || !baseUrl || !quickAgentId || !reasoningAgentId || knowledgeBaseIds.length === 0) {
  throw new Error('WeKnora HCI agent environment is incomplete')
}

const client = new WeknoraClient(resolveConfig({
  baseUrl, apiKey, knowledgeBaseIds, requestTimeoutMs: 30000, chatTimeoutMs: 300000,
  maxResults: 12, resourceUrls: 'handle',
}))

async function ask(agentId, title, query) {
  const signal = AbortSignal.timeout(300000)
  const sessionId = await client.createSession(title, signal)
  const result = await client.ask({
    sessionId, query, knowledgeBaseIds, agentId, webSearch: false,
  }, signal)
  return {
    session_id: result.sessionId,
    ...(includeAnswers ? { answer: result.answer.trim() } : {}),
    answer_preview: result.answer.trim().slice(0, 500),
    answer_chars: result.answer.trim().length,
    references: result.references.map(item => ({
      knowledge_id: item.knowledge_id,
      title: item.knowledge_title || item.knowledge_filename || '',
      chunk_index: item.chunk_index,
    })),
    tool_calls: result.toolCalls,
  }
}

const quickQuery = 'HCI 平台有虚拟机出现卡顿。当前只确认现象，影响范围、错误码、CPU、内存、存储和网络指标都待核。请根据 test 知识库给出最有区分度的只读排查思路，列出支持信号、反证信号和案例出处。'
const reasoningQuery = 'HCI 虚拟机卡顿，需要区分共享存储路径异常、宿主机 CPU 争用、单虚拟机资源或磁盘问题。请基于 test 知识库进行跨案例研判，提出最少的只读检查，说明每种结果会支持或削弱哪个解释，并列出实际来源。'

const quick = await ask(quickAgentId, 'HCI quick-answer smoke', quickQuery)
const reasoning = await ask(reasoningAgentId, 'HCI smart-reasoning smoke', reasoningQuery)
console.log(JSON.stringify({ status: 'passed', quick, reasoning }, null, 2))
