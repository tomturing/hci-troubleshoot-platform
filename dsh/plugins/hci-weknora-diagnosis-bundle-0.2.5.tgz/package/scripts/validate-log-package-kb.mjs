#!/usr/bin/env node
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import { SCENARIOS } from './log-package-scenarios.mjs'

const require = createRequire(import.meta.url)
const { WeknoraClient, resolveConfig } = await import(require.resolve('@wxg-prc-cpg/dsh-weknora'))

const apiKey = process.env.WEKNORA_API_KEY
const baseUrl = process.env.WEKNORA_BASE_URL
const knowledgeBaseIds = String(process.env.WEKNORA_KB_CASE_IDS || '').split(',').filter(Boolean)
if (!apiKey || !baseUrl || knowledgeBaseIds.length === 0) {
  throw new Error('WEKNORA_API_KEY, WEKNORA_BASE_URL and WEKNORA_KB_CASE_IDS are required')
}

const client = new WeknoraClient(resolveConfig({
  baseUrl,
  apiKey,
  knowledgeBaseIds,
  requestTimeoutMs: 30000,
  maxResults: 12,
  resourceUrls: 'handle',
}))

const validated = []
for (const scenario of SCENARIOS.filter(item => item.retrieval)) {
  const rows = await client.search({
    query: scenario.retrieval.query,
    knowledgeBaseIds,
    knowledgeIds: [],
  }, AbortSignal.timeout(30000))
  const unique = []
  const seen = new Set()
  for (const row of rows) {
    if (seen.has(row.knowledge_id)) continue
    seen.add(row.knowledge_id)
    unique.push(row)
  }
  const titles = unique.map(row => row.knowledge_title || row.knowledge_filename || '')
  for (const caseId of scenario.retrieval.required_case_ids) {
    assert.ok(titles.some(title => title.includes(caseId)), `${scenario.id}: ${caseId} not retrieved`)
  }
  for (const pattern of scenario.retrieval.forbidden_title_patterns) {
    assert.ok(titles.every(title => !new RegExp(pattern, 'i').test(title)), `${scenario.id}: synthetic exact match appeared for ${pattern}`)
  }
  validated.push({
    id: scenario.id,
    required_case_ids: scenario.retrieval.required_case_ids,
    unique_results: unique.length,
    top_titles: titles.slice(0, 5),
  })
}

console.log(JSON.stringify({ status: 'passed', scenarios: validated }, null, 2))
