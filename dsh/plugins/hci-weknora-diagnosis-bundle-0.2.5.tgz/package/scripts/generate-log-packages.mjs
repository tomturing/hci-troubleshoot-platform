#!/usr/bin/env node
import { mkdir, rm, writeFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { SCENARIOS, scenarioFiles } from './log-package-scenarios.mjs'

const packageRoot = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const outputRoot = resolve(packageRoot, 'testdata/log-packages')

for (const scenario of SCENARIOS) {
  await rm(resolve(outputRoot, scenario.id), { recursive: true, force: true })
  for (const [relativePath, content] of Object.entries(scenarioFiles(scenario))) {
    const target = resolve(outputRoot, scenario.id, relativePath)
    await mkdir(dirname(target), { recursive: true })
    await writeFile(target, content, 'utf8')
  }
}

console.log(JSON.stringify({ status: 'generated', root: outputRoot, scenarios: SCENARIOS.length }, null, 2))
