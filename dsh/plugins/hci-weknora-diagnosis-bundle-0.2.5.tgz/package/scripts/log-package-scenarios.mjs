/** Synthetic HCI support packages and their diagnosis acceptance contracts. */

export const LOG_PACKAGE_SCHEMA = 1

const commonCollection = `collector=hci-matrix-fixture/1\ncollection_mode=read-only\ntimezone=Asia/Shanghai\n`

export const SCENARIOS = [
  {
    id: 'exact-known-case',
    task_directory: 'Q2099112000001',
    title: '已知案例精确命中：第三方盘关闭写缓存误报',
    category: 'exact',
    problem: '更换故障硬盘后页面提示关闭写缓存失败，但后台状态显示写缓存已经关闭。',
    prompt: '分析换盘失败现象，确认页面报错是否代表写缓存仍开启，并给出有现场证据和案例依据的结论。',
    expectation: {
      root_cause_status: 'confirmed',
      kb_relationship: 'exact',
      required_case_ids: ['HCI-44561'],
      helpful_case_ids: [],
      rejected_case_ids: [],
      root_cause_patterns: ['三方盘|第三方盘', '兼容性', '写缓存'],
      limitation_patterns: [],
    },
    retrieval: {
      query: '更换故障硬盘 关闭写缓存操作失败 写缓存实际已关闭 三方盘兼容性',
      required_case_ids: ['HCI-44561'],
      forbidden_title_patterns: [],
    },
    probes: [
      { query: 'write cache is: disabled', path: 'sp_192.0.2.11/cmd-output/smart_sdf.txt' },
      { query: 'HWUTIL_WCACHE_SET_FAILED', path: 'sp_192.0.2.11/log/disk-replace.log' },
    ],
    evidence_files: [
      'sp_192.0.2.11/cmd-output/smart_sdf.txt',
      'sp_192.0.2.11/log/disk-replace.log',
    ],
    files: {
      'metadata/summary.txt': `工单：MATRIX-EXACT-001\n现象：替换 /dev/sdf 时页面提示“关闭写缓存操作失败”。\n时间：2026-11-18 09:41:22 +08:00\n影响：仅新更换磁盘；虚拟机业务正常。\n采集完整性：换盘任务、smartctl 与 hwutil 输出完整。\n`,
      'metadata/collection.txt': commonCollection + 'complete=true\nnodes=192.0.2.11\n',
      'sp_192.0.2.11/cmd-output/smart_sdf.txt': `smartctl 7.4 /dev/sdf\nDevice Model: MATRIX THIRD-PARTY SAS\nSerial Number: MATRIX-SDF-001\nwrite cache is: disabled\nSMART overall-health self-assessment test result: PASSED\n`,
      'sp_192.0.2.11/cmd-output/hwutil_wcache.txt': `2026-11-18T09:41:21+08:00 command=hwutil disk -s wcache=off /dev/sdf\nexit_code=1\nstderr=vendor mode page response is not compatible\n`,
      'sp_192.0.2.11/log/disk-replace.log': `2026-11-18T09:41:21+08:00 task=replace-disk device=/dev/sdf stage=disable-write-cache code=HWUTIL_WCACHE_SET_FAILED\n2026-11-18T09:41:22+08:00 ui_message="关闭写缓存操作失败"\n2026-11-18T09:44:07+08:00 task=replace-disk device=/dev/sdf retry=1 result=success rebuild=started\n`,
    },
  },
  {
    id: 'conflicting-known-cases',
    task_directory: 'Q2099112000002',
    title: '多个已知案例候选：存储路径抖动与 CPU 争用',
    category: 'conflict',
    problem: '同主机多台虚拟机同时卡顿，知识库可能同时召回共享存储异常和宿主机 CPU 争用案例。',
    prompt: '区分共享存储路径抖动和宿主机 CPU 争用，必须使用现场时间相关性选择或否定案例。',
    expectation: {
      root_cause_status: 'confirmed',
      kb_relationship: 'conflicting',
      required_case_ids: [],
      helpful_case_ids: [],
      rejected_case_ids: [],
      root_cause_patterns: ['存储|multipath|路径', '抖动|切换|故障'],
      limitation_patterns: [],
    },
    probes: [
      { query: 'remaining active paths: 0', path: 'sp_192.0.2.21/log/multipathd.log' },
      { query: 'idle=87.4', path: 'sp_192.0.2.21/cmd-output/performance_host_snapshot.txt' },
    ],
    evidence_files: [
      'sp_192.0.2.21/log/multipathd.log',
      'sp_192.0.2.21/cmd-output/performance_host_snapshot.txt',
      'sp_192.0.2.21/log/vm-io.log',
    ],
    files: {
      'metadata/summary.txt': `工单：MATRIX-CONFLICT-002\n现象：三台虚拟机在 10:12:31 同时出现 IO timeout，约 47 秒后恢复。\n候选：共享存储路径异常；宿主机 CPU 争用。\n采集完整性：故障窗口 multipath、主机性能和 VM IO 日志完整。\n`,
      'metadata/collection.txt': commonCollection + 'complete=true\nnodes=192.0.2.21\n',
      'sp_192.0.2.21/log/multipathd.log': `2026-11-18T10:12:30+08:00 sdx: mark as failed\n2026-11-18T10:12:31+08:00 mpathb: remaining active paths: 0\n2026-11-18T10:13:17+08:00 sdy: reinstated\n2026-11-18T10:13:18+08:00 mpathb: active paths: 1\n`,
      'sp_192.0.2.21/cmd-output/performance_host_snapshot.txt': `timestamp=2026-11-18T10:12:31+08:00 cpu_user=5.1 cpu_system=7.5 idle=87.4 load1=2.10 runnable=3\ntimestamp=2026-11-18T10:13:18+08:00 cpu_user=4.8 cpu_system=6.9 idle=88.3 load1=1.92 runnable=2\n`,
      'sp_192.0.2.21/log/vm-io.log': `2026-11-18T10:12:31+08:00 vm=erp-db-01 io_timeout disk=vdb\n2026-11-18T10:12:31+08:00 vm=erp-app-02 io_timeout disk=vda\n2026-11-18T10:12:32+08:00 vm=his-db-03 io_timeout disk=vdc\n2026-11-18T10:13:18+08:00 all_vms_io_resumed=true\n`,
    },
  },
  {
    id: 'analogical-kb-help',
    task_directory: 'Q2099112000003',
    title: '无精确案例但可类比：NebulaOS 迁移后缺失 vortex_scsi 驱动',
    category: 'analogy',
    problem: '虚构的 NebulaOS 3.2 迁移后无法启动；KB 不会有该系统和驱动的精确案例，但既有迁移后驱动缺失案例的核查思路可迁移。',
    prompt: '判断迁移后无法启动的原因；没有同系统精确案例时，说明哪些已知案例思路可以类比、哪些步骤不能照搬。',
    expectation: {
      root_cause_status: 'confirmed',
      kb_relationship: 'analogical',
      required_case_ids: [],
      helpful_case_ids: ['HCI-39058'],
      rejected_case_ids: [],
      root_cause_patterns: ['vortex_scsi|NebulaOS', 'initramfs|驱动'],
      limitation_patterns: ['类比|不.*照搬|系统.*不同'],
    },
    retrieval: {
      query: 'NebulaOS 3.2 迁移 HCI 无法启动 vortex_scsi initramfs 驱动缺失',
      required_case_ids: ['HCI-39058'],
      forbidden_title_patterns: ['NebulaOS', 'vortex_scsi'],
    },
    probes: [
      { query: 'vortex_scsi module not found', path: 'vm_nebula32/console/boot.log' },
      { query: 'vortex_scsi.ko: MISSING', path: 'vm_nebula32/offline/initramfs-inspect.txt' },
    ],
    evidence_files: ['vm_nebula32/console/boot.log', 'vm_nebula32/offline/initramfs-inspect.txt'],
    files: {
      'metadata/summary.txt': `工单：MATRIX-ANALOGY-003\n现象：虚构的 NebulaOS 3.2 从 MatrixHV 迁移到 HCI 后进入 initramfs emergency shell。\n范围：单台迁移虚拟机；同主机其他 VM 正常。\n采集完整性：串口启动日志与离线 initramfs 检查完整。\n说明：NebulaOS、MatrixHV 和 vortex_scsi 均为测试构造，不应存在于生产 KB。\n`,
      'metadata/collection.txt': commonCollection + 'complete=true\nvm=nebula32-matrix\n',
      'vm_nebula32/console/boot.log': `2026-11-18T11:20:06+08:00 initramfs: root volume /dev/nebula/root does not exist\n2026-11-18T11:20:07+08:00 modprobe: FATAL: Module vortex_scsi not found in directory /lib/modules/3.2.0-matrix\n2026-11-18T11:20:07+08:00 vortex_scsi module not found; boot disk unavailable\n`,
      'vm_nebula32/offline/initramfs-inspect.txt': `image=/boot/initramfs-3.2.0-matrix.img\nvortex_pci.ko: present\nvortex_blk.ko: present\nvortex_scsi.ko: MISSING\nroot_fstab=/dev/nebula/root\n`,
      'sp_192.0.2.31/cmd-output/storage_health.txt': `timestamp=2026-11-18T11:20:00+08:00 cluster_storage=healthy path_failures=0 latency_ms_p99=2.8\n`,
    },
  },
  {
    id: 'no-kb-match',
    task_directory: 'Q2099112000004',
    title: '完全无已知案例：新加速卡纪元回退保护触发',
    category: 'none',
    problem: '新型号加速卡固件触发未收录的 AURORA_EPOCH_ROLLBACK 保护，VM 图形服务被冻结。',
    prompt: '基于现场证据给出假设；KB 无匹配时必须明确未知，不得伪造案例 ID 或把弱相似结果写成既有结论。',
    expectation: {
      root_cause_status: 'probable',
      kb_relationship: 'none',
      required_case_ids: [],
      helpful_case_ids: [],
      rejected_case_ids: [],
      root_cause_patterns: ['AURORA_EPOCH_ROLLBACK', '固件|firmware'],
      limitation_patterns: ['无.*案例|未收录|待.*确认|未知'],
    },
    probes: [
      { query: 'AURORA_EPOCH_ROLLBACK', path: 'sp_192.0.2.41/log/accelerator.log' },
      { query: 'reset_required=true', path: 'sp_192.0.2.41/cmd-output/auroractl_status.txt' },
    ],
    evidence_files: ['sp_192.0.2.41/log/accelerator.log', 'sp_192.0.2.41/cmd-output/auroractl_status.txt'],
    files: {
      'metadata/summary.txt': `工单：MATRIX-NONE-004\n现象：升级 Aurora-X1 加速卡固件后，使用该卡的 VM 图形服务冻结。\n范围：仅绑定同一卡的两台 VM。\n采集完整性：固件事件、设备状态和对照 VM 状态完整。\n说明：AURORA-X1 与错误码均为测试构造，不应存在于生产 KB。\n`,
      'metadata/collection.txt': commonCollection + 'complete=true\nnodes=192.0.2.41\n',
      'sp_192.0.2.41/log/accelerator.log': `2026-11-18T12:00:01+08:00 device=aurora0 firmware=9.9.0-matrix event=AURORA_EPOCH_ROLLBACK observed_epoch=41 expected_epoch=42 action=freeze_contexts\n2026-11-18T12:00:02+08:00 affected_vms=matrix-gpu-01,matrix-gpu-02\n`,
      'sp_192.0.2.41/cmd-output/auroractl_status.txt': `device=aurora0 health=degraded contexts=frozen reset_required=true reason=AURORA_EPOCH_ROLLBACK\ndevice=aurora1 health=ok contexts=running reset_required=false\n`,
      'sp_192.0.2.41/cmd-output/control_vm_status.txt': `vm=matrix-control-01 accelerator=none service=running timestamp=2026-11-18T12:00:03+08:00\n`,
    },
  },
  {
    id: 'insufficient-evidence',
    task_directory: 'Q2099112000005',
    title: '证据不足：只有用户主观卡顿描述',
    category: 'insufficient',
    problem: '用户报告一台 VM 卡顿，但收集包缺少故障时间窗内 CPU、内存、存储、网络与 VM 日志。',
    prompt: '评估当前材料是否足以定位根因，并给出最少的下一步只读采集要求；不得确认具体根因。',
    expectation: {
      root_cause_status: 'undetermined',
      kb_relationship: 'none',
      required_case_ids: [],
      helpful_case_ids: [],
      rejected_case_ids: [],
      root_cause_patterns: [],
      limitation_patterns: ['证据不足|无法.*根因|缺少|待补'],
    },
    probes: [{ query: 'fault_window_metrics=missing', path: 'metadata/collection.txt' }],
    evidence_files: ['metadata/summary.txt', 'metadata/collection.txt'],
    files: {
      'metadata/summary.txt': `工单：MATRIX-INSUFFICIENT-005\n现象：用户称 matrix-vm-01 昨天下午“很卡”，未提供准确时间。\n范围：未知。\n采集完整性：不完整；只采集到当前 uptime。\n`,
      'metadata/collection.txt': commonCollection + 'complete=false\nfault_window=unknown\nfault_window_metrics=missing\nmissing=vm_log,host_cpu,host_memory,storage_latency,network_counters\n',
      'sp_192.0.2.51/cmd-output/uptime.txt': `2026-11-19T09:00:00+08:00 up 120 days, load average: 0.52, 0.61, 0.58\n`,
    },
  },
  {
    id: 'misleading-similarity',
    task_directory: 'Q2099112000006',
    title: '相似案例误导：应用远端对象存储超时并非 HCI 本地存储故障',
    category: 'rejected-similarity',
    problem: '应用日志包含 IO timeout，容易召回 HCI 存储案例；但超时对象是远端 S3，HCI 本地磁盘和多路径均健康。',
    prompt: '识别 IO timeout 的真实边界，验证相似存储案例是否适用；不得把远端对象存储超时归因为 HCI 本地存储。',
    expectation: {
      root_cause_status: 'confirmed',
      kb_relationship: 'rejected_similarity',
      required_case_ids: [],
      helpful_case_ids: [],
      rejected_case_ids: ['HCI storage timeout cases'],
      root_cause_patterns: ['S3|对象存储|远端', '丢包|网络'],
      limitation_patterns: ['不适用|排除|并非'],
    },
    probes: [
      { query: 'endpoint=s3.matrix.example', path: 'vm_app01/log/backup-agent.log' },
      { query: 'packet_loss_percent=38', path: 'sp_192.0.2.61/cmd-output/network_path.txt' },
      { query: 'path_failures=0', path: 'sp_192.0.2.61/cmd-output/local_storage.txt' },
    ],
    evidence_files: [
      'vm_app01/log/backup-agent.log',
      'sp_192.0.2.61/cmd-output/network_path.txt',
      'sp_192.0.2.61/cmd-output/local_storage.txt',
    ],
    files: {
      'metadata/summary.txt': `工单：MATRIX-MISLEAD-006\n现象：备份任务报 IO timeout，VM 业务盘读写正常。\n范围：访问 s3.matrix.example 的备份任务。\n采集完整性：应用目标、网络路径、本地存储对照完整。\n`,
      'metadata/collection.txt': commonCollection + 'complete=true\nnodes=192.0.2.61\n',
      'vm_app01/log/backup-agent.log': `2026-11-18T13:15:00+08:00 operation=PUT endpoint=s3.matrix.example object=backup-001 error="IO timeout" elapsed_ms=30000\n2026-11-18T13:15:31+08:00 local_spool_write_ms=4 result=success\n`,
      'sp_192.0.2.61/cmd-output/network_path.txt': `timestamp=2026-11-18T13:15:00+08:00 destination=s3.matrix.example packet_loss_percent=38 rtt_ms_p99=1890\ntimestamp=2026-11-18T13:20:00+08:00 destination=storage-vip.local packet_loss_percent=0 rtt_ms_p99=0.8\n`,
      'sp_192.0.2.61/cmd-output/local_storage.txt': `timestamp=2026-11-18T13:15:00+08:00 path_failures=0 latency_ms_p99=3.1 io_errors=0 health=ok\n`,
    },
  },
  {
    id: 'multiple-root-causes',
    task_directory: 'Q2099112000007',
    title: '并发双根因：单 VM CPU 争用叠加另一 VM 磁盘介质错误',
    category: 'multiple',
    problem: '两台 VM 同时被报告卡顿，但一台受 CPU steal 影响，另一台出现独立磁盘介质错误。',
    prompt: '判断是否存在统一根因；若证据显示两条独立故障链，必须分别报告，不能强行合并。',
    expectation: {
      root_cause_status: 'multiple',
      kb_relationship: 'conflicting',
      required_case_ids: [],
      helpful_case_ids: [],
      rejected_case_ids: [],
      root_cause_patterns: ['CPU|steal|超分', '介质|medium error|磁盘'],
      limitation_patterns: ['独立|两个|分别|非.*统一'],
    },
    probes: [
      { query: 'steal=61.2', path: 'vm_cpu01/cmd-output/mpstat.txt' },
      { query: 'Medium Error', path: 'vm_disk02/log/kernel.log' },
    ],
    evidence_files: ['vm_cpu01/cmd-output/mpstat.txt', 'vm_disk02/log/kernel.log', 'sp_192.0.2.71/cmd-output/host_mapping.txt'],
    files: {
      'metadata/summary.txt': `工单：MATRIX-MULTI-007\n现象：matrix-cpu-01 与 matrix-disk-02 在相近时间均被报告卡顿。\n范围：两台 VM，但症状不同。\n采集完整性：两台 VM 指标、内核日志和宿主映射完整。\n`,
      'metadata/collection.txt': commonCollection + 'complete=true\nnodes=192.0.2.71,192.0.2.72\n',
      'vm_cpu01/cmd-output/mpstat.txt': `2026-11-18T14:00:00+08:00 vm=matrix-cpu-01 usr=25.0 sys=8.1 idle=5.7 steal=61.2\n2026-11-18T14:00:10+08:00 vm=matrix-cpu-01 usr=24.8 sys=7.9 idle=6.0 steal=61.3\n`,
      'vm_disk02/log/kernel.log': `2026-11-18T14:00:04+08:00 sd 0:0:1:0: [sdb] tag#18 FAILED Result: hostbyte=DID_OK driverbyte=DRIVER_SENSE\n2026-11-18T14:00:04+08:00 sd 0:0:1:0: [sdb] Sense Key : Medium Error\n2026-11-18T14:00:05+08:00 blk_update_request: I/O error, dev sdb, sector 9918272\n`,
      'sp_192.0.2.71/cmd-output/host_mapping.txt': `vm=matrix-cpu-01 host=192.0.2.71 cpu_overcommit=8.0 storage_volume=volume-a\nvm=matrix-disk-02 host=192.0.2.72 cpu_overcommit=1.2 storage_volume=volume-b\nshared_failure_domain=false\n`,
    },
  },
]

/** Return the checked-in manifest without the generated file bodies. */
export function scenarioManifest(scenario) {
  const { files: _files, ...manifest } = scenario
  return { schema: LOG_PACKAGE_SCHEMA, ...manifest }
}

/** Return every expected file, including the generated scenario manifest. */
export function scenarioFiles(scenario) {
  return {
    'scenario.json': JSON.stringify(scenarioManifest(scenario), null, 2) + '\n',
    ...scenario.files,
  }
}
