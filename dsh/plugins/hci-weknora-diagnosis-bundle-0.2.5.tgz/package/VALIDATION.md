# HCI WeKnora Bundle 验证记录

日期：2026-11-23（Asia/Shanghai）

## 已确认环境

- WeKnora 源码：`/Users/royin/workspace/ai-ml/WeKnora`，commit `cbdcebabf`。
- 官方 DSH 插件：`@wxg-prc-cpg/dsh-weknora` 0.1.0。
- WeKnora app、docreader、PostgreSQL 已由 full Compose 启动并健康，app 映射到宿主 8080。
- API 未授权请求返回 401，符合当前部署的鉴权要求。
- 初始数据库盘点为 1 个用户、1 个租户、0 把活动 API Key、0 个知识库、0 篇知识；随后已完成下述运行配置，未在日志或本文记录密钥正文。
- `WeKnora-mcp` 容器当前重启中；本 Bundle 不依赖该容器，使用 WeKnora REST/官方 DSH 插件。

## 已完成的代码验证

- 2026-11-26 多 Agent 改动：19 项 Node 测试通过，覆盖根 Agent workflow 权限、直接子 Agent 的只读工具范围、父会话工单绑定、本轮检索开关与共享 E 账本；Harness workflow 工具 34 项测试通过。组合 mock REST 烟测通过，配置断言确认 `fork`、3 并发、20 总数和前台运行。尚未进行真实模型的多 Agent 工单回归；原有真实 Web 回归是单 Agent 轨迹。
- 2026-11-27 发布 0.2.5 安装包：当前 22 项 Node 测试全部通过，`npm run check` 通过；安装包内置 `@wxg-prc-cpg/dsh-weknora@0.1.0`，在空 pnpm store 下离线安装与解析验证通过。

- Node 单元测试：14/14 通过，覆盖固定 Agent/知识库/联网参数、持久 WeCom 目录恢复、E 读取、单库默认检索、文档级 TopN 去重、确认型结论 E 门禁、报告前覆盖预检、单 Agent/工具范围 guard 和日志收集包矩阵。
- 语法检查：运行模块与 `scripts/*.mjs` 全部通过 `node --check`。
- 合成日志矩阵：7/7 通过离线结构、现场信号探针、support 盘点/检索/读取和 E 引用校验；同一批包已物化到 WeCom 工作区的保留 `Q2099112000001`～`Q2099112000007` 目录并再次通过校验。
- 真实 KB 漂移预检：精确场景召回 HCI-44561；虚构 NebulaOS/vortex_scsi 场景未出现伪造的精确标题，同时召回可迁移的 HCI-39058 驱动排查思路。
- 真实 Web 模型回归：`Q2099112000001` 在不暴露 `scenario.json` 的条件下完成 HCI-44561 精确命中；support inventory/read、5 条 E 引用、3 篇 KB TopN 回读、`hci_evidence_status` 和 `hci_finalize(root_cause_status=confirmed)` 均通过。轨迹为 13 步、16 次工具调用、0 工具错误、58.6 秒；未出现 shell/通用文件工具调用。
- v3 导入 dry-run：3,201 Case＋133 Playbook，共 3,334 个 manifest 登记资产；未把 `playbooks/index.md` 误作知识资产。
- npm pack dry-run：Bundle、官方 WeKnora 依赖声明、运行模块、导入脚本和文档可打包。
- 真实 Harness 组合烟测：使用本机 `/Users/royin/workspace/ai-ml/deepseek-harness` 加载 Cordis、ToolRuntime、NativeExecutor、Scope 和官方 WeKnora 0.1.0；通过临时 mock REST 验证直接检索、两个 HCI 智能体工具、支持包 E、`hci_finalize` 和子 Agent 拒绝，模型调用数 0。

## 已完成的真实环境配置与烟测

- 已启动本地 Ollama，安装 `bge-m3`；中文 HCI 文本实测返回 1,024 维向量。
- 当前运行知识范围为 `test`，共 10,196 篇文档且全部 `completed`。该库绑定远程 `bge-m3` Embedding 和 `bge-reranker-v2-m3`。
- 运行 Key 能力为 `retrieve`、`chat`、`read_agents`，知识库白名单只有 `test`。
- DeepSeek Harness `.env` 已写入 WeKnora URL、运行 Key、`test` ID、两个 HCI 智能体 ID 与 `WECOM_AGENT_PRESET=hci-weknora`，文件权限为 600。
- DSH Web profile 已安装新 Bundle并移除旧 `hci-offline-diagnosis-bundle`；旧源码目录保留。组合配置只有 `hci-weknora`。
- DSH Web 已在 `127.0.0.1:3080` 启动，Session BI、WeCom 初始化和企微机器人鉴权成功。
- 已创建 `HCI 案例排查助手`（quick-answer）和 `HCI 案例深度研判助手`（smart-reasoning），两者的唯一知识库均为 `test`，联网、MCP、Skill 和沙箱关闭。
- 快速问答真实测试返回 4 个候选机制、区分性检查和 12 个案例来源，回答 2,993 字符。
- 智能推理真实测试完成跨案例研判，回答 5,856 字符，未触发输出上限。当前 WeKnora Agent SSE 未把内联引用另行汇总到 `references` 数组，回答正文包含实际 `<kb ...>` 引用。
- DSH Bundle 0.2.3 已注册 `hci_quick_ask`、`hci_reasoning_ask` 与 `hci_evidence_status`，并增加 title＋knowledge_id 引用门禁；Harness mock 烟测验证两个 Agent 工具、任务目录 E 和新门禁。
- DSH Bundle 0.2.4 增加阶段一案例检索开关：部署默认值由 `WEKNORA_INVESTIGATION_KB_SEARCH_ENABLED` 控制，机器人消息可用 `weknora排查思路是否检索：是/否` 单轮覆盖；关闭时门禁拒绝 `hci_quick_ask`/`hci_reasoning_ask`，保留阶段二 `hci_kb_search`/`hci_kb_read_document`。Node 测试与 npm pack 校验覆盖。
- 0.2.4 安装包使用 `bundleDependencies` 内置 `@wxg-prc-cpg/dsh-weknora@0.1.0`；在空 pnpm store 下 `pnpm add --offline` 与 `npm install --offline` 均可安装，包内依赖可被 `require.resolve` 和 `agent-tools.mjs` 的 ESM 导入解析。

## 待完成的真实联调

- 通过企微真实消息入口创建 `hci-weknora` Session，验证 Preset 选择、工单目录绑定、真实模型调用和渠道送达；Web 入口的真实模型回归已完成，不再列为待办。
- 执行两阶段、多案例、单一存储类型方案测试和旧插件对照。
