export const name = 'hci-weknora-flow-gate'
export const inject = ['tools']

const ledgers = new WeakMap()
const DEFAULT_TOP_N = 3

function list(value) {
  if (!Array.isArray(value)) return []
  return [...new Set(value.filter(item => typeof item === 'string').map(item => item.trim()).filter(Boolean))]
}

function topN(value) {
  const parsed = Number(value)
  return Number.isSafeInteger(parsed) && parsed >= 1 && parsed <= 20 ? parsed : DEFAULT_TOP_N
}

function sameMembers(left, right) {
  const a = [...left].sort()
  const b = [...right].sort()
  return a.length === b.length && a.every((item, index) => item === b[index])
}

function classifyScope(requested, config) {
  if (requested.length === 0) {
    if (config.caseKnowledgeBaseIds.length > 0 && config.playbookKnowledgeBaseIds.length === 0) return 'case'
    if (config.playbookKnowledgeBaseIds.length > 0 && config.caseKnowledgeBaseIds.length === 0) return 'playbook'
    return undefined
  }
  if (sameMembers(requested, config.caseKnowledgeBaseIds)) return 'case'
  if (sameMembers(requested, config.playbookKnowledgeBaseIds)) return 'playbook'
  return undefined
}

function ledger(agent) {
  let value = ledgers.get(agent)
  if (!value) {
    value = { required: new Set(), read: new Set(), evidence: new Set(), searches: [], documents: new Map() }
    ledgers.set(agent, value)
  }
  return value
}

function resultJson(result) {
  const value = result?.value
  if (value && typeof value === 'object' && !Array.isArray(value) && !Array.isArray(value.content)) return value
  const blocks = value?.content ?? result?.content ?? []
  const text = Array.isArray(blocks) ? blocks.find(block => block?.type === 'text')?.text : undefined
  if (typeof text !== 'string') return undefined
  try { return JSON.parse(text) } catch { return undefined }
}

function candidateDocuments(payload, count) {
  if (!payload || !Array.isArray(payload.results)) return []
  const ids = []
  const seen = new Set()
  for (const hit of payload.results) {
    const id = hit?.knowledge_id
    if (typeof id !== 'string' || !id || seen.has(id)) continue
    seen.add(id)
    ids.push(id)
    if (ids.length >= count) break
  }
  return ids
}

function rememberDocument(state, id, title) {
  if (typeof id !== 'string' || id === '' || typeof title !== 'string') return
  const normalized = title.trim()
  if (normalized === '' || normalized === id) return
  state.documents.set(id, normalized)
}

function rememberDocumentLabels(state, payload) {
  for (const hit of payload?.results ?? []) {
    rememberDocument(state, hit?.knowledge_id, hit?.document)
  }
  for (const document of payload?.documents ?? []) {
    rememberDocument(state, document?.knowledge_id, document?.title)
  }
}

function documentCitations(state, ids) {
  return ids.map(id => ({ knowledge_id: id, title: state.documents.get(id) ?? '' }))
}

function rememberSearch(agent, result, kind, limits) {
  const count = kind === 'playbook' ? limits.playbookTopN : limits.caseTopN
  const payload = resultJson(result)
  const ids = candidateDocuments(payload, count)
  const state = ledger(agent)
  rememberDocumentLabels(state, payload)
  ids.forEach(id => state.required.add(id))
  state.searches.push({ kind, ids })
}

export function validateSummary(agent, summary, rootCauseStatus = 'undetermined') {
  const state = ledger(agent)
  const missing = [...state.required].filter(id => !state.read.has(id))
  const missingCitations = [...state.required].filter(id => state.read.has(id) && !summary.includes(id))
  const missingTitles = [...state.required].filter(id => {
    const title = state.documents.get(id)
    return state.read.has(id) && title && !summary.includes(title)
  })
  const errors = []
  if (missing.length) errors.push(`必须通过 hci_kb_read_document 回读这些候选后才能收尾: ${missing.join(', ')}`)
  if (missingCitations.length) errors.push(`最终报告必须引用已回读 WeKnora 文档 ID: ${missingCitations.join(', ')}`)
  if (missingTitles.length) {
    errors.push(`最终报告必须同时展示已回读 WeKnora 文档标题和 knowledge_id: ${missingTitles.map(id => `${state.documents.get(id)} (${id})`).join(', ')}`)
  }
  const evidenceCited = [...state.evidence].some(id => summary.includes(id))
  if (state.evidence.size > 0 && !evidenceCited) errors.push('最终报告必须包含已读取的当前支持包 E 引用')
  if (rootCauseStatus !== 'undetermined' && state.evidence.size === 0) {
    errors.push('没有当前支持包 E 证据时，root_cause_status 只能是 undetermined')
  }
  return {
    valid: errors.length === 0,
    errors,
    required: [...state.required],
    read: [...state.read],
    documents: documentCitations(state, [...state.required]),
    evidence: [...state.evidence],
    rootCauseStatus,
    searches: state.searches,
  }
}

export function apply(ctx, config = {}) {
  const limits = {
    caseTopN: topN(config.caseTopN),
    playbookTopN: topN(config.playbookTopN),
    caseKnowledgeBaseIds: list(config.caseKnowledgeBaseIds),
    playbookKnowledgeBaseIds: list(config.playbookKnowledgeBaseIds),
  }

  ctx.tools.guard(exec => {
    if (exec.name !== 'hci_kb_search') return undefined
    if (limits.caseKnowledgeBaseIds.length === 0 && limits.playbookKnowledgeBaseIds.length === 0) {
      return 'Configure an HCI knowledge base before HCI knowledge search'
    }
    const requested = list(exec.arguments?.knowledge_base_ids)
    const kind = classifyScope(requested, limits)
    if (!kind) {
      return 'HCI knowledge search must explicitly select exactly the configured Case KB ids or exactly the configured Playbook KB ids; do not mix both types in one search'
    }
    return undefined
  })

  ctx.on('tools/execute', async (exec, next) => {
    const result = await next()
    if (!exec.agent) return result
    if (exec.name === 'hci_kb_search' && !result.isError) {
      const kind = classifyScope(list(exec.arguments?.knowledge_base_ids), limits)
      if (kind) rememberSearch(exec.agent, result, kind, limits)
    }
    if (exec.name === 'hci_kb_read_document' && !result.isError) {
      const id = exec.arguments?.knowledge_id
      if (typeof id === 'string' && id) {
        const state = ledger(exec.agent)
        state.read.add(id)
        const payload = resultJson(result)
        rememberDocument(state, id, payload?.title)
      }
    }
    if ((exec.name === 'mcp__hci_weknora__support_read'
      || exec.name === 'mcp__hci_weknora__support_search') && !result.isError) {
      const payload = resultJson(result)
      const state = ledger(exec.agent)
      if (typeof payload?.citation_id === 'string') state.evidence.add(payload.citation_id)
    }
    return result
  })

  ctx.tools.register({
    name: 'hci_evidence_status',
    description: 'Check HCI evidence and KB-read coverage before drafting the final report. Call this before hci_finalize to avoid rewriting a report around missing reads.',
    parameters: { type: 'object', properties: {}, additionalProperties: false },
    output: {
      schema: { type: 'object' },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
    },
    async execute(_args, exec) {
      const state = ledger(exec.agent)
      return {
        ready: [...state.required].every(id => state.read.has(id)),
        required: [...state.required],
        read: [...state.read],
        missing: [...state.required].filter(id => !state.read.has(id)),
        documents: documentCitations(state, [...state.required]),
        evidence: [...state.evidence],
      }
    },
  })

  ctx.tools.register({
    name: 'hci_finalize',
    description: 'Validate the complete HCI report before final output. All required WeKnora Case/Playbook documents must be read and cited as title (knowledge_id: ID); current support-package evidence must retain E citations.',
    parameters: {
      type: 'object',
      properties: {
        summary: { type: 'string', description: 'The complete final Markdown report.' },
        root_cause_status: {
          type: 'string',
          enum: ['confirmed', 'probable', 'undetermined', 'multiple'],
          description: 'Evidence-qualified conclusion status. Without current E evidence this must be undetermined.',
        },
      },
      required: ['summary', 'root_cause_status'],
      additionalProperties: false,
    },
    output: {
      schema: { type: 'object' },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
    },
    async execute(args, exec) {
      const summary = String(args.summary ?? '')
      const result = validateSummary(exec.agent, summary, String(args.root_cause_status ?? ''))
      if (!result.valid) {
        return { validated: false, ...result, instruction: '继续回读缺失文档或补充 E/K 引用，再次调用 hci_finalize。' }
      }
      return { validated: true, ...result, instruction: '门禁通过，可以输出与 summary 完全一致的报告。' }
    },
  })
}
