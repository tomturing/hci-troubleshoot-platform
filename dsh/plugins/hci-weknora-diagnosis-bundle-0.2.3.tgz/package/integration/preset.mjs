import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { resolve } from 'node:path'

export const name = 'hci-weknora-preset'
export const inject = ['agentPresets']

const require = createRequire(import.meta.url)
const localPlugins = new Set([
  './single-agent.mjs',
  './evidence-tools.mjs',
  './flow-gate.mjs',
])

function list(value) {
  if (Array.isArray(value)) return [...new Set(value.map(String).map(item => item.trim()).filter(Boolean))]
  if (typeof value !== 'string') return []
  return [...new Set(value.split(',').map(item => item.trim()).filter(Boolean))]
}

function positiveInt(value, fallback) {
  const parsed = Number(value)
  return Number.isSafeInteger(parsed) && parsed > 0 ? parsed : fallback
}

export function resolvePreset(config = {}) {
  const packageRoot = resolve(fileURLToPath(new URL('..', import.meta.url)))
  const workspaceRoot = typeof config.workspaceRoot === 'string' ? config.workspaceRoot.trim() : ''
  const fallbackSupportRoot = typeof config.fallbackSupportRoot === 'string' ? config.fallbackSupportRoot.trim() : ''
  if (!workspaceRoot && !fallbackSupportRoot) {
    throw new Error('WECOM_WORKSPACE_ROOT or HCI_SUPPORT_ROOT is required')
  }

  const caseKnowledgeBaseIds = list(config.caseKnowledgeBaseIds)
  const playbookKnowledgeBaseIds = list(config.playbookKnowledgeBaseIds)
  const agentKnowledgeBaseIds = list(config.agentKnowledgeBaseIds)
  const knowledgeBaseIds = [...new Set([...caseKnowledgeBaseIds, ...playbookKnowledgeBaseIds])]
  const caseTopN = positiveInt(config.caseTopN, 3)
  const playbookTopN = positiveInt(config.playbookTopN, 3)

  const plugins = (config.plugins ?? []).map(entry => {
    if (localPlugins.has(entry.name)) {
      const resolvedEntry = { ...entry, name: fileURLToPath(new URL(entry.name, import.meta.url)) }
      if (entry.id === 'hci-weknora-evidence-tools') {
        resolvedEntry.config = {
          ...entry.config,
          workspaceRoot: workspaceRoot ? resolve(workspaceRoot) : '',
          ruleWorkspaceRoot: process.env.WECOM_RULE_WORKSPACE_ROOT || '',
          fallbackSupportRoot: fallbackSupportRoot ? resolve(fallbackSupportRoot) : '',
        }
      }
      if (entry.id === 'hci-weknora-flow-gate') {
        resolvedEntry.config = {
          ...entry.config,
          caseKnowledgeBaseIds,
          playbookKnowledgeBaseIds,
          caseTopN,
          playbookTopN,
        }
      }
      return resolvedEntry
    }
    if (entry.id === 'weknora-hci-knowledge') {
      return {
        ...entry,
        name: require.resolve('@wxg-prc-cpg/dsh-weknora'),
        config: {
          ...entry.config,
          baseUrl: config.baseUrl || 'http://127.0.0.1:8080/api/v1',
          ...(typeof config.apiKey === 'string' && config.apiKey.trim() ? { apiKey: config.apiKey.trim() } : {}),
          ...(typeof config.tenantId === 'string' && config.tenantId.trim() ? { tenantId: config.tenantId.trim() } : {}),
          knowledgeBaseIds,
          requestTimeoutMs: positiveInt(config.requestTimeoutMs, 30000),
          maxResults: positiveInt(config.maxResults, 12),
          maxChunkChars: positiveInt(config.maxChunkChars, 1600),
          resourceUrls: config.resourceUrls === 'public' ? 'public' : 'handle',
          toolPrefix: 'hci_kb',
          tools: {
            listKnowledgeBases: true,
            search: true,
            readDocument: true,
            ask: false,
          },
        },
      }
    }
    if (entry.id === 'weknora-hci-quick-agent' || entry.id === 'weknora-hci-reasoning-agent') {
      const quick = entry.id === 'weknora-hci-quick-agent'
      const agentId = quick ? config.quickAgentId : config.reasoningAgentId
      if (typeof agentId !== 'string' || !agentId.trim()) {
        throw new Error(quick ? 'WEKNORA_HCI_QUICK_AGENT_ID is required' : 'WEKNORA_HCI_REASONING_AGENT_ID is required')
      }
      return {
        ...entry,
        name: fileURLToPath(new URL('./agent-tools.mjs', import.meta.url)),
        config: {
          baseUrl: config.baseUrl || 'http://127.0.0.1:8080/api/v1',
          ...(typeof config.apiKey === 'string' && config.apiKey.trim() ? { apiKey: config.apiKey.trim() } : {}),
          ...(typeof config.tenantId === 'string' && config.tenantId.trim() ? { tenantId: config.tenantId.trim() } : {}),
          knowledgeBaseIds: agentKnowledgeBaseIds,
          agentId: agentId.trim(),
          requestTimeoutMs: positiveInt(config.requestTimeoutMs, 30000),
          chatTimeoutMs: positiveInt(config.chatTimeoutMs, 300000),
          resourceUrls: config.resourceUrls === 'public' ? 'public' : 'handle',
          toolPrefix: quick ? 'hci_quick' : 'hci_reasoning',
          tools: {
            listKnowledgeBases: false,
            search: false,
            readDocument: false,
            ask: true,
          },
        },
      }
    }
    if (entry.id === 'persona') {
      const prefix = String(entry.config?.prefix ?? '')
      return {
        ...entry,
        config: {
          ...entry.config,
          prefix: `${prefix} 阶段一智能体固定使用 test 知识库 ID：${agentKnowledgeBaseIds.join(', ') || '未配置'}。阶段二直接检索知识库 ID：${knowledgeBaseIds.join(', ') || '未配置'}。`,
        },
      }
    }
    return entry
  })

  const {
    baseUrl: _baseUrl,
    apiKey: _apiKey,
    tenantId: _tenantId,
    caseKnowledgeBaseIds: _caseKnowledgeBaseIds,
    playbookKnowledgeBaseIds: _playbookKnowledgeBaseIds,
    agentKnowledgeBaseIds: _agentKnowledgeBaseIds,
    quickAgentId: _quickAgentId,
    reasoningAgentId: _reasoningAgentId,
    workspaceRoot: _workspaceRoot,
    fallbackSupportRoot: _fallbackSupportRoot,
    caseTopN: _caseTopN,
    playbookTopN: _playbookTopN,
    requestTimeoutMs: _requestTimeoutMs,
    chatTimeoutMs: _chatTimeoutMs,
    maxResults: _maxResults,
    maxChunkChars: _maxChunkChars,
    resourceUrls: _resourceUrls,
    ...presetConfig
  } = config
  return { ...presetConfig, plugins }
}

export async function apply(ctx, config) {
  await ctx.effect(() => ctx.agentPresets.register(resolvePreset(config)))
}
