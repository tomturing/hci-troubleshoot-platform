# HCI WeKnora 离线安装包 0.2.3

本包包含：

- `hci-weknora-diagnosis-bundle-0.2.3.tgz`
- `wxg-prc-cpg-dsh-weknora-0.1.0.tgz`

在没有外网的环境中，将本目录复制到目标机器，并在 DeepSeek Harness 检出目录执行：

```bash
pnpm store add ./wxg-prc-cpg-dsh-weknora-0.1.0.tgz
pnpm dsh plugin --profile web add ./hci-weknora-diagnosis-bundle-0.2.3.tgz --offline --ignore-scripts
```

然后按 Bundle README 配置 `WEKNORA_BASE_URL`、`WEKNORA_API_KEY`、知识库 ID 和 Agent ID。

要求：Node.js 24.9+、pnpm 11，以及目标 Harness 已具备 Web profile。
