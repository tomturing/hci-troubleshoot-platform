#!/bin/sh
set -eu

if [ "$#" -ne 1 ]; then
  echo "用法: $0 /path/to/deepseek-harness" >&2
  exit 2
fi

bundle_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
harness_dir=$1

pnpm store add "$bundle_dir/wxg-prc-cpg-dsh-weknora-0.1.0.tgz"
cd "$harness_dir"
pnpm dsh plugin --profile web add "$bundle_dir/hci-weknora-diagnosis-bundle-0.2.3.tgz" --offline --ignore-scripts
